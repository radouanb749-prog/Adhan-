# تطبيق مواقيت الصلاة بالمغرب - Moroccan Islamic Prayer Times

تطبيق مواقيت الصلاة الدقيقة بالمغرب وفق حسابات وزارة الأوقاف والشؤون الإسلامية بالمملكة المغربية، مع دعم أصوات المؤذنين والقبلة والأذكار واللغتين العربية والإنجليزية.

---

## إدماج إعلانات Unity Ads (Game ID: 800400769 - Quran Karim)
تم دمج كود شبكة Unity Ads الإعلانية بنجاح في هذا الإصدار:
- **Game ID:** `800400769` (Quran Karim)
- **Banner Placement:** `Banner_Android` / `banner`
- **Interstitial Placement:** `Interstitial_Android` / `video`
- **Rewarded Placement:** `Rewarded_Android` / `rewardedVideo`
- **الملف الخدمي:** `src/services/unityAdsService.ts`
- **مكون البانر:** `src/components/UnityAdsBanner.tsx`
- **ملف تهيئة الموبايل (Android / Capacitor):** `capacitor.config.json`

---

## المميزات الأساسية:
- مواقيت الصلاة الدقيقة لـ 100+ مدينة مغربية وفق التوقيت المعتمد (GMT / GMT+1).
- حساب الصلاة القادمة والعد التنازلي التلقائي ثانية بثانية بدون قيم سالبة.
- أذان بصوت كبار مؤذني العالم الإسلامي والأذان المغربي الأصيل.
- إمكانية إيقاف الأذان بهز الهاتف عبر مستشعر الحركة (Accelerometer).
- دعم اللغتين (العربية والإنجليزية) في جميع القوائم وشاشات الإعدادات.
- الحفاظ الكامل على نصوص الآيات القرآنية بالرسم العثماني والأذكار النبوية الشريفة.
- تطبيق ويب تقدمي (PWA) قابل للتثبيت على الهواتف مع دعم العمل بدون إنترنت.

---

## التشغيل محلياً:
```bash
# تثبيت التبعيات
npm install

# تشغيل خادم التطوير
npm run dev

# بناء النسخة الإنتاجية مع تحديث ملف الـ ZIP
npm run build
```

---

## تصدير التطبيق إلى Android APK (اختياري عبر Capacitor):
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "صلاتك" "com.salatmaroc.app"
npm run build
npx cap add android
npx cap open android
```
معرف Unity Ads (`800400769` - Quran Karim) جاهز ومعد تلقائياً في `capacitor.config.json`.
