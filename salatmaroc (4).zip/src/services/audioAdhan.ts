// Web Audio API synthesized Adhan & HTML5 Real Muezzin Adhan Streaming
import { adhanLogService } from './adhanLogService';
import { nativeAlarmBridge, scheduleNativeAdhan } from './nativeAlarmBridge';

export interface AdhanPlaybackState {
  isPlaying: boolean;
  activeId: string | null; // e.g. prayer id or muezzin id
  title: string | null;
  muezzinName: string | null;
  currentTime: number;
  duration: number;
}

export interface PlayAdhanContext {
  prayerId?: string;
  prayerNameAr?: string;
  scheduledTime?: string;
  cityNameAr?: string;
  triggerType?: 'scheduled' | 'manual_test' | 'pre_alert';
}

export interface AudioSystemAlert {
  id: string;
  type: 'phone_settings' | 'autoplay_blocked' | 'audio_error';
  title: string;
  message: string;
  prayerNameAr?: string;
  timestamp: number;
  audioUrl?: string;
  muezzinName?: string;
}

type PlaybackListener = (state: AdhanPlaybackState) => void;

class AdhanAudioService {
  private ctx: AudioContext | null = null;
  private isAudioUnlocked: boolean = false;
  private activeOscillators: OscillatorNode[] = [];
  private activeBufferSource: AudioBufferSourceNode | null = null;
  private activeGainNode: GainNode | null = null;
  private audioBufferCache: Map<string, AudioBuffer> = new Map();
  private activeAudioIssue: AudioSystemAlert | null = null;
  private audioIssueListeners: ((issue: AudioSystemAlert | null) => void)[] = [];
  private listeners: PlaybackListener[] = [];
  private isStoppedByUser: boolean = false;
  private userStoppedAdhanIds: Set<string> = new Set();
  private pendingInteractionResumer: (() => void) | null = null;
  private wakeLock: any = null;
  private keepAliveOscillator: OscillatorNode | null = null;
  private keepAliveGain: GainNode | null = null;
  private state: AdhanPlaybackState = {
    isPlaying: false,
    activeId: null,
    title: null,
    muezzinName: null,
    currentTime: 0,
    duration: 0,
  };

  constructor() {
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        this.preloadAudioBuffer('/audio/adhan-morocco.mp3').catch(() => {});
        this.preloadAudioBuffer('/audio/adhan-fajr.mp3').catch(() => {});
      }, 300);
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    // Configure AudioSession type to 'playback' on iOS & modern Android browsers to override silent/mute hardware switch
    try {
      if (typeof navigator !== 'undefined' && 'audioSession' in navigator) {
        // @ts-expect-error AudioSession API for Safari & modern Chromium
        navigator.audioSession.type = 'playback';
      }
    } catch {}
  }

  // Pre-fetch and decode real MP3 adhan into in-memory AudioBuffer
  // Web Audio buffer playback is exempt from autoplay restrictions once AudioContext has been resumed
  public async preloadAudioBuffer(url: string): Promise<AudioBuffer | null> {
    try {
      this.initCtx();
      if (!this.ctx) return null;
      if (this.audioBufferCache.has(url)) {
        return this.audioBufferCache.get(url)!;
      }
      const response = await fetch(url);
      if (!response.ok) return null;
      const arrayBuffer = await response.arrayBuffer();
      const decoded = await this.ctx.decodeAudioData(arrayBuffer);
      this.audioBufferCache.set(url, decoded);
      return decoded;
    } catch (err) {
      console.warn(`[audioAdhan] Failed to preload audio buffer for ${url}:`, err);
      return null;
    }
  }

  // Play real authentic MP3 Adhan via Web Audio API BufferSource (bypasses browser autoplay restrictions)
  public playBufferAdhan(
    buffer: AudioBuffer,
    id: string,
    title: string,
    muezzinName: string
  ): boolean {
    try {
      if (this.activeBufferSource) {
        try {
          this.activeBufferSource.stop();
        } catch {}
        this.activeBufferSource = null;
      }
      this.isStoppedByUser = false;
      this.userStoppedAdhanIds.delete(id);
      this.initCtx();
      if (!this.ctx) return false;

      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }

      const source = this.ctx.createBufferSource();
      source.buffer = buffer;

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(1.0, this.ctx.currentTime);

      source.connect(gain);
      gain.connect(this.ctx.destination);

      this.activeBufferSource = source;
      this.activeGainNode = gain;

      const startTime = this.ctx.currentTime;
      const duration = buffer.duration;

      this.state = {
        isPlaying: true,
        activeId: id,
        title,
        muezzinName,
        currentTime: 0,
        duration,
      };
      this.notify();

      // Setup MediaSession for lock screen display & background audio controls
      if (typeof navigator !== 'undefined' && 'mediaSession' in navigator) {
        try {
          navigator.mediaSession.metadata = new MediaMetadata({
            title,
            artist: muezzinName,
            album: 'صلاتك - مواقيت الصلاة والأذان بالمغرب',
            artwork: [
              { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
              { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
            ],
          });
          navigator.mediaSession.playbackState = 'playing';
          navigator.mediaSession.setActionHandler('pause', () => this.stopAll());
          navigator.mediaSession.setActionHandler('stop', () => this.stopAll());
        } catch {}
      }

      // Request Screen Wake Lock during buffer playback
      try {
        if (typeof navigator !== 'undefined' && 'wakeLock' in navigator && !this.wakeLock) {
          navigator.wakeLock.request('screen').then((lock: any) => {
            this.wakeLock = lock;
          }).catch(() => {});
        }
      } catch {}

      source.onended = () => {
        this.stopAll();
      };

      nativeAlarmBridge.enableTemporaryDndBypass();
      source.start(0);
      return true;
    } catch (err) {
      console.warn('[audioAdhan] playBufferAdhan failed:', err);
      return false;
    }
  }

  // Starts a continuous inaudible audio carrier node that keeps Web Audio running 24/7
  // Prevents mobile browsers (iOS/Android) from suspending the AudioContext when screen is locked
  public startKeepAliveAudio() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }

      // 1. Maintain inaudible 10Hz sub-carrier node directly on AudioContext hardware clock
      if (!this.keepAliveOscillator) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(10, this.ctx.currentTime);
        // Ultra-low amplitude: inaudible but keeps audio DAC and system thread active
        gain.gain.setValueAtTime(0.0001, this.ctx.currentTime);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start();

        this.keepAliveOscillator = osc;
        this.keepAliveGain = gain;
      }

      // 3. MediaSession standby registration so mobile OS maintains active background media channel
      if (typeof navigator !== 'undefined' && 'mediaSession' in navigator) {
        try {
          navigator.mediaSession.metadata = new MediaMetadata({
            title: 'مواقيت الصلاة والأذان بالمغرب',
            artist: 'جاهز لرفع الأذان في موعده',
            album: 'صلاتك - حماية الأذان في الخلفية',
            artwork: [
              { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
              { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
            ],
          });
          navigator.mediaSession.playbackState = 'playing';
        } catch {}
      }

      this.isAudioUnlocked = true;
    } catch (err) {
      console.warn('[audioAdhan] startKeepAliveAudio failed:', err);
    }
  }

  // Activate continuous silent background audio loop so mobile browser never freezes timers
  public activateBackgroundAudioGuard() {
    this.startKeepAliveAudio();
  }

  // Proactively unlock browser audio on user gesture for background playback
  public unlockAudio() {
    try {
      this.initCtx();
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      this.startKeepAliveAudio();

      // Eagerly pre-decode real Moroccan Adhan buffer into memory for 0ms reliable background playback
      this.preloadAudioBuffer('/audio/adhan-morocco.mp3').catch(() => {});
      this.preloadAudioBuffer('/audio/adhan-fajr.mp3').catch(() => {});
    } catch {
      // ignore
    }
  }

  // Subscribe to playback status updates
  public subscribe(listener: PlaybackListener): () => void {
    this.listeners.push(listener);
    listener(this.state);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => {
      try {
        l({ ...this.state });
      } catch {
        // ignore
      }
    });
  }

  // Play Real MP3 Adhan recitation by famous Muezzin with robust fallback
  public async playRealAdhan(
    audioUrl: string,
    id: string,
    title: string = 'أذان الصلاة',
    muezzinName: string = 'الأذان',
    extraContext?: PlayAdhanContext
  ) {
    const isTest = extraContext?.triggerType === 'manual_test' || id.startsWith('test') || id.startsWith('hero_');
    const logId = `adhan_log_${id}_${Date.now()}`;
    const prayerNameAr = extraContext?.prayerNameAr || (id.includes('fajr') ? 'الفجر' : title);
    const prayerId = extraContext?.prayerId || (id.includes('fajr') ? 'fajr' : 'general');
    const isFajr = id.includes('fajr') || title.includes('الفجر');
    const fallbackUrl = isFajr ? '/audio/adhan-fajr.mp3' : '/audio/adhan-morocco.mp3';
    let targetUrl = audioUrl || fallbackUrl;

    try {
      // If already playing this same audio, stop it
      if (this.state.isPlaying && this.state.activeId === id) {
        this.stopAll();
        return;
      }

      // Stop any existing audio first
      this.stopAll();
      this.isStoppedByUser = false;
      this.userStoppedAdhanIds.delete(id);

      // Ensure AudioContext and keep-alive carrier are running
      this.initCtx();
      this.startKeepAliveAudio();

      // 1. For real scheduled Adhan, schedule notification via @capacitor/local-notifications on azan-channel with sound azan.mp3
      if (!isTest) {
        scheduleNativeAdhan(prayerNameAr, new Date(Date.now() + 500)).catch(() => {});
      }

      let buffer: AudioBuffer | null | undefined =
        this.audioBufferCache.get(targetUrl) || (await this.preloadAudioBuffer(targetUrl));
      if (!buffer && targetUrl !== fallbackUrl) {
        buffer = this.audioBufferCache.get(fallbackUrl) || (await this.preloadAudioBuffer(fallbackUrl));
      }

      if (this.isStoppedByUser || this.userStoppedAdhanIds.has(id)) {
        return;
      }

      // Play directly via Web Audio BufferSource (no new Audio() and no setInterval())
      if (buffer) {
        if (this.ctx && this.ctx.state === 'suspended') {
          try {
            await this.ctx.resume();
          } catch {}
        }
        const played = this.playBufferAdhan(buffer, id, title, muezzinName);
        if (played) {
          adhanLogService.addLog({
            id: logId,
            prayerId,
            prayerNameAr,
            scheduledTime: extraContext?.scheduledTime,
            cityNameAr: extraContext?.cityNameAr,
            muezzinName,
            audioUrl: targetUrl,
            status: 'success',
            triggerType: extraContext?.triggerType || (isTest ? 'manual_test' : 'scheduled'),
            message: isTest
              ? `تم اختبار تشغيل الملف الصوتي (${muezzinName}) بنجاح.`
              : `تم رفع أذان ${prayerNameAr} في موعده المحدد بصوت ${muezzinName}.`,
            audioSourceType: targetUrl.startsWith('/audio/') ? 'local_mp3' : 'external_url',
          });
          return;
        }
      }

      this.playAdhanChime(title, muezzinName);
      return;
    } catch (err: any) {
      console.warn('[audioAdhan] playRealAdhan error:', err);
      if (!this.isStoppedByUser && !this.userStoppedAdhanIds.has(id)) {
        this.playAdhanChime(title, muezzinName);
      }
    }
  }

  // Returns null as HTMLAudioElement is replaced with Web Audio BufferSource & LocalNotifications
  public getCurrentAudioElement(): HTMLAudioElement | null {
    return null;
  }

  public stopAll(): boolean {
    const wasPlaying = this.state.isPlaying;
    this.isStoppedByUser = true;
    if (this.state.activeId) {
      this.userStoppedAdhanIds.add(this.state.activeId);
    }

    // Immediately remove pending interaction resumption listeners so tapping never restarts Adhan
    if (this.pendingInteractionResumer) {
      window.removeEventListener('touchstart', this.pendingInteractionResumer);
      window.removeEventListener('click', this.pendingInteractionResumer);
      window.removeEventListener('pointerdown', this.pendingInteractionResumer);
      this.pendingInteractionResumer = null;
    }



    if (this.activeBufferSource) {
      try {
        this.activeBufferSource.stop();
        this.activeBufferSource.disconnect();
      } catch {
        // ignore
      }
      this.activeBufferSource = null;
    }

    if (this.activeGainNode) {
      try {
        this.activeGainNode.disconnect();
      } catch {
        // ignore
      }
      this.activeGainNode = null;
    }

    if (this.activeOscillators.length > 0) {
      this.activeOscillators.forEach((osc) => {
        try {
          osc.stop();
          osc.disconnect();
        } catch {
          // ignore
        }
      });
      this.activeOscillators = [];
    }

    // Immediately stop any active phone vibration
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(0);
      } catch {
        // ignore
      }
    }

    // Immediately stop native Adhan in Android background service, dismiss lock screen,
    // and restore original NotificationManager interruption filter if temporarily bypassed
    try {
      nativeAlarmBridge.stopAdhan();
      nativeAlarmBridge.restoreOriginalDndFilter();
    } catch {}

    if (this.wakeLock) {
      try {
        this.wakeLock.release().catch(() => {});
      } catch {}
      this.wakeLock = null;
    }

    this.state = {
      isPlaying: false,
      activeId: null,
      title: null,
      muezzinName: null,
      currentTime: 0,
      duration: 0,
    };
    this.notify();

    return wasPlaying;
  }

  // Alias for backward compatibility
  public stopRealAdhan() {
    this.stopAll();
  }

  public getPlaybackState(): AdhanPlaybackState {
    return { ...this.state };
  }

  // Play a single clean, pleasant synthesized alert pulse (double harmonic chime)
  private playAlertPulse() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      const now = this.ctx.currentTime;

      // Pulse 1: D5 note (587.33 Hz)
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now);
      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.32, now + 0.04);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
      osc1.connect(gain1);
      gain1.connect(this.ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.4);
      this.activeOscillators.push(osc1);

      // Pulse 2: A5 harmonic note (880.0 Hz)
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880.0, now + 0.18);
      gain2.gain.setValueAtTime(0, now + 0.18);
      gain2.gain.linearRampToValueAtTime(0.35, now + 0.22);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
      osc2.connect(gain2);
      gain2.connect(this.ctx.destination);
      osc2.start(now + 0.18);
      osc2.stop(now + 0.68);
      this.activeOscillators.push(osc2);

      // Clean up finished oscillators
      osc2.onended = () => {
        this.activeOscillators = this.activeOscillators.filter(
          (o) => o !== osc1 && o !== osc2
        );
      };

      // Vibrate mobile device in sync with alert pulse
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([180, 80, 180]);
        } catch {}
      }
    } catch (err) {
      console.warn('[audioAdhan] playAlertPulse error:', err);
    }
  }

  // Ensures repeating an alert tone scheduled purely on Web Audio clock (no setTimeout or setInterval)
  public playRepeatingAlertTone(
    title: string = 'تنبيه موعد الصلاة',
    muezzinName: string = 'نغمة تنبيه مكررة',
    prayerNameAr?: string,
    targetAudioUrl?: string
  ) {
    try {
      this.stopAll();
      this.initCtx();
      if (!this.ctx) return;
      this.isStoppedByUser = false;

      const alertTitle = title || (prayerNameAr ? `تنبيه موعد صلاة ${prayerNameAr}` : 'تنبيه موعد الصلاة');

      this.state = {
        isPlaying: true,
        activeId: 'repeating_alert_tone',
        title: alertTitle,
        muezzinName,
        currentTime: 0,
        duration: 30, // 30 seconds max duration
      };
      this.notify();

      // Schedule 12 pulses directly on Web Audio hardware timeline (no setTimeout or setInterval)
      nativeAlarmBridge.enableTemporaryDndBypass();
      const now = this.ctx.currentTime;
      const count = 12;
      for (let i = 0; i < count; i++) {
        const pulseStart = now + i * 2.5;
        this.scheduleAlertPulseAt(pulseStart, i === count - 1);
      }
    } catch (err) {
      console.warn('[audioAdhan] playRepeatingAlertTone failed:', err);
      this.stopAll();
    }
  }

  private scheduleAlertPulseAt(startTime: number, isLast: boolean) {
    if (!this.ctx) return;
    try {
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, startTime);
      gain1.gain.setValueAtTime(0.001, startTime);
      gain1.gain.exponentialRampToValueAtTime(0.35, startTime + 0.04);
      gain1.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.5);
      osc1.connect(gain1);
      gain1.connect(this.ctx.destination);
      osc1.start(startTime);
      osc1.stop(startTime + 0.52);
      this.activeOscillators.push(osc1);

      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880.0, startTime + 0.18);
      gain2.gain.setValueAtTime(0.001, startTime + 0.18);
      gain2.gain.exponentialRampToValueAtTime(0.4, startTime + 0.22);
      gain2.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.65);
      osc2.connect(gain2);
      gain2.connect(this.ctx.destination);
      osc2.start(startTime + 0.18);
      osc2.stop(startTime + 0.68);
      this.activeOscillators.push(osc2);

      if (isLast) {
        osc2.onended = () => {
          this.stopAll();
        };
      }
    } catch {}
  }

  // Audio system issue listeners for phone settings & playback restrictions
  public onAudioIssue(listener: (issue: AudioSystemAlert | null) => void): () => void {
    this.audioIssueListeners.push(listener);
    listener(this.activeAudioIssue);
    return () => {
      this.audioIssueListeners = this.audioIssueListeners.filter((l) => l !== listener);
    };
  }

  public getActiveAudioIssue(): AudioSystemAlert | null {
    return this.activeAudioIssue;
  }

  public dismissAudioIssue(): void {
    this.activeAudioIssue = null;
    this.audioIssueListeners.forEach((l) => {
      try {
        l(null);
      } catch {}
    });
  }

  public triggerAudioIssue(issue: Omit<AudioSystemAlert, 'timestamp'>): void {
    this.activeAudioIssue = {
      ...issue,
      timestamp: Date.now(),
    };
    this.audioIssueListeners.forEach((l) => {
      try {
        l(this.activeAudioIssue);
      } catch {}
    });
  }

  // Play peaceful Islamic chime / Adhan melody (Synthesized Web Audio Fallback)
  public playAdhanChime(title: string = 'أذان الصلاة', muezzinName: string = 'الأذان الشرعي') {
    try {
      this.stopAll();
      this.initCtx();
      if (!this.ctx) return;

      this.state = {
        isPlaying: true,
        activeId: 'adhan_chime',
        title,
        muezzinName,
        currentTime: 0,
        duration: 7,
      };
      this.notify();

      nativeAlarmBridge.enableTemporaryDndBypass();
      const now = this.ctx.currentTime;
      // Traditional maqam bayati notes frequency (D, Eb-half-flat, F, G, A, Bb, C, D)
      const notes = [
        { freq: 293.66, dur: 0.8 }, // D4 (Allah)
        { freq: 349.23, dur: 1.2 }, // F4 (Akbar)
        { freq: 392.00, dur: 1.6 }, // G4
        { freq: 440.00, dur: 1.4 }, // A4
        { freq: 349.23, dur: 1.8 }, // F4
        { freq: 293.66, dur: 2.2 }, // D4
      ];

      let startTime = now;
      notes.forEach((note) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        // Warm sine + harmonic warmth
        osc.type = 'sine';
        osc.frequency.setValueAtTime(note.freq, startTime);

        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(0.25, startTime + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + note.dur);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + note.dur + 0.1);

        this.activeOscillators.push(osc);
        startTime += note.dur * 0.75;
      });

      const lastOsc = this.activeOscillators[this.activeOscillators.length - 1];
      if (lastOsc) {
        lastOsc.onended = () => {
          this.stopAll();
        };
      }

      if (navigator.vibrate) {
        navigator.vibrate([100, 50, 100]);
      }
    } catch {
      this.stopAll();
    }
  }

  // Soft bell click sound
  public playClickSound() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(650, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.15);
    } catch {
      // ignore
    }
  }

  // Play serene chime when compass is precisely aligned with Qibla
  public playQiblaAlignedTone() {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      // Golden bell chime chord: 528Hz + 660Hz + 792Hz
      const freqs = [528.0, 660.0, 792.0];

      freqs.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0, now + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.25, now + idx * 0.08 + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 1.4);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 1.45);
      });
    } catch {
      // Audio might be suppressed before gesture
    }
  }

  // Voice guidance in Arabic: "أنت الآن باتجاه القبلة"
  public speakQiblaGuidance() {
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance('أنت الآن باتجاه القبلة');
        utterance.lang = 'ar-SA';
        utterance.rate = 0.95;
        window.speechSynthesis.speak(utterance);
      }
    } catch {
      // ignore
    }
  }

  // Soft, serene spiritual chime specifically for morning & evening Dhikr reminders
  public playGentleDhikrChime() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const now = this.ctx.currentTime;
      // Gentle spiritual pentatonic bells: 440Hz (A4), 554.37Hz (C#5), 659.25Hz (E5), 880Hz (A5)
      const freqs = [440.0, 554.37, 659.25, 880.0];
      freqs.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.14);

        gain.gain.setValueAtTime(0, now + idx * 0.14);
        gain.gain.linearRampToValueAtTime(0.2, now + idx * 0.14 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.14 + 1.3);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now + idx * 0.14);
        osc.stop(now + idx * 0.14 + 1.35);
      });

      if (navigator.vibrate) {
        navigator.vibrate([100, 80, 120]);
      }
    } catch {
      // ignore
    }
  }
}

export const audioAdhanService = new AdhanAudioService();
