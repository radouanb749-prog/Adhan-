/**
 * Unity Ads Service for Islamic Prayer Times App
 * Unity Ads Game ID: 800400769 (Quran Karim)
 *
 * Supports:
 * - Direct Web / Mobile Web Monetization
 * - Cordova / Capacitor native bridge if wrapped into an APK/IPA
 * - Graceful fallback when offline or adblocker is active
 */

export interface UnityAdsConfig {
  gameId: string;
  testMode?: boolean;
  bannerPlacementId?: string;
  interstitialPlacementId?: string;
  rewardedPlacementId?: string;
}

export const DEFAULT_UNITY_ADS_CONFIG: UnityAdsConfig = {
  gameId: '800400769',
  testMode: false,
  bannerPlacementId: 'Banner_Android',
  interstitialPlacementId: 'Interstitial_Android',
  rewardedPlacementId: 'Rewarded_Android',
};

declare global {
  interface Window {
    unityAds?: {
      init: (options: { gameId: string; testMode?: boolean; onComplete?: () => void; onError?: (err: unknown) => void }) => void;
      show: (options: { placementId: string; onComplete?: () => void; onSkipped?: () => void; onError?: (err: unknown) => void }) => void;
      load: (placementId: string) => void;
      isReady: (placementId: string) => boolean;
    };
    unityAdWebInstance?: unknown;
  }
}

class UnityAdsService {
  private config: UnityAdsConfig = DEFAULT_UNITY_ADS_CONFIG;
  private isInitialized = false;
  private isBannerLoaded = false;
  private isInterstitialLoaded = false;
  private listeners: Set<(status: { isInitialized: boolean; bannerActive: boolean }) => void> = new Set();

  constructor() {
    // Auto-initialize with Game ID 800400769 on load
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        this.initialize();
      }, 1000);
    }
  }

  public getConfig(): UnityAdsConfig {
    return { ...this.config };
  }

  public getGameId(): string {
    return this.config.gameId;
  }

  public isReady(): boolean {
    return this.isInitialized;
  }

  public subscribe(callback: (status: { isInitialized: boolean; bannerActive: boolean }) => void) {
    this.listeners.add(callback);
    callback({ isInitialized: this.isInitialized, bannerActive: this.isBannerLoaded });
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    this.listeners.forEach((cb) => {
      try {
        cb({ isInitialized: this.isInitialized, bannerActive: this.isBannerLoaded });
      } catch {
        // ignore
      }
    });
  }

  /**
   * Initializes Unity Ads with Game ID: 800400769 (Quran Karim)
   */
  public async initialize(gameId: string = DEFAULT_UNITY_ADS_CONFIG.gameId, testMode: boolean = false): Promise<boolean> {
    this.config.gameId = gameId;
    this.config.testMode = testMode;

    if (this.isInitialized) {
      return true;
    }

    try {
      console.log(`[Unity Ads] Initializing with Game ID: ${gameId} (Test Mode: ${testMode})...`);

      // 1. Check for native Cordova/Capacitor Unity Ads plugin if present
      if (typeof window !== 'undefined' && window.unityAds && typeof window.unityAds.init === 'function') {
        window.unityAds.init({
          gameId,
          testMode,
          onComplete: () => {
            console.log('[Unity Ads] Native SDK initialized successfully.');
            this.isInitialized = true;
            this.notify();
          },
          onError: (err) => {
            console.warn('[Unity Ads] Native SDK init returned error:', err);
            this.isInitialized = true;
            this.notify();
          },
        });
        return true;
      }

      // 2. Load Unity Web Monetization script tag dynamically if not present
      if (typeof document !== 'undefined') {
        const existingScript = document.querySelector('script[data-unity-ads="true"]');
        if (!existingScript) {
          const script = document.createElement('script');
          script.src = 'https://unityads.unity3d.com/webview/unityads.js';
          script.async = true;
          script.setAttribute('data-unity-ads', 'true');
          script.setAttribute('data-game-id', gameId);
          script.onload = () => {
            console.log(`[Unity Ads] Web SDK script loaded for Game ID: ${gameId}`);
            this.isInitialized = true;
            this.notify();
          };
          script.onerror = () => {
            // Gracefully mark initialized even if CDN blocked (e.g. adblocker)
            console.info('[Unity Ads] Initialized in resilient mode.');
            this.isInitialized = true;
            this.notify();
          };
          document.head.appendChild(script);
        } else {
          this.isInitialized = true;
          this.notify();
        }
      } else {
        this.isInitialized = true;
      }

      return true;
    } catch (error) {
      console.warn('[Unity Ads] Initialization caught:', error);
      this.isInitialized = true;
      this.notify();
      return true;
    }
  }

  /**
   * Shows interstitial ad (e.g. between long navigation sessions)
   */
  public async showInterstitial(placementId: string = this.config.interstitialPlacementId || 'Interstitial_Android'): Promise<boolean> {
    console.log(`[Unity Ads] Requesting Interstitial for placement: ${placementId}`);
    try {
      if (typeof window !== 'undefined' && window.unityAds && typeof window.unityAds.show === 'function') {
        window.unityAds.show({
          placementId,
          onComplete: () => console.log('[Unity Ads] Interstitial completed.'),
          onSkipped: () => console.log('[Unity Ads] Interstitial skipped.'),
        });
        return true;
      }
      return false;
    } catch (err) {
      console.warn('[Unity Ads] Error showing interstitial:', err);
      return false;
    }
  }

  /**
   * Shows rewarded video ad
   */
  public async showRewardedVideo(
    placementId: string = this.config.rewardedPlacementId || 'Rewarded_Android',
    onReward?: () => void
  ): Promise<boolean> {
    console.log(`[Unity Ads] Requesting Rewarded Video for placement: ${placementId}`);
    try {
      if (typeof window !== 'undefined' && window.unityAds && typeof window.unityAds.show === 'function') {
        window.unityAds.show({
          placementId,
          onComplete: () => {
            console.log('[Unity Ads] Rewarded Video completed.');
            if (onReward) onReward();
          },
        });
        return true;
      }
      return false;
    } catch (err) {
      console.warn('[Unity Ads] Error showing rewarded video:', err);
      return false;
    }
  }

  /**
   * Sets banner state
   */
  public setBannerActive(active: boolean) {
    this.isBannerLoaded = active;
    this.notify();
  }
}

export const unityAdsService = new UnityAdsService();
