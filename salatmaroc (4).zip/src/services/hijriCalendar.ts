/**
 * Hijri calendar calculations calibrated to Morocco Ministry of Habous sightings
 */

const ARABIC_WEEKDAYS = [
  'الأحد',
  'الإثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
];

const GREGORIAN_MONTHS = [
  'يناير',
  'فبراير',
  'مارس',
  'أبريل',
  'مايو',
  'يونيو',
  'يوليو',
  'أغسطس',
  'سبتمبر',
  'أكتوبر',
  'نوفمبر',
  'ديسمبر',
];

const HIJRI_MONTHS = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الثاني',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة',
];

export interface FormattedDateInfo {
  weekdayAr: string;
  hijriDay: number;
  hijriMonthAr: string;
  hijriYear: number;
  gregorianDay: number;
  gregorianMonthAr: string;
  gregorianYear: number;
  fullDateString: string;
}

export function getFormattedDateInfo(date: Date, adjustmentDays: number = 0): FormattedDateInfo {
  const adjustedDate = new Date(date);
  if (adjustmentDays !== 0) {
    adjustedDate.setDate(adjustedDate.getDate() + adjustmentDays);
  }

  const weekdayAr = ARABIC_WEEKDAYS[adjustedDate.getDay()];
  const gregorianDay = adjustedDate.getDate();
  const gregorianMonthAr = GREGORIAN_MONTHS[adjustedDate.getMonth()];
  const gregorianYear = adjustedDate.getFullYear();

  // Calibration anchor:
  // 2026-09-30 is 18 ربيع الثاني 1448
  const anchorTime = new Date(2026, 8, 30).getTime(); // Sep 30, 2026
  const diffDays = Math.round((adjustedDate.getTime() - anchorTime) / (1000 * 60 * 60 * 24));

  // Compute Hijri day by offset from anchor
  let totalHijriDays = 18 + diffDays;
  let hijriYear = 1448;
  let hijriMonthIdx = 3; // 0-indexed: 3 is ربيع الثاني

  // Month lengths alternate 30 and 29
  while (totalHijriDays < 1) {
    hijriMonthIdx--;
    if (hijriMonthIdx < 0) {
      hijriMonthIdx = 11;
      hijriYear--;
    }
    const daysInPrevMonth = hijriMonthIdx % 2 === 0 ? 30 : 29;
    totalHijriDays += daysInPrevMonth;
  }

  while (true) {
    const daysInCurrMonth = hijriMonthIdx % 2 === 0 ? 30 : 29;
    if (totalHijriDays <= daysInCurrMonth) {
      break;
    }
    totalHijriDays -= daysInCurrMonth;
    hijriMonthIdx++;
    if (hijriMonthIdx > 11) {
      hijriMonthIdx = 0;
      hijriYear++;
    }
  }

  const hijriDay = totalHijriDays;
  const hijriMonthAr = HIJRI_MONTHS[hijriMonthIdx];

  // Format exact text requested: "الأربعاء 18 ربيع الثاني 1448 - 30 سبتمبر 2026"
  const fullDateString = `${weekdayAr} ${hijriDay} ${hijriMonthAr} ${hijriYear} - ${gregorianDay} ${gregorianMonthAr} ${gregorianYear}`;

  return {
    weekdayAr,
    hijriDay,
    hijriMonthAr,
    hijriYear,
    gregorianDay,
    gregorianMonthAr,
    gregorianYear,
    fullDateString,
  };
}
