// Service to manage supervisor/admin password protection for downloading the project ZIP

const STORAGE_KEY = 'morocco_prayer_supervisor_zip_password';
const DEFAULT_SUPERVISOR_PASSWORD = '2026';

export const adminAuthService = {
  // Get current supervisor password from localStorage or fallback to default
  getSupervisorPassword(): string {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && saved.trim().length > 0) {
        return saved;
      }
    } catch {
      // ignore
    }
    return DEFAULT_SUPERVISOR_PASSWORD;
  },

  // Check if a given password matches the supervisor password
  verifyPassword(candidate: string): boolean {
    const current = this.getSupervisorPassword();
    return candidate.trim() === current.trim();
  },

  // Set a new custom password chosen by the supervisor
  setSupervisorPassword(newPassword: string): boolean {
    if (!newPassword || newPassword.trim().length < 3) {
      return false;
    }
    try {
      localStorage.setItem(STORAGE_KEY, newPassword.trim());
      return true;
    } catch {
      return false;
    }
  },

  // Reset to default password if needed
  resetToDefault(): void {
    try {
      localStorage.setItem(STORAGE_KEY, DEFAULT_SUPERVISOR_PASSWORD);
    } catch {
      // ignore
    }
  },

  // Check if custom password has been set by supervisor
  isCustomPasswordSet(): boolean {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return Boolean(saved && saved.trim() !== DEFAULT_SUPERVISOR_PASSWORD);
    } catch {
      return false;
    }
  },

  getDefaultPassword(): string {
    return DEFAULT_SUPERVISOR_PASSWORD;
  },
};
