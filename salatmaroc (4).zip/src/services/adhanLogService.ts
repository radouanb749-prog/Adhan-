// Service for logging all Adhan activities, triggers, playback status, and audio errors
// Allows user to inspect if prayer adhan played on time and check for audio playback failures.

export type AdhanLogStatus = 'success' | 'warning' | 'error' | 'muted';

export interface AdhanLogEntry {
  id: string;
  timestamp: number;
  dateFormatted: string; // e.g. "2026-10-06"
  timeFormatted: string; // e.g. "18:15:02"
  prayerId: string; // 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha' | 'test'
  prayerNameAr: string; // 'الفجر' | 'الظهر' | 'العصر' | 'المغرب' | 'العشاء' | 'تجربة صوت الأذان'
  scheduledTime?: string; // e.g. "18:15"
  delaySeconds?: number; // difference in seconds between scheduled time and trigger time
  cityNameAr?: string; // 'المحمدية'
  muezzinName: string; // 'الأذان المغربي الأصيل'
  audioUrl: string; // '/audio/adhan-morocco.mp3'
  status: AdhanLogStatus; // 'success' | 'warning' | 'error' | 'muted'
  triggerType: 'scheduled' | 'manual_test' | 'pre_alert';
  message: string;
  errorDetails?: string;
  audioSourceType?: 'local_mp3' | 'external_url' | 'synthesized_chime';
  durationSec?: number;
}

export interface AdhanLogSummary {
  total: number;
  success: number;
  error: number;
  warning: number;
  muted: number;
  lastAdhanTime?: string;
  lastAdhanPrayer?: string;
  lastStatus?: AdhanLogStatus;
}

const STORAGE_KEY = 'salat_adhan_activity_logs';
const MAX_LOGS = 80;

type LogListener = (logs: AdhanLogEntry[]) => void;

class AdhanLogService {
  private listeners: Set<LogListener> = new Set();
  private cache: AdhanLogEntry[] | null = null;

  constructor() {
    this.initDefaultIfEmpty();
  }

  private initDefaultIfEmpty(): void {
    if (typeof window === 'undefined') return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw || raw === '[]') {
        const now = new Date();
        const initialEntry: AdhanLogEntry = {
          id: `init_${Date.now()}`,
          timestamp: Date.now(),
          dateFormatted: this.formatDate(now),
          timeFormatted: this.formatTime(now),
          prayerId: 'system_init',
          prayerNameAr: 'تهيئة نظام الأذان',
          muezzinName: 'الأذان المغربي الأصيل',
          audioUrl: '/audio/adhan-morocco.mp3',
          status: 'success',
          triggerType: 'manual_test',
          message: 'تم تفعيل وجاهزية نظام مراقبة وتشغيل الأذان الصوتي بنجاح.',
          audioSourceType: 'local_mp3',
        };
        this.saveLogs([initialEntry]);
      }
    } catch {
      // ignore
    }
  }

  private formatDate(d: Date): string {
    const y = d.getUTCFullYear();
    const m = String(d.getUTCMonth() + 1).padStart(2, '0');
    const day = String(d.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  private formatTime(d: Date): string {
    // Strictly formatted in GMT+0 (توقيت غرينتش / التوقيت العالمي) matching Morocco Awqaf prayer times
    const h = String(d.getUTCHours()).padStart(2, '0');
    const min = String(d.getUTCMinutes()).padStart(2, '0');
    const sec = String(d.getUTCSeconds()).padStart(2, '0');
    return `${h}:${min}:${sec}`;
  }

  public getLogs(): AdhanLogEntry[] {
    if (this.cache) return this.cache;
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        this.cache = JSON.parse(raw);
        return this.cache || [];
      }
    } catch {
      this.cache = [];
    }
    return [];
  }

  private saveLogs(logs: AdhanLogEntry[]): void {
    this.cache = logs;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(logs));
      } catch {
        // quota exceeded fallback
      }
    }
    this.notify();
  }

  public addLog(entry: Omit<AdhanLogEntry, 'id' | 'timestamp' | 'dateFormatted' | 'timeFormatted'> & {
    id?: string;
    timestamp?: number;
    dateFormatted?: string;
    timeFormatted?: string;
  }): AdhanLogEntry {
    const now = new Date(entry.timestamp || Date.now());
    const fullEntry: AdhanLogEntry = {
      id: entry.id || `adhan_log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: entry.timestamp || now.getTime(),
      dateFormatted: entry.dateFormatted || this.formatDate(now),
      timeFormatted: entry.timeFormatted || this.formatTime(now),
      ...entry,
    };

    const currentLogs = this.getLogs();
    // Prepend new entry
    const updated = [fullEntry, ...currentLogs.filter((item) => item.id !== fullEntry.id)].slice(0, MAX_LOGS);
    this.saveLogs(updated);
    return fullEntry;
  }

  public updateLog(id: string, updates: Partial<AdhanLogEntry>): void {
    const currentLogs = this.getLogs();
    const updated = currentLogs.map((item) => {
      if (item.id === id) {
        return { ...item, ...updates };
      }
      return item;
    });
    this.saveLogs(updated);
  }

  public clearLogs(): void {
    this.saveLogs([]);
  }

  public getSummary(): AdhanLogSummary {
    const logs = this.getLogs();
    const total = logs.length;
    let success = 0;
    let error = 0;
    let warning = 0;
    let muted = 0;

    logs.forEach((log) => {
      if (log.status === 'success') success++;
      else if (log.status === 'error') error++;
      else if (log.status === 'warning') warning++;
      else if (log.status === 'muted') muted++;
    });

    const last = logs[0];

    return {
      total,
      success,
      error,
      warning,
      muted,
      lastAdhanTime: last ? `${last.timeFormatted} (${last.prayerNameAr})` : undefined,
      lastAdhanPrayer: last ? last.prayerNameAr : undefined,
      lastStatus: last ? last.status : undefined,
    };
  }

  public subscribe(listener: LogListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    const logs = this.getLogs();
    this.listeners.forEach((listener) => {
      try {
        listener(logs);
      } catch {
        // ignore
      }
    });
  }
}

export const adhanLogService = new AdhanLogService();
