export interface MosqueSuitability {
  status: 'optimal' | 'moderate' | 'difficult';
  badge: string;
  advice: string;
  hadithQuote?: string;
}

export interface WeatherConditionInfo {
  temp: number;
  conditionText: string;
  weatherCode: number;
  humidity: number;
  windSpeed: number;
  precipitation: number;
  isDay: boolean;
  mosqueSuitability: MosqueSuitability;
}

// Map WMO codes to Arabic descriptions and day/night status
function getConditionDescription(code: number, isDay: boolean): string {
  switch (code) {
    case 0:
      return isDay ? 'صحو مشمس' : 'سماء صافية';
    case 1:
      return isDay ? 'صافٍ غالباً' : 'صحو مع بعض السحب';
    case 2:
      return 'قليل الغيوم';
    case 3:
      return 'غائم جزئياً';
    case 45:
    case 48:
      return 'ضبابي';
    case 51:
    case 53:
    case 55:
      return 'رذاذ خفيف';
    case 56:
    case 57:
      return 'رذاذ بارد متجمد';
    case 61:
      return 'أمطار خفيفة';
    case 63:
      return 'أمطار متوسطة';
    case 65:
      return 'أمطار غزيرة 🌧️';
    case 66:
    case 67:
      return 'أمطار جليدية';
    case 71:
    case 73:
    case 75:
    case 77:
      return 'تساقط ثلوج ❄️';
    case 80:
    case 81:
    case 82:
      return 'زخات مطرية 🌦️';
    case 85:
    case 86:
      return 'زخات ثلجية';
    case 95:
      return 'عاصفة رعدية ⚡';
    case 96:
    case 99:
      return 'عاصفة رعدية مع برد ⛈️';
    default:
      return 'أجواء مستقرة';
  }
}

// Evaluate Islamic guidance & mosque prayer suitability
function evaluateMosqueSuitability(
  code: number,
  temp: number,
  windSpeed: number,
  precipitation: number
): MosqueSuitability {
  // Severe weather (heavy rain, thunderstorms, extreme winds)
  const isHeavyRain = [65, 82, 95, 96, 99].includes(code) || precipitation >= 4.0;
  const isSevereStorm = code >= 95 || windSpeed >= 50;

  if (isHeavyRain || isSevereStorm) {
    return {
      status: 'difficult',
      badge: 'رخصة الصلاة بالبيت 🌧️',
      advice: 'أجواء ماطرة أو عاصفة؛ ثبتت الرخصة الشرعية بصلاة الفريضة في البيت والمنازل دفعاً للمشقة.',
      hadithQuote: 'قال النبي ﷺ لمناديه في ليلة مطيرة: «أَلا صَلُّوا في رِحالِكُمْ» (متفق عليه)',
    };
  }

  // Light rain or cold weather or moderate wind
  const isLightRain = [51, 53, 55, 61, 63, 80, 81].includes(code) || precipitation > 0.3;
  const isVeryCold = temp <= 6;
  const isVeryHot = temp >= 39;

  if (isLightRain) {
    return {
      status: 'moderate',
      badge: 'اصطحب مظلة ☂️',
      advice: 'هطول رذاذ أو أمطار خفيفة؛ يُستحب إدراك الجماعة بالمسجد مع اصطحاب مظلة واحتياط الطريق.',
      hadithQuote: '«أَلَا أَدُلُّكُمْ عَلَى مَا يَمْحُو اللَّهُ بِهِ الْخَطَايَا... إِسْبَاغُ الْوُضُوءِ عَلَى الْمَكَارِهِ، وَكَثْرَةُ الْخُطَا إِلَى الْمَسَاجِدِ»',
    };
  }

  if (isVeryCold) {
    return {
      status: 'moderate',
      badge: 'أجواء باردة 🧥',
      advice: 'الطقس بارد؛ يُنصح بارتداء لباس شتوي دافئ عند الخروج لصلاة الفجر والعشاء بالمسجد.',
      hadithQuote: '«بَشِّرِ الْمَشَّائِينَ فِي الظُّلَمِ إِلَى الْمَسَاجِدِ بِالنُّورِ التَّامِّ يَوْمَ الْقِيَامَةِ»',
    };
  }

  if (isVeryHot) {
    return {
      status: 'moderate',
      badge: 'حرارة مرتفعة ☀️',
      advice: 'الحرارة مرتفعة؛ يُنصح بالمشي في الظل والتزود بالماء لصلاة الظهر والعصر.',
      hadithQuote: '«إِذَا اشْتَدَّ الْحَرُّ فَأَبْرِدُوا بِالصَّلَاةِ، فَإِنَّ شِدَّةَ الْحَرِّ مِنْ فَيْحِ جَهَنَّمَ»',
    };
  }

  // Default: Optimal, great weather for walking to the mosque
  return {
    status: 'optimal',
    badge: 'مناسبة للمسجد 🕌',
    advice: 'الأجواء معتدلة ولطيفة ومثالية للمشي إلى المسجد ونيل فضل صلاة الجماعة.',
    hadithQuote: '«صَلَاةُ الْجَمَاعَةِ تَفْضُلُ صَلَاةَ الْفَذِّ بِسَبْعٍ وَعِشْرِينَ دَرَجَةً»',
  };
}

// In-memory cache by lat_lng
const weatherCache = new Map<string, { data: WeatherConditionInfo; fetchedAt: number }>();
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes

export async function fetchLocalWeather(
  latitude: number,
  longitude: number
): Promise<WeatherConditionInfo> {
  const cacheKey = `${latitude.toFixed(2)}_${longitude.toFixed(2)}`;
  const cached = weatherCache.get(cacheKey);
  const now = Date.now();

  if (cached && now - cached.fetchedAt < CACHE_TTL_MS) {
    return cached.data;
  }

  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,precipitation,is_day&timezone=auto`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Weather API error: ${res.status}`);

    const json = await res.json();
    const current = json.current;

    const temp = Math.round(current.temperature_2m ?? 22);
    const humidity = Math.round(current.relative_humidity_2m ?? 60);
    const weatherCode = Number(current.weather_code ?? 0);
    const windSpeed = Math.round(current.wind_speed_10m ?? 10);
    const precipitation = Number(current.precipitation ?? 0);
    const isDay = current.is_day === 1;

    const conditionText = getConditionDescription(weatherCode, isDay);
    const mosqueSuitability = evaluateMosqueSuitability(
      weatherCode,
      temp,
      windSpeed,
      precipitation
    );

    const result: WeatherConditionInfo = {
      temp,
      conditionText,
      weatherCode,
      humidity,
      windSpeed,
      precipitation,
      isDay,
      mosqueSuitability,
    };

    weatherCache.set(cacheKey, { data: result, fetchedAt: now });
    return result;
  } catch (err) {
    console.warn('[weatherService] Fallback to default pleasant weather:', err);

    // Fallback if offline or network error
    const fallback: WeatherConditionInfo = {
      temp: 23,
      conditionText: 'معتدل ومستقر',
      weatherCode: 0,
      humidity: 65,
      windSpeed: 12,
      precipitation: 0,
      isDay: true,
      mosqueSuitability: {
        status: 'optimal',
        badge: 'مناسبة للمسجد 🕌',
        advice: 'الأجواء معتدلة ومناسبة للمشي إلى المسجد ونيل أجر صلاة الجماعة.',
        hadithQuote: '«صَلَاةُ الْجَمَاعَةِ تَفْضُلُ صَلَاةَ الْفَذِّ بِسَبْعٍ وَعِشْرِينَ دَرَجَةً»',
      },
    };
    return fallback;
  }
}
