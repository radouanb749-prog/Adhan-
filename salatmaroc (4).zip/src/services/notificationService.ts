import { audioAdhanService } from './audioAdhan';
import { adhanLogService } from './adhanLogService';
import { nativeAlarmBridge } from './nativeAlarmBridge';
import { MUEZZINS_LIST, MuezzinItem } from '../data/muezzinsData';

export interface PrePrayerAlertData {
  id: string;
  prayerNameAr: string;
  cityNameAr: string;
  minutesRemaining: number;
  prayerTime: string;
  timestamp: number;
  adhanUrl?: string;
}

export interface DhikrReminderData {
  id: string;
  type: 'morning' | 'evening';
  title: string;
  body: string;
  timestamp: number;
}

type AlertCallback = (alert: PrePrayerAlertData) => void;
type DhikrListener = (data: DhikrReminderData) => void;

class NotificationService {
  private alertListeners: AlertCallback[] = [];
  private dhikrListeners: DhikrListener[] = [];
  private triggeredAlerts: Set<string> = new Set(); // Prevent duplicate alerts in same session
  private userDismissedAdhanKeys: Set<string> = new Set(); // Prevent repeating stopped adhan
  private lastActiveAdhanKey: string | null = null;
  private preloadedUrls: Set<string> = new Set();
  private currentAdhanAudio: HTMLAudioElement | null = null; // Direct reference to active Adhan audio element

  constructor() {
    this.loadPersistedKeys();
  }

  private loadPersistedKeys() {
    try {
      if (typeof localStorage !== 'undefined') {
        const savedAlerts = localStorage.getItem('salat_triggered_adhan_keys');
        if (savedAlerts) {
          const parsed = JSON.parse(savedAlerts);
          if (Array.isArray(parsed)) {
            this.triggeredAlerts = new Set(parsed);
          }
        }
        const savedDismissed = localStorage.getItem('salat_dismissed_adhan_keys');
        if (savedDismissed) {
          const parsed = JSON.parse(savedDismissed);
          if (Array.isArray(parsed)) {
            this.userDismissedAdhanKeys = new Set(parsed);
          }
        }
      }
    } catch {}
  }

  private persistTriggeredKey(key: string) {
    try {
      if (typeof localStorage !== 'undefined') {
        const arr = Array.from(this.triggeredAlerts).slice(-60);
        localStorage.setItem('salat_triggered_adhan_keys', JSON.stringify(arr));
      }
    } catch {}
  }

  private persistDismissedKey(key: string) {
    try {
      if (typeof localStorage !== 'undefined') {
        const arr = Array.from(this.userDismissedAdhanKeys).slice(-60);
        localStorage.setItem('salat_dismissed_adhan_keys', JSON.stringify(arr));
      }
    } catch {}
  }

  // Helper to accurately resolve the chosen Muezzin from MUEZZINS_LIST by ID or URL
  public resolveMuezzin(muezzinIdOrUrl?: string, isFajr: boolean = false): MuezzinItem {
    if (!muezzinIdOrUrl) {
      if (isFajr) {
        return MUEZZINS_LIST.find((m) => m.id === 'makkah_fajr') || MUEZZINS_LIST[0];
      }
      return MUEZZINS_LIST[0]; // 'moroccan_traditional' default
    }

    // Match by ID
    const byId = MUEZZINS_LIST.find((m) => m.id === muezzinIdOrUrl);
    if (byId) return byId;

    // Match by Audio URL
    const byUrl = MUEZZINS_LIST.find((m) => m.audioUrl === muezzinIdOrUrl);
    if (byUrl) return byUrl;

    // Fallback to Moroccan Traditional Adhan
    return MUEZZINS_LIST[0];
  }

  // Preload upcoming Adhan audio to guarantee 0ms instant playback when prayer enters
  public preloadUpcomingAdhan(muezzinIdOrUrl?: string, isFajr: boolean = false) {
    try {
      const muezzin = this.resolveMuezzin(muezzinIdOrUrl, isFajr);
      if (!this.preloadedUrls.has(muezzin.audioUrl)) {
        this.preloadedUrls.add(muezzin.audioUrl);
        const preAudio = new Audio();
        preAudio.preload = 'auto';
        preAudio.src = muezzin.audioUrl;
      }
    } catch {
      // ignore
    }
  }

  // Check if browser notifications are supported
  public isSupported(): boolean {
    return typeof window !== 'undefined' && 'Notification' in window;
  }

  // Get current permission status
  public getPermissionStatus(): NotificationPermission | 'unsupported' {
    if (!this.isSupported()) return 'unsupported';
    return Notification.permission;
  }

  // Request browser permission
  public async requestPermission(): Promise<NotificationPermission | 'unsupported'> {
    if (!this.isSupported()) return 'unsupported';
    try {
      const permission = await Notification.requestPermission();
      return permission;
    } catch {
      return Notification.permission;
    }
  }

  // Subscribe to in-app alert banner
  public onAlert(callback: AlertCallback): () => void {
    this.alertListeners.push(callback);
    return () => {
      this.alertListeners = this.alertListeners.filter((cb) => cb !== callback);
    };
  }

  // Fire notification (both native browser push notification + in-app alert banner + audio)
  public triggerAlert(data: PrePrayerAlertData, playSound: boolean = true) {
    const alertKey = `${data.prayerNameAr}-${data.prayerTime}-${data.minutesRemaining}`;
    if (this.triggeredAlerts.has(alertKey)) {
      return; // Already notified
    }
    this.triggeredAlerts.add(alertKey);

    // 1. Play real adhan or reminder chime
    if (playSound) {
      if (data.adhanUrl) {
        audioAdhanService.playRealAdhan(
          data.adhanUrl,
          'alert_' + alertKey,
          `أذان ${data.prayerNameAr}`,
          data.cityNameAr
        );
      } else {
        audioAdhanService.playAdhanChime();
      }
    }

    // 2. Vibrate phone
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 200, 100, 300]);
    }

    // 3. Native Browser Push Notification
    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        const title = `اقتراب صلاة ${data.prayerNameAr} (${data.prayerTime})`;
        const body = `بقي ${data.minutesRemaining} دقائق على موعد أذان ${data.prayerNameAr} في مدينة ${data.cityNameAr}. استعد للوضوء والصلاة.`;

        const notification = new Notification(title, {
          body,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: alertKey,
          requireInteraction: true,
        });

        notification.onclick = () => {
          window.focus();
          notification.close();
        };
      } catch (err) {
        console.warn('Native notification failed, using in-app alert banner:', err);
      }
    }

    // 4. In-App alert banner for immediate visibility in UI
    this.alertListeners.forEach((listener) => {
      try {
        listener(data);
      } catch {
        // ignore
      }
    });
  }

  // Trigger full official Adhan when prayer enters (0 minutes / exact prayer time)
  public triggerActualPrayerAdhan(
    prayerId: string,
    prayerNameAr: string,
    prayerTime: string,
    cityNameAr: string,
    muezzinIdOrUrl: string,
    customMuezzinName?: string,
    playSound: boolean = true
  ): boolean {
    const now = new Date();
    const todayKey = `${now.getUTCFullYear()}-${String(now.getUTCMonth() + 1).padStart(2, '0')}-${String(
      now.getUTCDate()
    ).padStart(2, '0')}`;
    const adhanKey = `actual_adhan_${prayerId}_${prayerTime}_${todayKey}`;

    if (this.triggeredAlerts.has(adhanKey) || this.userDismissedAdhanKeys.has(adhanKey)) {
      return false; // Already played or explicitly dismissed for this prayer today
    }
    this.triggeredAlerts.add(adhanKey);
    this.persistTriggeredKey(adhanKey);
    this.lastActiveAdhanKey = adhanKey;

    // 1. Resolve exact Muezzin from MUEZZINS_LIST
    const isFajr = prayerId === 'fajr';
    const muezzin = this.resolveMuezzin(muezzinIdOrUrl, isFajr);
    const title = `أذان صلاة ${prayerNameAr}`;
    const muezzinDisplayName =
      customMuezzinName || muezzin.nameAr || muezzin.muezzinName;

    // 2. Play the chosen Adhan audio
    if (playSound) {
      audioAdhanService.playRealAdhan(
        muezzin.audioUrl,
        adhanKey,
        title,
        muezzinDisplayName,
        {
          prayerId,
          prayerNameAr,
          scheduledTime: prayerTime,
          cityNameAr,
          triggerType: 'scheduled',
        }
      );
      this.currentAdhanAudio = audioAdhanService.getCurrentAudioElement();
      console.log(
        '[notificationService] triggerActualPrayerAdhan stored active audio element:',
        this.currentAdhanAudio
      );
    } else {
      // User explicitly turned off Adhan sound for this prayer in settings
      adhanLogService.addLog({
        id: `adhan_muted_${adhanKey}`,
        prayerId,
        prayerNameAr,
        scheduledTime: prayerTime,
        cityNameAr,
        muezzinName: muezzinDisplayName,
        audioUrl: muezzin.audioUrl,
        status: 'muted',
        triggerType: 'scheduled',
        message: `حان موعد صلاة ${prayerNameAr} (${prayerTime}) ولكن تم كتم الأذان بناءً على إعداداتك المخصصة لهذه الصلاة.`,
      });
    }

    // 3. Vibrate phone with Islamic cadence (effective when phone is on silent mode)
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([600, 250, 600, 250, 1000, 400, 1200, 400, 1500]);
      } catch {
        // ignore
      }
    }

    // 4. Native Browser & Service Worker Push Notification (shows on lock screen)
    if (this.isSupported() && Notification.permission === 'granted') {
      const notificationTitle = prayerNameAr; // e.g. "المغرب" exactly like the screenshot
      const body = `حان موعد أذان صلاة ${prayerNameAr}`;

      const notificationOptions: any = {
        body,
        icon: '/pwa-192x192.png',
        badge: '/favicon-48x48.png',
        tag: adhanKey,
        requireInteraction: true,
        silent: false,
        renotify: true,
        vibrate: [600, 250, 600, 250, 1000, 400, 1200, 400, 1500],
        sound: muezzin.audioUrl || '/audio/adhan-morocco.mp3',
        actions: [
          {
            action: 'stop_adhan',
            title: 'Stop Adhan',
          },
        ],
      };

      try {
        const notification = new Notification(notificationTitle, notificationOptions);
        notification.onclick = () => {
          window.focus();
          notification.close();
        };
      } catch (err) {
        console.warn('Native notification fallback error:', err);
      }
    }

    // 5. In-App alert banner
    this.alertListeners.forEach((listener) => {
      try {
        listener({
          id: adhanKey,
          prayerNameAr,
          cityNameAr,
          minutesRemaining: 0,
          prayerTime,
          timestamp: Date.now(),
          adhanUrl: muezzin.audioUrl,
        });
      } catch {
        // ignore
      }
    });

    return true;
  }

  // Get active audio element reference if currently playing
  public getCurrentAudio(): HTMLAudioElement | null {
    const audio = this.currentAdhanAudio || audioAdhanService.getCurrentAudioElement();
    console.log('[notificationService] getCurrentAudio returned:', audio);
    return audio;
  }

  // Stop active Adhan and pause HTMLAudioElement reference directly
  public stopAdhan(): boolean {
    console.log('[notificationService] stopAdhan() called');
    let directlyPaused = false;

    // Record user dismissal for this prayer so it can NEVER repeat today
    if (this.lastActiveAdhanKey) {
      this.userDismissedAdhanKeys.add(this.lastActiveAdhanKey);
      this.persistDismissedKey(this.lastActiveAdhanKey);
    }

    // 1. Pause directly through stored audio element reference
    if (this.currentAdhanAudio) {
      try {
        console.log(
          '[notificationService] Pausing this.currentAdhanAudio directly (paused before:',
          this.currentAdhanAudio.paused,
          'currentTime:',
          this.currentAdhanAudio.currentTime,
          ')'
        );
        this.currentAdhanAudio.onerror = null;
        this.currentAdhanAudio.onended = null;
        this.currentAdhanAudio.ontimeupdate = null;
        this.currentAdhanAudio.pause();
        this.currentAdhanAudio.currentTime = 0;
        directlyPaused = true;
        console.log('[notificationService] Successfully paused this.currentAdhanAudio directly');
      } catch (err) {
        console.warn('[notificationService] Error pausing currentAdhanAudio:', err);
      }
      this.currentAdhanAudio = null;
    }

    // 2. Also check audioAdhanService reference
    const serviceAudio = audioAdhanService.getCurrentAudioElement();
    if (serviceAudio && !serviceAudio.paused) {
      try {
        console.log('[notificationService] Pausing audioAdhanService.getCurrentAudioElement() directly');
        serviceAudio.onerror = null;
        serviceAudio.onended = null;
        serviceAudio.ontimeupdate = null;
        serviceAudio.pause();
        serviceAudio.currentTime = 0;
        directlyPaused = true;
      } catch (err) {
        console.warn('[notificationService] Error pausing service audio element:', err);
      }
    }

    // 3. Stop all audio and WebAudio synthesizers in audioAdhanService
    const stoppedService = audioAdhanService.stopAll();

    // 4. Immediately stop native Android background service and dismiss lock screen
    try {
      nativeAlarmBridge.stopAdhan();
    } catch {}

    // 5. Immediately cancel any active phone vibration
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(0);
      } catch {}
    }

    console.log(
      '[notificationService] stopAdhan completed. directlyPaused:',
      directlyPaused,
      'audioAdhanService.stopAll returned:',
      stoppedService
    );
    return directlyPaused || stoppedService;
  }

  // Test notification function for the user to try instantly
  public triggerTestNotification(cityNameAr: string = 'المحمدية', adhanUrl?: string) {
    this.triggerAlert(
      {
        id: 'test_' + Date.now(),
        prayerNameAr: 'العصر',
        cityNameAr,
        minutesRemaining: 5,
        prayerTime: '15:42',
        timestamp: Date.now(),
        adhanUrl,
      },
      true
    );
  }

  // Subscribe to in-app Dhikr reminder events
  public onDhikrReminder(callback: DhikrListener): () => void {
    this.dhikrListeners.push(callback);
    return () => {
      this.dhikrListeners = this.dhikrListeners.filter((cb) => cb !== callback);
    };
  }

  // Fire gentle morning / evening Dhikr reminder
  public triggerDhikrReminder(type: 'morning' | 'evening', playSound: boolean = true) {
    const today = new Date().toDateString();
    const alertKey = `dhikr_${type}_${today}`;
    if (this.triggeredAlerts.has(alertKey)) {
      return; // Already notified today
    }
    this.triggeredAlerts.add(alertKey);

    const isMorning = type === 'morning';
    const title = isMorning ? 'أذكار الصباح ☀️' : 'أذكار المساء 🌙';
    const body = isMorning
      ? 'أصبحنا وأصبح الملك لله، والحمد لله.. حان موعد قراءة أذكار الصباح لتحصين نفسك وبركة يومك.'
      : 'أمسينا وأمسى الملك لله، والحمد لله.. حان موعد قراءة أذكار المساء لتحصين نفسك والسكينة.';

    // 1. Play serene gentle chime
    if (playSound) {
      audioAdhanService.playGentleDhikrChime();
    }

    // 2. Gentle vibration pulse
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([100, 80, 120]);
      } catch {}
    }

    // 3. Native Browser Notification
    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        const notification = new Notification(title, {
          body,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: alertKey,
        });

        notification.onclick = () => {
          window.focus();
          notification.close();
        };
      } catch (err) {
        console.warn('Dhikr native notification error:', err);
      }
    }

    // 4. In-App alert listeners
    const data: DhikrReminderData = {
      id: alertKey,
      type,
      title,
      body,
      timestamp: Date.now(),
    };
    this.dhikrListeners.forEach((listener) => {
      try {
        listener(data);
      } catch (err) {
        console.warn('Dhikr listener error:', err);
      }
    });
  }

  // Instant test function for Dhikr reminder
  public triggerTestDhikrReminder(type: 'morning' | 'evening' = 'morning') {
    const isMorning = type === 'morning';
    const title = isMorning ? 'تنبيه أذكار الصباح ☀️' : 'تنبيه أذكار المساء 🌙';
    const body = isMorning
      ? 'أصبحنا وأصبح الملك لله.. حان موعد قراءة أذكار الصباح المباركة.'
      : 'أمسينا وأمسى الملك لله.. حان موعد قراءة أذكار المساء المباركة.';

    audioAdhanService.playGentleDhikrChime();

    if (this.isSupported() && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
        });
      } catch {}
    }

    const testData: DhikrReminderData = {
      id: 'test_dhikr_' + Date.now(),
      type,
      title,
      body,
      timestamp: Date.now(),
    };
    this.dhikrListeners.forEach((l) => l(testData));
  }
}

export const notificationService = new NotificationService();
