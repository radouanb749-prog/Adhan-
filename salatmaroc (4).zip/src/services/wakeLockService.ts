/**
 * Wake Lock Service
 * Uses the Screen Wake Lock API to prevent mobile and desktop browsers
 * from putting the tab into a deep sleep state, ensuring on-time Adhan alarms.
 */

type WakeLockListener = (isActive: boolean) => void;

class WakeLockService {
  private sentinel: any = null;
  private isEnabled: boolean = true;
  private listeners: Set<WakeLockListener> = new Set();

  constructor() {
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', () => {
        // When tab or phone screen is unlocked, re-acquire wake lock if enabled
        if (document.visibilityState === 'visible' && this.isEnabled && !this.sentinel) {
          this.requestLock();
        }
      });
    }
  }

  public isSupported(): boolean {
    return typeof navigator !== 'undefined' && 'wakeLock' in navigator;
  }

  public async setEnabled(enabled: boolean): Promise<boolean> {
    this.isEnabled = enabled;
    if (enabled) {
      return await this.requestLock();
    } else {
      this.releaseLock();
      return false;
    }
  }

  public async requestLock(): Promise<boolean> {
    if (!this.isSupported() || !this.isEnabled) {
      return false;
    }

    try {
      if (this.sentinel) {
        return true;
      }

      this.sentinel = await navigator.wakeLock.request('screen');

      this.sentinel.addEventListener('release', () => {
        this.sentinel = null;
        this.notifyListeners(false);
      });

      this.notifyListeners(true);
      return true;
    } catch (err: any) {
      // Could fail if tab is not visible or battery is critically low
      console.warn('[wakeLockService] Request failed:', err?.message || err);
      this.sentinel = null;
      this.notifyListeners(false);
      return false;
    }
  }

  public releaseLock() {
    if (this.sentinel) {
      try {
        this.sentinel.release().catch(() => {});
      } catch {}
      this.sentinel = null;
      this.notifyListeners(false);
    }
  }

  public isActive(): boolean {
    return !!this.sentinel;
  }

  public subscribe(listener: WakeLockListener): () => void {
    this.listeners.add(listener);
    listener(this.isActive());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(active: boolean) {
    this.listeners.forEach((listener) => {
      try {
        listener(active);
      } catch {}
    });
  }
}

export const wakeLockService = new WakeLockService();
