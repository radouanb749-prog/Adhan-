/**
 * Background Adhan Scheduler Service
 * Replaces unreliable Web Workers / setInterval / new Audio() loops
 * Directly calculates upcoming prayer time and schedules exact native Adhan
 * via @capacitor/local-notifications (scheduleNativeAdhan)
 */

import { scheduleNativeAdhan, PrayerScheduleItem } from './nativeAlarmBridge';
import { calculatePrayerTimes, getNextPrayer, PrayerOffsets } from './prayerCalculation';
import { DEFAULT_CITY } from '../data/moroccoCities';
import { CityData, SettingsState } from '../types/prayer';

class BackgroundTimerService {
  private wakeLockSentinel: any = null;

  /**
   * Calculates upcoming prayer time based on saved user settings and city,
   * then calls scheduleNativeAdhan directly.
   */
  public async scheduleNextAdhan(
    customCity?: CityData,
    customOffsets?: PrayerOffsets,
    timezoneMode: 'gmt' | 'gmt+1' = 'gmt'
  ): Promise<{ prayerName: string; triggerDate: Date } | null> {
    try {
      let city = customCity;
      if (!city && typeof localStorage !== 'undefined') {
        const savedCity = localStorage.getItem('salat_selected_city');
        if (savedCity) {
          try {
            city = JSON.parse(savedCity);
          } catch {}
        }
      }
      if (!city) {
        city = DEFAULT_CITY;
      }

      let offsets = customOffsets;
      if (!offsets && typeof localStorage !== 'undefined') {
        const savedSettings = localStorage.getItem('salat_user_settings');
        if (savedSettings) {
          try {
            const s: SettingsState = JSON.parse(savedSettings);
            offsets = {
              fajr: s.fajrOffset,
              sunrise: s.sunriseOffset,
              dhuhr: s.dhuhrOffset,
              asr: s.asrOffset,
              maghrib: s.maghribOffset,
              isha: s.ishaOffset,
            };
          } catch {}
        }
      }

      const now = new Date();
      const tzOffsetHours = timezoneMode === 'gmt+1' ? 1 : 0;
      const todayDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const tomorrowDate = new Date(todayDate);
      tomorrowDate.setDate(tomorrowDate.getDate() + 1);

      const todayPrayers = calculatePrayerTimes(todayDate, city, timezoneMode, offsets);
      const tomorrowPrayers = calculatePrayerTimes(tomorrowDate, city, timezoneMode, offsets);

      const nextInfo = getNextPrayer(todayPrayers, now.getTime(), timezoneMode, tomorrowPrayers);
      if (!nextInfo || !nextInfo.nextPrayer) {
        return null;
      }

      const nextPrayer = nextInfo.nextPrayer;
      const [h, m] = nextPrayer.time.split(':').map(Number);

      // Determine whether the target prayer occurs today or tomorrow (e.g. Fajr after Isha)
      const isTomorrow = nextInfo.diffSeconds > (24 * 3600 - 300) || nextPrayer.id === 'fajr' && now.getUTCHours() + tzOffsetHours >= 20;
      const targetDate = isTomorrow ? tomorrowDate : todayDate;

      const triggerUtcMillis = Date.UTC(
        targetDate.getFullYear(),
        targetDate.getMonth(),
        targetDate.getDate(),
        h - tzOffsetHours,
        m,
        0,
        0
      );
      const triggerDate = new Date(triggerUtcMillis);

      // Call scheduleNativeAdhan via @capacitor/local-notifications on azan-channel
      await scheduleNativeAdhan(nextPrayer.nameAr, triggerDate, 1001);

      console.log(`[BackgroundTimer] Calculated and scheduled next native Adhan: ${nextPrayer.nameAr} at ${triggerDate.toLocaleTimeString()}`);
      return { prayerName: nextPrayer.nameAr, triggerDate };
    } catch (err) {
      console.warn('[BackgroundTimer] scheduleNextAdhan error:', err);
      return null;
    }
  }

  public async acquireWakeLock() {
    try {
      if (typeof navigator !== 'undefined' && 'wakeLock' in navigator && !this.wakeLockSentinel) {
        this.wakeLockSentinel = await navigator.wakeLock.request('screen');
        this.wakeLockSentinel.addEventListener('release', () => {
          this.wakeLockSentinel = null;
        });
      }
    } catch {}
  }

  public releaseWakeLock() {
    if (this.wakeLockSentinel) {
      try {
        this.wakeLockSentinel.release().catch(() => {});
      } catch {}
      this.wakeLockSentinel = null;
    }
  }

  /**
   * Start hook: triggers scheduleNextAdhan directly without running any setInterval or new Audio
   */
  public start(callback?: () => void) {
    this.scheduleNextAdhan().then(() => {
      if (callback) {
        try {
          callback();
        } catch {}
      }
    });

    return () => {
      this.stop();
    };
  }

  public stop() {
    this.releaseWakeLock();
  }
}

export const backgroundTimerService = new BackgroundTimerService();
