/**
 * Native Android Alarm Bridge
 * - Schedules background adhan alarms via @capacitor/local-notifications on channel 'azan-channel'
 * - High priority (importance 5) with sound 'azan.mp3'
 * - Interfaces with AndroidAdhan JavascriptInterface if running in custom native shell
 * - No new Audio() or setInterval() used
 */

import { LocalNotifications } from '@capacitor/local-notifications';

declare global {
  interface Window {
    AndroidAdhan?: {
      schedulePrayerAlarm: (prayerId: string, prayerName: string, triggerAtMillis: number, isFajr: boolean) => void;
      scheduleTestAlarm?: (delayMillis: number) => void;
      cancelPrayerAlarm: (prayerId: string) => void;
      updateLocation?: (cityName: string, lat: number, lng: number, timezoneMode: string) => void;
      setAllowInSilentMode?: (enabled: boolean) => void;
      isAllowInSilentMode?: () => boolean;
      setSilentModeEnabled?: (isEnabled: boolean) => void;
      isSilentModeEnabled?: () => boolean;
      setAdhanAlertMethod?: (method: string) => void;
      getAdhanAlertMethod?: () => string;
      stopAdhan?: () => void;
      isAdhanPlaying?: () => boolean;
      setShakeToStopConfig?: (enabled: boolean, sensitivity: number) => void;
      isDndAccessGranted?: () => boolean;
      getCurrentInterruptionFilter?: () => number;
      setInterruptionFilter?: (filter: number) => boolean;
      beginTemporaryDndBypass?: () => number;
      restoreDndFilter?: () => boolean;
      isIgnoringBatteryOptimizations?: () => boolean;
      canScheduleExactAlarms?: () => boolean;
      canUseFullScreenIntent?: () => boolean;
      isAndroid12OrHigher?: () => boolean;
      requestDndAccess?: () => void;
      requestBatteryExemption?: () => void;
      requestExactAlarmPermission?: () => void;
      requestFullScreenIntentPermission?: () => void;
    };
  }
}

export const INTERRUPTION_FILTER = {
  UNKNOWN: 0,
  ALL: 1,
  PRIORITY: 2,
  NONE: 3,
  ALARMS: 4,
} as const;

let savedOriginalInterruptionFilter: number | null = null;

export interface PrayerScheduleItem {
  id: string;
  nameAr: string;
  time: string; // HH:mm
}

const PRAYER_NOTIFICATION_IDS: Record<string, number> = {
  fajr: 101,
  dhuhr: 102,
  asr: 103,
  maghrib: 104,
  isha: 105,
};

/**
 * Initializes the high-importance notification channel for Adhan
 */
export async function initAdhanChannel(): Promise<void> {
  try {
    await LocalNotifications.createChannel({
      id: 'azan-channel',
      name: 'الأذان',
      description: 'أذان الصلاة بأعلى أولوية وصوت الأذان',
      importance: 5,
      sound: 'azan.mp3',
      visibility: 1,
      vibration: true,
    });
    console.log('[nativeAlarmBridge] azan-channel created with importance 5 & sound azan.mp3');
  } catch (err) {
    console.warn('[nativeAlarmBridge] initAdhanChannel warning:', err);
  }
}

/**
 * Requests notification permissions from the user
 */
export async function requestAdhanPermissions(): Promise<boolean> {
  try {
    const res = await LocalNotifications.requestPermissions();
    return res.display === 'granted';
  } catch (err) {
    console.warn('[nativeAlarmBridge] requestAdhanPermissions warning:', err);
    return false;
  }
}

/**
 * Schedules a native Adhan local notification via @capacitor/local-notifications
 * Channel: azan-channel, Importance: 5, Sound: azan.mp3
 */
export async function scheduleNativeAdhan(
  prayerName: string,
  at: Date,
  id: number = 1001
): Promise<void> {
  try {
    await initAdhanChannel();

    // Remove existing pending notification with the same ID if any
    try {
      await LocalNotifications.cancel({ notifications: [{ id }] });
    } catch {}

    await LocalNotifications.schedule({
      notifications: [
        {
          id,
          title: `حان الآن موعد أذان ${prayerName}`,
          body: `حي على الصلاة، حي على الفلاح - صلاة ${prayerName}`,
          schedule: { at, allowWhileIdle: true },
          sound: 'azan.mp3',
          channelId: 'azan-channel',
          extra: { prayerName, at: at.toISOString() },
        },
      ],
    });
    console.log(`[nativeAlarmBridge] scheduleNativeAdhan scheduled: ${prayerName} at ${at.toLocaleString()}`);
  } catch (err) {
    console.warn('[nativeAlarmBridge] scheduleNativeAdhan error:', err);
  }
}

export const nativeAlarmBridge = {
  isAvailable(): boolean {
    return typeof window !== 'undefined' && !!window.AndroidAdhan;
  },

  initAdhanChannel,
  requestAdhanPermissions,
  scheduleNativeAdhan,

  async scheduleDailyPrayers(
    prayers: PrayerScheduleItem[],
    targetDate: Date,
    tomorrowPrayers?: PrayerScheduleItem[],
    timezoneMode: 'gmt' | 'gmt+1' = 'gmt'
  ) {
    const now = Date.now();
    const tzOffsetHours = timezoneMode === 'gmt+1' ? 1 : 0;
    const y = targetDate.getFullYear();
    const mon = targetDate.getMonth();
    const d = targetDate.getDate();

    const hasNativeBridge = this.isAvailable();

    if (hasNativeBridge) {
      // Cancel any Capacitor LocalNotifications prayer IDs to avoid duplicate notifications or overlapping sound
      try {
        const idsToCancel = [...Object.values(PRAYER_NOTIFICATION_IDS), 9999].map((id) => ({ id }));
        await LocalNotifications.cancel({ notifications: idsToCancel });
      } catch {}
    } else {
      await initAdhanChannel();
    }

    for (const prayer of prayers) {
      if (prayer.id === 'sunrise') continue;

      const [h, m] = prayer.time.split(':').map(Number);
      let triggerMillis = Date.UTC(y, mon, d, h - tzOffsetHours, m, 0, 0);

      // If prayer already passed today, schedule for tomorrow
      if (triggerMillis <= now) {
        let th = h;
        let tm = m;
        if (tomorrowPrayers) {
          const tomPrayer = tomorrowPrayers.find((p) => p.id === prayer.id);
          if (tomPrayer) {
            const [parsedH, parsedM] = tomPrayer.time.split(':').map(Number);
            th = parsedH;
            tm = parsedM;
          }
        }
        const tomDate = new Date(targetDate);
        tomDate.setDate(tomDate.getDate() + 1);
        triggerMillis = Date.UTC(
          tomDate.getFullYear(),
          tomDate.getMonth(),
          tomDate.getDate(),
          th - tzOffsetHours,
          tm,
          0,
          0
        );
      }

      if (triggerMillis > now) {
        if (hasNativeBridge) {
          // Route through native AlarmManager.setAlarmClock -> AdhanAlarmReceiver -> AdhanForegroundService
          // with USE_FULL_SCREEN_INTENT and clean USAGE_ALARM MediaPlayer playback
          try {
            window.AndroidAdhan?.schedulePrayerAlarm(
              prayer.id,
              prayer.nameAr,
              triggerMillis,
              prayer.id === 'fajr'
            );
          } catch (err) {
            console.warn('[nativeAlarmBridge] AndroidAdhan.schedulePrayerAlarm failed, using fallback:', err);
            const notifId = PRAYER_NOTIFICATION_IDS[prayer.id] || (1000 + Math.floor(Math.random() * 8000));
            await scheduleNativeAdhan(prayer.nameAr, new Date(triggerMillis), notifId);
          }
        } else {
          const notifId = PRAYER_NOTIFICATION_IDS[prayer.id] || (1000 + Math.floor(Math.random() * 8000));
          await scheduleNativeAdhan(prayer.nameAr, new Date(triggerMillis), notifId);
        }
      }
    }
  },

  async scheduleTestAlarm(delayMillis: number = 15000): Promise<boolean> {
    if (this.isAvailable() && window.AndroidAdhan?.scheduleTestAlarm) {
      try {
        await LocalNotifications.cancel({ notifications: [{ id: 9999 }] });
      } catch {}

      try {
        window.AndroidAdhan.scheduleTestAlarm(delayMillis);
        return true;
      } catch (err) {
        console.warn('[nativeAlarmBridge] scheduleTestAlarm failed, falling back to LocalNotifications:', err);
      }
    }

    const testDate = new Date(Date.now() + delayMillis);
    await scheduleNativeAdhan('اختبار الأذان', testDate, 9999);
    return true;
  },

  async cancelAll(prayers: PrayerScheduleItem[]) {
    try {
      const ids = Object.values(PRAYER_NOTIFICATION_IDS).map((id) => ({ id }));
      await LocalNotifications.cancel({ notifications: ids });
    } catch {}

    if (this.isAvailable()) {
      prayers.forEach((prayer) => {
        try {
          window.AndroidAdhan?.cancelPrayerAlarm(prayer.id);
        } catch {}
      });
    }
  },

  syncCityWithNative(cityName: string, lat: number, lng: number, timezoneMode: string = 'gmt') {
    if (this.isAvailable() && window.AndroidAdhan?.updateLocation) {
      try {
        window.AndroidAdhan.updateLocation(cityName, lat, lng, timezoneMode);
      } catch (err) {
        console.warn('[nativeAlarmBridge] updateLocation error:', err);
      }
    }
  },

  setAllowInSilentMode(enabled: boolean) {
    if (this.isAvailable() && window.AndroidAdhan?.setAllowInSilentMode) {
      try {
        window.AndroidAdhan.setAllowInSilentMode(enabled);
      } catch {}
    }
    try {
      localStorage.setItem('prayer_settings_allow_in_silent_mode', String(enabled));
    } catch {}
  },

  isAllowInSilentMode(): boolean {
    if (this.isAvailable() && window.AndroidAdhan?.isAllowInSilentMode) {
      try {
        return window.AndroidAdhan.isAllowInSilentMode();
      } catch {}
    }
    try {
      const saved = localStorage.getItem('prayer_settings_allow_in_silent_mode');
      if (saved !== null) return saved === 'true';
    } catch {}
    return true;
  },

  setSilentModeEnabled(isEnabled: boolean) {
    if (this.isAvailable() && window.AndroidAdhan?.setSilentModeEnabled) {
      try {
        window.AndroidAdhan.setSilentModeEnabled(isEnabled);
      } catch {}
    }
    try {
      localStorage.setItem('prayer_settings_is_silent_mode_enabled', String(isEnabled));
    } catch {}
  },

  isSilentModeEnabled(): boolean {
    if (this.isAvailable() && window.AndroidAdhan?.isSilentModeEnabled) {
      try {
        return window.AndroidAdhan.isSilentModeEnabled();
      } catch {}
    }
    try {
      const saved = localStorage.getItem('prayer_settings_is_silent_mode_enabled');
      if (saved !== null) return saved === 'true';
    } catch {}
    return false;
  },

  setAdhanAlertMethod(method: 'lock_window_unlocked_notification' | 'window' | 'notification') {
    if (this.isAvailable() && window.AndroidAdhan?.setAdhanAlertMethod) {
      try {
        window.AndroidAdhan.setAdhanAlertMethod(method);
      } catch {}
    }
    try {
      localStorage.setItem('prayer_settings_adhan_alert_method', method);
    } catch {}
  },

  getAdhanAlertMethod(): 'lock_window_unlocked_notification' | 'window' | 'notification' {
    if (this.isAvailable() && window.AndroidAdhan?.getAdhanAlertMethod) {
      try {
        const val = window.AndroidAdhan.getAdhanAlertMethod();
        if (val === 'window' || val === 'notification' || val === 'lock_window_unlocked_notification') {
          return val;
        }
      } catch {}
    }
    try {
      const saved = localStorage.getItem('prayer_settings_adhan_alert_method');
      if (saved === 'window' || saved === 'notification' || saved === 'lock_window_unlocked_notification') {
        return saved;
      }
    } catch {}
    return 'lock_window_unlocked_notification';
  },

  stopAdhan() {
    if (this.isAvailable()) {
      try {
        window.AndroidAdhan?.stopAdhan?.();
      } catch (err) {
        console.warn('Native stopAdhan error:', err);
      }
    }
  },

  isAdhanPlaying(): boolean {
    if (this.isAvailable() && window.AndroidAdhan?.isAdhanPlaying) {
      try {
        return !!window.AndroidAdhan.isAdhanPlaying();
      } catch {
        return false;
      }
    }
    return false;
  },

  setShakeToStopConfig(enabled: boolean, sensitivity: number = 5.5) {
    if (this.isAvailable() && window.AndroidAdhan?.setShakeToStopConfig) {
      try {
        window.AndroidAdhan.setShakeToStopConfig(enabled, sensitivity);
      } catch {}
    }
    try {
      localStorage.setItem('prayer_settings_shake_to_stop_enabled', String(enabled));
      localStorage.setItem('prayer_settings_shake_sensitivity', String(sensitivity));
    } catch {}
  },

  isDndAccessGranted(): boolean {
    if (!this.isAvailable() || !window.AndroidAdhan?.isDndAccessGranted) return true;
    try {
      return window.AndroidAdhan.isDndAccessGranted();
    } catch {
      return true;
    }
  },

  getCurrentInterruptionFilter(): number {
    if (!this.isAvailable() || !window.AndroidAdhan?.getCurrentInterruptionFilter) {
      return INTERRUPTION_FILTER.ALL;
    }
    try {
      return window.AndroidAdhan.getCurrentInterruptionFilter();
    } catch {
      return INTERRUPTION_FILTER.ALL;
    }
  },

  setInterruptionFilter(filter: number): boolean {
    if (!this.isAvailable() || !window.AndroidAdhan?.setInterruptionFilter) return false;
    if (!this.isDndAccessGranted()) return false;
    try {
      return !!window.AndroidAdhan.setInterruptionFilter(filter);
    } catch {
      return false;
    }
  },

  /**
   * Temporarily switches NotificationManager interruption filter to INTERRUPTION_FILTER.ALL
   * at the moment Adhan begins, preserving the original DND state to restore once audio ends.
   */
  enableTemporaryDndBypass(): number | null {
    if (!this.isAvailable() || !this.isAllowInSilentMode() || !this.isDndAccessGranted()) {
      return null;
    }
    try {
      const currentFilter = this.getCurrentInterruptionFilter();
      if (savedOriginalInterruptionFilter === null) {
        savedOriginalInterruptionFilter = currentFilter;
      }

      if (currentFilter !== INTERRUPTION_FILTER.ALL) {
        const applied = this.setInterruptionFilter(INTERRUPTION_FILTER.ALL);
        if (!applied && window.AndroidAdhan?.beginTemporaryDndBypass) {
          const nativePrev = window.AndroidAdhan.beginTemporaryDndBypass();
          if (nativePrev >= 0 && savedOriginalInterruptionFilter === null) {
            savedOriginalInterruptionFilter = nativePrev;
          }
        }
      }
      return savedOriginalInterruptionFilter;
    } catch {
      return null;
    }
  },

  /**
   * Restores the original NotificationManager interruption filter after Adhan playback ends or stops.
   */
  restoreOriginalDndFilter(): boolean {
    if (!this.isAvailable()) {
      savedOriginalInterruptionFilter = null;
      return false;
    }

    let restored = false;
    try {
      if (savedOriginalInterruptionFilter !== null) {
        restored = this.setInterruptionFilter(savedOriginalInterruptionFilter);
        savedOriginalInterruptionFilter = null;
      }
      if (!restored && window.AndroidAdhan?.restoreDndFilter) {
        restored = !!window.AndroidAdhan.restoreDndFilter();
      }
    } catch {
      savedOriginalInterruptionFilter = null;
    }
    return restored;
  },

  isIgnoringBatteryOptimizations(): boolean {
    if (!this.isAvailable() || !window.AndroidAdhan?.isIgnoringBatteryOptimizations) return true;
    try {
      return window.AndroidAdhan.isIgnoringBatteryOptimizations();
    } catch {
      return true;
    }
  },

  isAndroid12OrHigher(): boolean {
    if (!this.isAvailable() || !window.AndroidAdhan?.isAndroid12OrHigher) return false;
    try {
      return !!window.AndroidAdhan.isAndroid12OrHigher();
    } catch {
      return false;
    }
  },

  canScheduleExactAlarms(): boolean {
    if (!this.isAvailable() || !window.AndroidAdhan?.canScheduleExactAlarms) return true;
    try {
      return window.AndroidAdhan.canScheduleExactAlarms();
    } catch {
      return true;
    }
  },

  canUseFullScreenIntent(): boolean {
    if (!this.isAvailable() || !window.AndroidAdhan?.canUseFullScreenIntent) return true;
    try {
      return window.AndroidAdhan.canUseFullScreenIntent();
    } catch {
      return true;
    }
  },

  checkAndPromptExactAlarmPermission(): boolean {
    if (!this.isAvailable()) return true;
    const canExact = this.canScheduleExactAlarms();
    if (!canExact) {
      console.log('[nativeAlarmBridge] SCHEDULE_EXACT_ALARM missing on Android 12+, prompting system settings...');
      this.requestExactAlarmPermission();
      return false;
    }
    return true;
  },

  requestDndAccess() {
    if (!this.isAvailable()) return;
    try {
      window.AndroidAdhan?.requestDndAccess?.();
    } catch {}
  },

  requestBatteryExemption() {
    if (!this.isAvailable()) return;
    try {
      window.AndroidAdhan?.requestBatteryExemption?.();
    } catch {}
  },

  requestExactAlarmPermission() {
    if (!this.isAvailable()) return;
    try {
      window.AndroidAdhan?.requestExactAlarmPermission?.();
    } catch {}
  },

  requestFullScreenIntentPermission() {
    if (!this.isAvailable()) return;
    try {
      window.AndroidAdhan?.requestFullScreenIntentPermission?.();
    } catch {}
  },
};
