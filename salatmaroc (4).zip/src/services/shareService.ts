import { CityData, PrayerTimeItem } from '../types/prayer';

export interface ShareScheduleOptions {
  city: CityData;
  dateString: string;
  prayers: PrayerTimeItem[];
  language: 'ar' | 'en';
}

/**
 * Returns canonical production or live app URL
 */
export function getAppShareUrl(): string {
  if (typeof window !== 'undefined') {
    // Prefer shared app URL or current origin
    const origin = window.location.origin;
    if (origin && !origin.includes('localhost') && !origin.includes('127.0.0.1')) {
      return origin;
    }
  }
  return 'https://ais-pre-nucy6ralauuvtg2bqlmo6h-323909448447.europe-west2.run.app';
}

/**
 * Formats a clean, readable prayer schedule message
 */
export function formatPrayerScheduleText({
  city,
  dateString,
  prayers,
  language,
}: ShareScheduleOptions): string {
  const cityName = language === 'en' ? (city.nameFr || city.nameAr) : city.nameAr;
  const appUrl = getAppShareUrl();

  if (language === 'en') {
    const prayerLines = prayers
      .map((p) => `• ${p.nameEn}: ${p.time}`)
      .join('\n');

    return (
      `🕌 Today's Prayer Times - ${cityName}\n` +
      `📅 ${dateString}\n\n` +
      `${prayerLines}\n\n` +
      `📱 Accurate Morocco Prayer Times & Adhan:\n${appUrl}`
    );
  }

  // Arabic default
  const prayerLines = prayers
    .map((p) => `• صلاة ${p.nameAr}: ${p.time}`)
    .join('\n');

  return (
    `🕌 مواقيت الصلاة اليوم لمدينة ${cityName}\n` +
    `📅 ${dateString}\n\n` +
    `${prayerLines}\n\n` +
    `📱 تطبيق مواقيت الصلاة بالمغرب والأذان:\n${appUrl}`
  );
}

/**
 * Checks if the Web Share API is available in the current browser/device
 */
export function isWebShareSupported(): boolean {
  return typeof navigator !== 'undefined' && typeof navigator.share === 'function';
}

/**
 * Triggers native Web Share API
 */
export async function shareViaWebShare({
  title,
  text,
  url,
}: {
  title: string;
  text: string;
  url?: string;
}): Promise<boolean> {
  if (!isWebShareSupported()) {
    return false;
  }
  try {
    await navigator.share({
      title,
      text,
      url: url || getAppShareUrl(),
    });
    return true;
  } catch (err: unknown) {
    // User cancelled share or abort error
    if (err instanceof Error && err.name === 'AbortError') {
      return false;
    }
    console.warn('Web Share API error:', err);
    return false;
  }
}

/**
 * Copies text to clipboard with modern API and reliable textarea fallback
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fallback to execCommand
  }

  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    const successful = document.execCommand('copy');
    document.body.removeChild(textArea);
    return successful;
  } catch {
    return false;
  }
}
