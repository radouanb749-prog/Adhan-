import { PrayerTimeItem, CityData } from '../types/prayer';

/**
 * Calculates prayer times according to the Moroccan Ministry of Habous and Islamic Affairs
 * Official Method: Fajr: 19 degrees, Isha: 17 degrees, Maliki Asr factor: 1, Maghrib: Sunset + 2 min
 */

function degToRad(deg: number): number {
  return (deg * Math.PI) / 180.0;
}

function radToDeg(rad: number): number {
  return (rad * 180.0) / Math.PI;
}

function normalize(value: number, max: number): number {
  let val = value - max * Math.floor(value / max);
  return val < 0 ? val + max : val;
}

export interface PrayerOffsets {
  fajr?: number;
  sunrise?: number;
  dhuhr?: number;
  asr?: number;
  maghrib?: number;
  isha?: number;
}

function applyMinutesOffset(timeStr: string, offsetMin: number = 0): string {
  if (!offsetMin) return timeStr;
  const [h, m] = timeStr.split(':').map(Number);
  const totalMin = ((h * 60 + m + offsetMin) % 1440 + 1440) % 1440;
  const newH = Math.floor(totalMin / 60);
  const newM = totalMin % 60;
  return `${newH.toString().padStart(2, '0')}:${newM.toString().padStart(2, '0')}`;
}

export function calculatePrayerTimes(
  date: Date,
  city: CityData,
  timezoneMode: 'gmt' | 'gmt+1' = 'gmt',
  offsets?: PrayerOffsets
): PrayerTimeItem[] {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  // Astronomical Julian Day calculation
  const a = Math.floor((14 - month) / 12);
  const y = year + 4800 - a;
  const m = month + 12 * a - 3;
  const jd =
    day +
    Math.floor((153 * m + 2) / 5) +
    365 * y +
    Math.floor(y / 4) -
    Math.floor(y / 100) +
    Math.floor(y / 400) -
    32045;

  const d = jd - 2451545.0; // days since J2000.0 epoch

  // Sun coordinates
  const g = normalize(357.529 + 0.98560028 * d, 360);
  const q = normalize(280.459 + 0.98564736 * d, 360);
  const L = normalize(q + 1.915 * Math.sin(degToRad(g)) + 0.02 * Math.sin(degToRad(2 * g)), 360);

  const e = 23.439 - 0.00000036 * d; // Obliquity of ecliptic
  const sinDecl = Math.sin(degToRad(e)) * Math.sin(degToRad(L));
  const decl = radToDeg(Math.asin(sinDecl));

  // Equation of time (in minutes)
  const ra = radToDeg(Math.atan2(Math.cos(degToRad(e)) * Math.sin(degToRad(L)), Math.cos(degToRad(L)))) / 15;
  const raNormalized = normalize(ra, 24);
  const eqTime = (q / 15 - raNormalized) * 60;

  // Timezone: 0 for Greenwich (GMT), 1 for Moroccan standard GMT+1
  const tzOffset = timezoneMode === 'gmt' ? 0.0 : 1.0;

  // Exact solar noon in hours (considering city longitude west of prime meridian)
  const solarNoon = 12 + tzOffset - city.lng / 15 - eqTime / 60;

  // Spherical trigonometry Hour Angle function:
  // cos(H) = (sin(altitude) - sin(lat) * sin(decl)) / (cos(lat) * cos(decl))
  const hourAngle = (altitude: number): number => {
    const latRad = degToRad(city.lat);
    const declRad = degToRad(decl);
    const cosH =
      (Math.sin(degToRad(altitude)) - Math.sin(latRad) * Math.sin(declRad)) /
      (Math.cos(latRad) * Math.cos(declRad));

    if (cosH > 1 || cosH < -1) return 0;
    return radToDeg(Math.acos(cosH)) / 15;
  };

  // Moroccan Awqaf Official Parameters:
  // Fajr: 19 degrees below horizon (-19°)
  // Sunrise / Sunset: -0.8333 degrees (semi-diameter + atmospheric refraction)
  // Maghrib: Sunset + 2 minutes precaution (احتياط وزارة الأوقاف)
  // Isha: 17 degrees below horizon (-17°)
  const fajrDiff = hourAngle(-19);
  const sunriseDiff = hourAngle(-0.8333);
  const sunsetDiff = hourAngle(-0.8333);
  const ishaDiff = hourAngle(-17);

  // Asr (Maliki Jurisprudence: shadow of an object equals its length + shadow at noon)
  // altitude = atan(1 / (1 + tan(abs(latitude - declination))))
  const asrAlt = radToDeg(
    Math.atan(1 / (1 + Math.tan(degToRad(Math.abs(city.lat - decl)))))
  );
  const asrDiff = hourAngle(asrAlt);

  // Astronomical Times in Hours
  const fajrHours = solarNoon - fajrDiff;
  const sunriseHours = solarNoon - sunriseDiff;
  const dhuhrHours = solarNoon + 5 / 60; // 5 min after solar noon (زوال الشمس)
  const asrHours = solarNoon + asrDiff;
  // Astronomical sunset (غروب قرص الشمس الفلكي)
  const sunsetHours = solarNoon + sunsetDiff;
  // Official Moroccan Habous calculation for Maghrib / Iftar:
  // Adds precaution margin (+2 minutes) to ensure entire solar disk has sunk beneath real horizon (احتياط وزارة الأوقاف والشؤون الإسلامية بالمغرب)
  const maghribHours = sunsetHours + 2 / 60; 
  const ishaHours = solarNoon + ishaDiff;

  const toTimeStr = (hoursVal: number): string => {
    const totalMinutes = Math.round(normalize(hoursVal, 24) * 60);
    const h = Math.floor(totalMinutes / 60) % 24;
    const m = totalMinutes % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  };

  // Calculated dynamic times that update every single day with the movement of the sun
  let fajrTime = toTimeStr(fajrHours);
  let sunriseTime = toTimeStr(sunriseHours);
  let dhuhrTime = toTimeStr(dhuhrHours);
  let asrTime = toTimeStr(asrHours);
  let sunsetTime = toTimeStr(sunsetHours);
  let maghribTime = toTimeStr(maghribHours);
  let ishaTime = toTimeStr(ishaHours);

  // Apply user-defined manual offsets in minutes if set
  if (offsets) {
    if (offsets.fajr) fajrTime = applyMinutesOffset(fajrTime, offsets.fajr);
    if (offsets.sunrise) sunriseTime = applyMinutesOffset(sunriseTime, offsets.sunrise);
    if (offsets.dhuhr) dhuhrTime = applyMinutesOffset(dhuhrTime, offsets.dhuhr);
    if (offsets.asr) asrTime = applyMinutesOffset(asrTime, offsets.asr);
    if (offsets.maghrib) maghribTime = applyMinutesOffset(maghribTime, offsets.maghrib);
    if (offsets.isha) ishaTime = applyMinutesOffset(ishaTime, offsets.isha);
  }

  const toTimestamp = (timeStr: string): number => {
    const [h, m] = timeStr.split(':').map(Number);
    const dObj = new Date(date);
    dObj.setHours(h, m, 0, 0);
    return dObj.getTime();
  };

  const prayers: PrayerTimeItem[] = [
    {
      id: 'fajr',
      nameAr: 'الفجر',
      nameEn: 'Fajr',
      time: fajrTime,
      timestamp: toTimestamp(fajrTime),
    },
    {
      id: 'sunrise',
      nameAr: 'الشروق',
      nameEn: 'Sunrise',
      time: sunriseTime,
      timestamp: toTimestamp(sunriseTime),
    },
    {
      id: 'dhuhr',
      nameAr: 'الظهر',
      nameEn: 'Dhuhr',
      time: dhuhrTime,
      timestamp: toTimestamp(dhuhrTime),
    },
    {
      id: 'asr',
      nameAr: 'العصر',
      nameEn: 'Asr',
      time: asrTime,
      timestamp: toTimestamp(asrTime),
    },
    {
      id: 'maghrib',
      nameAr: 'المغرب',
      nameEn: 'Maghrib',
      time: maghribTime,
      timestamp: toTimestamp(maghribTime),
      sunsetTime: sunsetTime,
    },
    {
      id: 'isha',
      nameAr: 'العشاء',
      nameEn: 'Isha',
      time: ishaTime,
      timestamp: toTimestamp(ishaTime),
    },
  ];

  return prayers;
}

export function getSecondsForTimezone(
  nowTimestamp: number = Date.now(),
  timezoneMode: 'gmt' | 'gmt+1' = 'gmt'
): number {
  const now = new Date(nowTimestamp);
  const tzOffsetHours = timezoneMode === 'gmt+1' ? 1 : 0;
  const h = (now.getUTCHours() + tzOffsetHours + 24) % 24;
  return h * 3600 + now.getUTCMinutes() * 60 + now.getUTCSeconds();
}

// Alias for backward compatibility
export const getWallClockSecondsToday = (
  nowTimestamp: number = Date.now(),
  timezoneMode: 'gmt' | 'gmt+1' = 'gmt'
): number => getSecondsForTimezone(nowTimestamp, timezoneMode);

export interface NextPrayerResult {
  nextPrayer: PrayerTimeItem;
  countdownStr: string;
  diffSeconds: number;
  hours: number;
  minutes: number;
  seconds: number;
  formattedRemainingAr: string;
}

export function getNextPrayer(
  prayers: PrayerTimeItem[],
  nowTimestamp: number,
  timezoneMode: 'gmt' | 'gmt+1' = 'gmt',
  tomorrowPrayers?: PrayerTimeItem[],
  manualNextPrayerId?: string | null
): NextPrayerResult {
  const currentSecToday = getSecondsForTimezone(nowTimestamp, timezoneMode);

  // Filter 5 obligatory canonical prayers (exclude sunrise from prayer sequence)
  const canonicalPrayers = prayers.filter((p) => p.id !== 'sunrise');

  let next: PrayerTimeItem | undefined;
  let diffSec: number = 0;

  // 1. If user explicitly selected a manual target prayer to calibrate order:
  if (manualNextPrayerId) {
    const manualTarget = canonicalPrayers.find((p) => p.id === manualNextPrayerId);
    if (manualTarget) {
      const [h, m] = manualTarget.time.split(':').map(Number);
      const pSec = h * 3600 + m * 60;
      if (pSec > currentSecToday) {
        // Targeted prayer is still upcoming today
        next = manualTarget;
        diffSec = Math.max(0, pSec - currentSecToday);
      } else {
        // Targeted prayer has arrived or passed today. Its next occurrence is tomorrow!
        // This ensures fixing Fajr (or any prayer) at night or during the day locks to that prayer accurately
        if (manualNextPrayerId === 'fajr') {
          const tomorrowFajr = tomorrowPrayers?.find((p) => p.id === 'fajr');
          const fajrItem = tomorrowFajr || manualTarget;
          const [fh, fm] = fajrItem.time.split(':').map(Number);
          const fajrSec = fh * 3600 + fm * 60;
          next = fajrItem;
          diffSec = Math.max(0, 86400 - currentSecToday + fajrSec);
        } else {
          const tomorrowTarget = tomorrowPrayers?.find((p) => p.id === manualNextPrayerId);
          const item = tomorrowTarget || manualTarget;
          const [th, tm] = item.time.split(':').map(Number);
          const targetTomorrowSec = th * 3600 + tm * 60;
          next = item;
          diffSec = Math.max(0, 86400 - currentSecToday + targetTomorrowSec);
        }
      }
    }
  }

  // 2. Default automatic progression if no manual override or manual prayer has finished:
  if (!next) {
    next = canonicalPrayers.find((p) => {
      const [h, m] = p.time.split(':').map(Number);
      const pSec = h * 3600 + m * 60;
      return pSec > currentSecToday;
    });

    if (next) {
      const [h, m] = next.time.split(':').map(Number);
      const pSec = h * 3600 + m * 60;
      diffSec = Math.max(0, pSec - currentSecToday);
    } else {
      // If all prayers have ended today (after Isha time), next prayer is Fajr tomorrow morning
      const tomorrowFajr = tomorrowPrayers?.find((p) => p.id === 'fajr');
      const fajr = tomorrowFajr || prayers.find((p) => p.id === 'fajr') || prayers[0];
      const [h, m] = fajr.time.split(':').map(Number);
      const fajrSec = h * 3600 + m * 60;
      diffSec = Math.max(0, 86400 - currentSecToday + fajrSec);
      next = fajr;
    }
  }

  // Calculate exact canonical remaining time components to next prayer
  const hours = Math.floor(diffSec / 3600);
  const minutes = Math.floor((diffSec % 3600) / 60);
  const seconds = diffSec % 60;

  const pad = (n: number) => n.toString().padStart(2, '0');
  
  // Format countdown string: if hours > 0, HH:MM:SS, otherwise MM:SS
  const countdownStr =
    hours > 0
      ? `${pad(hours)} : ${pad(minutes)} : ${pad(seconds)}`
      : `${pad(minutes)} : ${pad(seconds)}`;

  // Human-readable Arabic remaining time label
  const formattedRemainingAr =
    hours > 0
      ? `${hours} س و ${minutes} د`
      : `${minutes} د`;

  return {
    nextPrayer: next,
    countdownStr,
    diffSeconds: diffSec,
    hours,
    minutes,
    seconds,
    formattedRemainingAr,
  };
}
