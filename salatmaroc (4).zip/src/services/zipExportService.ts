import JSZip from 'jszip';

export function getZipDirectUrl(): string {
  if (typeof window !== 'undefined') {
    return `${window.location.origin}/salatmaroc.zip`;
  }
  return '/salatmaroc.zip';
}

export async function downloadAppZip(): Promise<void> {
  // 1. Primary method: Direct link with target=_blank to punch through iframe download restrictions
  const zipUrl = `/salatmaroc.zip?t=${Date.now()}`;
  try {
    const a = document.createElement('a');
    a.href = zipUrl;
    a.download = 'salatmaroc.zip';
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 500);
  } catch (err) {
    console.warn('Anchor download attempt:', err);
  }

  // 2. Secondary method: Blob URL
  try {
    const res = await fetch(zipUrl, {
      cache: 'no-cache',
    });
    if (res.ok) {
      const blob = await res.blob();
      if (blob.size > 1000) {
        triggerDownload(blob, 'salatmaroc.zip');
        return;
      }
    }
  } catch (err) {
    console.error('Failed to fetch static zip, falling back to dynamic:', err);
  }

  // 3. Fallback: dynamic generation
  const zip = new JSZip();
  zip.file('README.md', '# تطبيق مواقيت الصلاة بالمغرب - Moroccan Islamic Prayer Times');
  const content = await zip.generateAsync({ type: 'blob' });
  triggerDownload(content, 'salatmaroc.zip');
}

function triggerDownload(blob: Blob, filename: string) {
  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
      URL.revokeObjectURL(url);
    }, 2000);
  } catch (e) {
    console.warn('triggerDownload blob error:', e);
  }
}
