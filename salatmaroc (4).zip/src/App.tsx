import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Navigation, X } from 'lucide-react';
import { HeaderHero } from './components/HeaderHero';
import { DateBar } from './components/DateBar';
import { PrayerList } from './components/PrayerList';
import { HadithCard } from './components/HadithCard';
import { AdhkarQuickWidget } from './components/AdhkarQuickWidget';
import { PrePrayerAlertBanner } from './components/PrePrayerAlertBanner';
import { DhikrReminderBanner } from './components/DhikrReminderBanner';
import { AudioIssueBanner } from './components/AudioIssueBanner';
import { ExactAlarmBanner } from './components/ExactAlarmBanner';
import { BottomNav, MainTabType } from './components/BottomNav';
import { SideMenuBottomSheet, SubMenuOption } from './components/SideMenuBottomSheet';
import { QiblaCompassView } from './components/QiblaCompassView';
import { MosquesView } from './components/MosquesView';
import { PrayerVirtuesView } from './components/PrayerVirtuesView';
import { HadithsModal } from './components/Modals/HadithsModal';
import { AdhkarModal } from './components/Modals/AdhkarModal';
import { MonthlyTimetableModal } from './components/Modals/MonthlyTimetableModal';
import { CitiesModal } from './components/Modals/CitiesModal';
import { SettingsModal } from './components/Modals/SettingsModal';
import { PrayerTimesAdjustModal } from './components/Modals/PrayerTimesAdjustModal';
import { MuezzinSelectorModal } from './components/Modals/MuezzinSelectorModal';
import { AdhanSettingsModal } from './components/Modals/AdhanSettingsModal';
import { HisnAlMuslimModal } from './components/Modals/HisnAlMuslimModal';
import { DailyPrayerTrackerWidget } from './components/DailyPrayerTrackerWidget';
import { AdhanMiniPlayer } from './components/AdhanMiniPlayer';
import { IslamicAmbientBackground } from './components/IslamicAmbientBackground';
import { DEFAULT_CITY, MOROCCO_CITIES, findNearestMoroccoCity, calculateDistanceKm } from './data/moroccoCities';
import { MUEZZINS_LIST } from './data/muezzinsData';
import { CityData, SettingsState, PrayerTimeItem } from './types/prayer';
import { calculatePrayerTimes, getNextPrayer, getWallClockSecondsToday, getSecondsForTimezone, PrayerOffsets } from './services/prayerCalculation';
import { getFormattedDateInfo } from './services/hijriCalendar';
import { notificationService } from './services/notificationService';
import { audioAdhanService } from './services/audioAdhan';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { downloadAppZip } from './services/zipExportService';
import { SupervisorAuthModal } from './components/Modals/SupervisorAuthModal';
import { TasbeehCounterModal } from './components/Modals/TasbeehCounterModal';
import { ShareModal } from './components/Modals/ShareModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { UnityAdsBanner } from './components/UnityAdsBanner';
import { AndroidAutoModal } from './components/Modals/AndroidAutoModal';
import { backgroundTimerService } from './services/backgroundTimer';
import {
  nativeAlarmBridge,
  initAdhanChannel,
  requestAdhanPermissions,
} from './services/nativeAlarmBridge';
import { wakeLockService } from './services/wakeLockService';
import { useShakeDetector } from './hooks/useShakeDetector';

interface AppContentProps {
  currentCity: CityData;
  setCurrentCity: (city: CityData) => void;
  targetDate: Date;
  dayOffset: number;
  setDayOffset: React.Dispatch<React.SetStateAction<number>>;
  dateInfo: { fullDateString: string };
  prayers: PrayerTimeItem[];
  todayRealPrayers: PrayerTimeItem[];
  tomorrowRealPrayers?: PrayerTimeItem[];
  settings: SettingsState;
  handleUpdateSettings: (newSettings: Partial<SettingsState>) => void;
  currentTimeMs: number;
  handleAutoLocate: (isManual?: boolean) => void;
  isLocating: boolean;
  gpsStatusMessage?: string | null;
  gpsToast?: { message: string; cityName: string; regionName: string } | null;
  onDismissGpsToast?: () => void;
  assignedMuezzins: Record<string, string>;
  setAssignedMuezzins: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  defaultMuezzinId: string;
  setDefaultMuezzinId: (id: string) => void;
}

function AppContent({
  currentCity,
  setCurrentCity,
  targetDate,
  dayOffset,
  setDayOffset,
  dateInfo,
  prayers,
  todayRealPrayers,
  tomorrowRealPrayers,
  settings,
  handleUpdateSettings,
  currentTimeMs,
  handleAutoLocate,
  isLocating,
  gpsStatusMessage,
  gpsToast,
  onDismissGpsToast,
  assignedMuezzins,
  setAssignedMuezzins,
  defaultMuezzinId,
  setDefaultMuezzinId,
}: AppContentProps) {
  const { isDark } = useTheme();

  // Navigation & Menus
  const [activeTab, setActiveTab] = useState<MainTabType>('today');
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  // Modals state
  const [isHadithsModalOpen, setIsHadithsModalOpen] = useState(false);
  const [isAdhkarModalOpen, setIsAdhkarModalOpen] = useState(false);
  const [isMonthlyModalOpen, setIsMonthlyModalOpen] = useState(false);
  const [isCitiesModalOpen, setIsCitiesModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isPrayerAdjustModalOpen, setIsPrayerAdjustModalOpen] = useState(false);
  const [isMuezzinModalOpen, setIsMuezzinModalOpen] = useState(false);
  const [isAdhanSettingsModalOpen, setIsAdhanSettingsModalOpen] = useState(false);
  const [isHisnModalOpen, setIsHisnModalOpen] = useState(false);
  const [isTasbeehModalOpen, setIsTasbeehModalOpen] = useState(false);
  const [isSupervisorAuthModalOpen, setIsSupervisorAuthModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isAndroidAutoModalOpen, setIsAndroidAutoModalOpen] = useState(false);
  const [targetPrayerForMuezzin, setTargetPrayerForMuezzin] = useState<{ id: string; nameAr: string } | null>(null);
  const [adhkarCategory, setAdhkarCategory] = useState<'morning' | 'evening' | 'after_prayer'>('morning');

  // Adhan playback state tracking across WebAudio and Android Foreground Service
  const [isAdhanPlaying, setIsAdhanPlaying] = useState<boolean>(() => {
    return audioAdhanService.getPlaybackState().isPlaying || nativeAlarmBridge.isAdhanPlaying();
  });
  const [shakeStoppedToast, setShakeStoppedToast] = useState(false);

  useEffect(() => {
    const unsub = audioAdhanService.subscribe((state) => {
      setIsAdhanPlaying(state.isPlaying || nativeAlarmBridge.isAdhanPlaying());
    });
    const interval = setInterval(() => {
      const nativePlaying = nativeAlarmBridge.isAdhanPlaying();
      if (nativePlaying) {
        setIsAdhanPlaying(true);
      }
    }, 1000);
    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  // Synchronize shake to stop configuration with native Android preferences
  useEffect(() => {
    nativeAlarmBridge.setShakeToStopConfig(
      settings.shakeToStopAdhan !== false,
      settings.shakeSensitivity || 5.5
    );
  }, [settings.shakeToStopAdhan, settings.shakeSensitivity]);

  // Global root shake detector to silence Adhan immediately
  useShakeDetector({
    enabled: (settings.shakeToStopAdhan !== false) && isAdhanPlaying,
    threshold: settings.shakeSensitivity || 5.5,
    onShake: () => {
      console.log('[AppContent] Root shake detected! Stopping Adhan across web and native bridge...');
      notificationService.stopAdhan();
      audioAdhanService.stopAll();
      nativeAlarmBridge.stopAdhan();
      setIsAdhanPlaying(false);
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([150, 50, 150]);
        } catch {}
      }
      setShakeStoppedToast(true);
      setTimeout(() => setShakeStoppedToast(false), 4000);
    },
  });

  // Ensure automatic continuous progression across all prayers (no frozen manual overrides)
  const [manualNextPrayerId, setManualNextPrayerId] = useState<string | null>(() => {
    try {
      localStorage.removeItem('salat_manual_next_prayer');
    } catch {}
    return null;
  });

  const handleSelectManualNextPrayer = (prayerId: string | null) => {
    setManualNextPrayerId(prayerId);
    try {
      if (prayerId) {
        localStorage.setItem('salat_manual_next_prayer', prayerId);
      } else {
        localStorage.removeItem('salat_manual_next_prayer');
      }
    } catch {}
  };

  // Compute Next Prayer and Live Countdown string strictly synchronized with today's real time and tomorrow's Fajr
  const { nextPrayer, countdownStr, diffSeconds } = useMemo(() => {
    return getNextPrayer(
      todayRealPrayers,
      currentTimeMs,
      settings.timezoneMode,
      tomorrowRealPrayers,
      manualNextPrayerId
    );
  }, [todayRealPrayers, currentTimeMs, settings.timezoneMode, tomorrowRealPrayers, manualNextPrayerId]);

  // When a manually selected prayer passes, auto-clear manual override so subsequent sequence continues automatically
  useEffect(() => {
    if (!manualNextPrayerId) return;
    // If the target prayer is still counting down (diffSeconds > 0), keep it fixed and do not clear
    if (diffSeconds > 0) return;

    // Once the prayer arrives and has elapsed by at least 60 seconds, clear manual override to resume automatic sequence
    const currentSecToday = getSecondsForTimezone(currentTimeMs, settings.timezoneMode);
    const target = todayRealPrayers.find((p) => p.id === manualNextPrayerId);
    if (target) {
      const [h, m] = target.time.split(':').map(Number);
      const targetSec = h * 3600 + m * 60;
      if (currentSecToday >= targetSec + 60 && currentSecToday < targetSec + 1800) {
        handleSelectManualNextPrayer(null);
      }
    }
  }, [currentTimeMs, manualNextPrayerId, diffSeconds, todayRealPrayers, settings.timezoneMode]);

  // Manual fine-tuning adjustment for remaining time on the upcoming prayer
  const currentPrayerOffsetKey = nextPrayer ? (`${nextPrayer.id}Offset` as keyof SettingsState) : null;
  const currentPrayerOffset = currentPrayerOffsetKey ? ((settings[currentPrayerOffsetKey] as number) || 0) : 0;

  const handleAdjustRemainingOffset = (deltaMinutes: number) => {
    if (!currentPrayerOffsetKey) return;
    const current = (settings[currentPrayerOffsetKey] as number) || 0;
    handleUpdateSettings({ [currentPrayerOffsetKey]: current + deltaMinutes });
  };

  const handleResetRemainingOffset = () => {
    if (!currentPrayerOffsetKey) return;
    handleUpdateSettings({ [currentPrayerOffsetKey]: 0 });
  };

  // Handle sub menu options from bottom sheet
  const handleSelectSubMenuOption = (option: SubMenuOption) => {
    switch (option) {
      case 'tasbeeh':
        setIsTasbeehModalOpen(true);
        break;
      case 'hisn':
        setIsHisnModalOpen(true);
        break;
      case 'virtues':
        setActiveTab('virtues');
        break;
      case 'hadiths':
        setIsHadithsModalOpen(true);
        break;
      case 'adhkar':
        setIsAdhkarModalOpen(true);
        break;
      case 'monthly':
        setIsMonthlyModalOpen(true);
        break;
      case 'cities':
        setIsCitiesModalOpen(true);
        break;
      case 'adhan_settings':
        setIsAdhanSettingsModalOpen(true);
        break;
      case 'share':
        setIsShareModalOpen(true);
        break;
      case 'settings':
        setIsSettingsModalOpen(true);
        break;
      case 'download_zip':
        setIsSupervisorAuthModalOpen(true);
        break;
      case 'android_auto':
        setIsAndroidAutoModalOpen(true);
        break;
    }
  };

  const sunriseTime = useMemo(
    () => prayers.find((p) => p.id === 'sunrise')?.time || '06:20',
    [prayers]
  );
  const sunsetTime = useMemo(
    () => prayers.find((p) => p.id === 'maghrib')?.time || '18:15',
    [prayers]
  );

  return (
    <div
      className={`min-h-screen flex flex-col items-center justify-start antialiased font-['Cairo',sans-serif] pb-24 selection:bg-[#C5A059] selection:text-black transition-colors duration-500 ${
        isDark ? 'bg-[#121212] text-white' : 'bg-[#F7F5F0] text-gray-900'
      }`}
    >
      {/* Real-Time Floating GPS Toast Notification */}
      {gpsToast && (
        <div className="fixed top-3 left-3 right-3 max-w-md mx-auto z-50 bg-gradient-to-r from-emerald-950/95 via-[#1A1A1A]/95 to-emerald-950/95 border border-emerald-500/50 rounded-2xl p-3.5 shadow-2xl backdrop-blur-md flex items-center justify-between text-white animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <Navigation className="w-4 h-4 fill-emerald-400 animate-pulse" />
            </div>
            <div>
              <p className="text-xs sm:text-sm font-bold text-emerald-300 font-['Cairo',sans-serif]">
                {gpsToast.message}
              </p>
              <p className="text-[11px] text-white/70">
                {gpsToast.cityName} • {gpsToast.regionName} (تم ضبط المواقيت تلقائياً)
              </p>
            </div>
          </div>
          <button
            onClick={onDismissGpsToast}
            className="p-1.5 rounded-full text-white/60 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Calm Islamic Animated Ambient Background (Clouds, Ambient Glow, Stars, Light Beams) */}
      <IslamicAmbientBackground enabled={settings.animatedBackgroundEnabled !== false} />

      {/* 5-Minute Pre-Prayer Alert Floating Banner */}
      <PrePrayerAlertBanner />

      {/* Audio Issue Visual Alert Banner for Phone System Settings */}
      <AudioIssueBanner />

      {/* Android 12+ SCHEDULE_EXACT_ALARM Permission Banner */}
      <ExactAlarmBanner />

      {/* Daily Morning & Evening Dhikr Reminder Banner */}
      <DhikrReminderBanner
        onOpenAdhkar={(cat) => {
          setAdhkarCategory(cat);
          setIsAdhkarModalOpen(true);
        }}
      />

      {/* Container simulating mobile frame or clean max-w layout */}
      <div
        className={`w-full max-w-md md:max-w-lg min-h-screen shadow-2xl relative flex flex-col transition-colors duration-500 z-10 ${
          isDark ? 'bg-[#121212]' : 'bg-[#F7F5F0]'
        }`}
      >
        {activeTab === 'today' && (
          <main className="flex-1 flex flex-col">
            {/* 1. Header Hero with Hassan II Mosque Casablanca */}
            <HeaderHero
              nextPrayer={nextPrayer}
              countdownStr={countdownStr}
              currentCity={currentCity}
              timezoneMode={settings.timezoneMode}
              animatedBackgroundEnabled={settings.animatedBackgroundEnabled !== false}
              onToggleTimezone={() =>
                handleUpdateSettings({
                  timezoneMode: settings.timezoneMode === 'gmt' ? 'gmt+1' : 'gmt',
                })
              }
              onOpenQibla={() => setActiveTab('qibla')}
              onOpenSettings={() => setIsSettingsModalOpen(true)}
              onOpenShare={() => setIsShareModalOpen(true)}
              muezzinId={settings.adhanSound || defaultMuezzinId}
              assignedMuezzins={assignedMuezzins}
              onAutoLocate={() => handleAutoLocate(true)}
              isLocating={isLocating}
              prayers={prayers}
              manualNextPrayerId={manualNextPrayerId}
              onSelectManualNextPrayer={handleSelectManualNextPrayer}
              currentPrayerOffset={currentPrayerOffset}
              onAdjustRemainingOffset={handleAdjustRemainingOffset}
              onResetRemainingOffset={handleResetRemainingOffset}
              isSilentModeEnabled={!!settings.is_silent_mode_enabled}
              onToggleSilentMode={() =>
                handleUpdateSettings({
                  is_silent_mode_enabled: !settings.is_silent_mode_enabled,
                })
              }
            />

            {/* 2. Date Bar with Golden Arrows */}
            <DateBar
              dateString={dateInfo.fullDateString}
              dayOffset={dayOffset}
              onPrevDay={() => setDayOffset((prev) => prev - 1)}
              onNextDay={() => setDayOffset((prev) => prev + 1)}
              onResetToday={() => setDayOffset(0)}
            />

            {/* Optional Daily Prayer Performance Tracker (سجل الصلوات اليومية) */}
            {settings.dailyPrayerTrackerEnabled && (
              <DailyPrayerTrackerWidget
                targetDate={targetDate}
                prayers={prayers}
                currentTimeMs={currentTimeMs}
                timezoneMode={settings.timezoneMode}
              />
            )}

            {/* 3. Prayer List (6 rows with real Adhan players) */}
            <PrayerList
              prayers={prayers}
              nextPrayerId={dayOffset === 0 ? nextPrayer?.id : undefined}
              countdownStr={dayOffset === 0 ? countdownStr : undefined}
              onOpenPrayerAdjust={() => setIsPrayerAdjustModalOpen(true)}
              onOpenMuezzinSelector={(prayerId, prayerNameAr) => {
                setTargetPrayerForMuezzin({ id: prayerId, nameAr: prayerNameAr });
                setIsAdhanSettingsModalOpen(true);
              }}
              onOpenShare={() => setIsShareModalOpen(true)}
              assignedMuezzins={assignedMuezzins}
            />

            {/* 4. Hadith Card */}
            <HadithCard
              targetDate={targetDate}
              onOpenHadithsModal={() => setIsHadithsModalOpen(true)}
            />

            {/* 5. Quick Adhkar Widgets (Morning & Evening) */}
            <AdhkarQuickWidget
              onOpenMorning={() => {
                setAdhkarCategory('morning');
                setIsAdhkarModalOpen(true);
              }}
              onOpenEvening={() => {
                setAdhkarCategory('evening');
                setIsAdhkarModalOpen(true);
              }}
            />

            {/* Unity Ads Banner (Game ID: 800400769 - Quran Karim) */}
            <UnityAdsBanner />
          </main>
        )}

        {/* Tab 2: Virtues of Prayer & Congregational Prayer in Mosque (فضل الصلاة) */}
        {activeTab === 'virtues' && (
          <main className="flex-1 flex flex-col p-4">
            <PrayerVirtuesView
              onBack={() => setActiveTab('today')}
              nextPrayer={nextPrayer}
            />
          </main>
        )}

        {/* Tab 3: Qibla View Tab */}
        {activeTab === 'qibla' && (
          <main className="flex-1 flex flex-col p-4">
            <QiblaCompassView
              currentCity={currentCity}
              onBack={() => setActiveTab('today')}
            />
          </main>
        )}

        {/* Tab 4: Mosques View Tab */}
        {activeTab === 'mosques' && (
          <main className="flex-1 flex flex-col p-4">
            <MosquesView
              currentCity={currentCity}
              onBack={() => setActiveTab('today')}
            />
          </main>
        )}

        {/* 5. Bottom Navigation Bar */}
        <BottomNav
          activeTab={activeTab}
          onTabChange={(tab) => {
            setActiveTab(tab);
            setIsMoreMenuOpen(false);
          }}
          onOpenMoreMenu={() => setIsMoreMenuOpen(true)}
          isMoreMenuOpen={isMoreMenuOpen}
        />

        {/* 6. Side Menu Bottom Sheet (المزيد) */}
        <SideMenuBottomSheet
          isOpen={isMoreMenuOpen}
          onClose={() => setIsMoreMenuOpen(false)}
          onSelectOption={handleSelectSubMenuOption}
        />

        {/* Modals triggered from "المزيد" or header */}
        <TasbeehCounterModal
          isOpen={isTasbeehModalOpen}
          onClose={() => setIsTasbeehModalOpen(false)}
        />

        <SupervisorAuthModal
          isOpen={isSupervisorAuthModalOpen}
          onClose={() => setIsSupervisorAuthModalOpen(false)}
        />

        <HisnAlMuslimModal
          isOpen={isHisnModalOpen}
          onClose={() => setIsHisnModalOpen(false)}
        />

        <HadithsModal
          isOpen={isHadithsModalOpen}
          onClose={() => setIsHadithsModalOpen(false)}
        />

        <AdhkarModal
          isOpen={isAdhkarModalOpen}
          onClose={() => setIsAdhkarModalOpen(false)}
          initialCategory={adhkarCategory}
        />

        <MonthlyTimetableModal
          isOpen={isMonthlyModalOpen}
          onClose={() => setIsMonthlyModalOpen(false)}
          currentCity={currentCity}
          timezoneMode={settings.timezoneMode}
        />

        <CitiesModal
          isOpen={isCitiesModalOpen}
          onClose={() => setIsCitiesModalOpen(false)}
          currentCity={currentCity}
          onSelectCity={(city) => setCurrentCity(city)}
          onAutoLocate={handleAutoLocate}
          isLocating={isLocating}
        />

        {/* Share Modal (Web Share API & Copy Link / Prayer Schedule) */}
        <ShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          currentCity={currentCity}
          dateString={dateInfo.fullDateString}
          prayers={prayers}
        />

        {/* Android Auto Modal (Car Dashboard Simulator & Connection Guide) */}
        <AndroidAutoModal
          isOpen={isAndroidAutoModalOpen}
          onClose={() => setIsAndroidAutoModalOpen(false)}
          prayers={prayers}
          currentCity={currentCity}
          nextPrayer={nextPrayer}
          countdownStr={countdownStr}
          dateString={dateInfo.fullDateString}
        />

        {/* Main Settings Modal (including City/Location Settings and ZIP Download) */}
        <SettingsModal
          isOpen={isSettingsModalOpen}
          onClose={() => setIsSettingsModalOpen(false)}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onOpenPrayerAdjust={() => setIsPrayerAdjustModalOpen(true)}
          onOpenAdhanSettings={() => setIsAdhanSettingsModalOpen(true)}
          onOpenMuezzinSelector={() => {
            setTargetPrayerForMuezzin(null);
            setIsMuezzinModalOpen(true);
          }}
          onOpenCityPicker={() => setIsCitiesModalOpen(true)}
          onAutoLocate={handleAutoLocate}
          isLocating={isLocating}
          gpsStatusMessage={gpsStatusMessage}
          onDownloadZip={() => setIsSupervisorAuthModalOpen(true)}
          currentCityName={currentCity.nameAr}
          currentCityRegion={currentCity.region}
          sunriseTime={sunriseTime}
          sunsetTime={sunsetTime}
        />

        {/* Modal: Adhan Settings matching user screenshot */}
        <AdhanSettingsModal
          isOpen={isAdhanSettingsModalOpen}
          onClose={() => setIsAdhanSettingsModalOpen(false)}
          assignedMuezzins={assignedMuezzins}
          onUpdateAssignedMuezzin={(prayerId, muezzinId) => {
            setAssignedMuezzins((prev) => ({ ...prev, [prayerId]: muezzinId }));
          }}
          onOpenMuezzinPickerForPrayer={(prayerId, prayerNameAr) => {
            setTargetPrayerForMuezzin({ id: prayerId, nameAr: prayerNameAr });
            setIsMuezzinModalOpen(true);
          }}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
        />

        {/* Modal: Adjust Prayer Times matching the user screenshot */}
        <PrayerTimesAdjustModal
          isOpen={isPrayerAdjustModalOpen}
          onClose={() => setIsPrayerAdjustModalOpen(false)}
          prayers={prayers}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
        />

        {/* Modal: Famous Islamic World Muezzins Selector */}
        <MuezzinSelectorModal
          isOpen={isMuezzinModalOpen}
          onClose={() => setIsMuezzinModalOpen(false)}
          selectedMuezzinId={
            targetPrayerForMuezzin
              ? assignedMuezzins[targetPrayerForMuezzin.id] || defaultMuezzinId
              : defaultMuezzinId
          }
          onSelectMuezzin={(muezzinId) => {
            if (targetPrayerForMuezzin) {
              setAssignedMuezzins((prev) => ({
                ...prev,
                [targetPrayerForMuezzin.id]: muezzinId,
              }));
            } else {
              setDefaultMuezzinId(muezzinId);
              handleUpdateSettings({ adhanSound: muezzinId });
              // Update all prayers with the selected muezzin
              setAssignedMuezzins((prev) => ({
                ...prev,
                dhuhr: muezzinId,
                asr: muezzinId,
                maghrib: muezzinId,
                isha: muezzinId,
                fajr: muezzinId.includes('fajr') ? muezzinId : prev.fajr,
              }));
            }
          }}
          targetPrayerName={targetPrayerForMuezzin?.nameAr}
        />

        {/* Floating Mini Player when Adhan is actively playing */}
        <AdhanMiniPlayer
          shakeEnabled={settings.shakeToStopAdhan !== false}
          shakeThreshold={settings.shakeSensitivity || 5.5}
        />

        {/* Global Toast confirming Adhan stopped by shaking the phone */}
        {shakeStoppedToast && (
          <div className="fixed bottom-24 left-4 right-4 z-50 max-w-sm mx-auto animate-in fade-in slide-in-from-bottom-4 duration-300 pointer-events-none">
            <div className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-emerald-950/95 border border-emerald-500/60 shadow-2xl backdrop-blur-md text-emerald-300 text-xs font-bold text-center">
              <span>تم إيقاف الأذان بنجاح عبر اهتزاز الهاتف 📳</span>
            </div>
          </div>
        )}

        {/* Offline connectivity indicator banner */}
        <OfflineIndicator />
      </div>
    </div>
  );
}

export default function App() {
  // Location state (defaults to Mohammedia or saved city)
  const [currentCity, setCurrentCity] = useState<CityData>(() => {
    try {
      const saved = localStorage.getItem('salat_selected_city');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_CITY;
  });
  const [isLocating, setIsLocating] = useState(false);

  // Save selected city
  useEffect(() => {
    try {
      localStorage.setItem('salat_selected_city', JSON.stringify(currentCity));
    } catch {}
  }, [currentCity]);

  // Date selection state (dayOffset 0 = today in real-time)
  const [dayOffset, setDayOffset] = useState<number>(0);

  // GPS Live Location State
  const [gpsStatusMessage, setGpsStatusMessage] = useState<string | null>(null);
  const [gpsToast, setGpsToast] = useState<{
    message: string;
    cityName: string;
    regionName: string;
  } | null>(null);

  // Moroccan civil time operates strictly on Greenwich Mean Time (GMT+0 / التوقيت العالمي)
  // GMT+1 is used only as summer time (التوقيت الصيفي)
  const defaultSettingsState: SettingsState = {
    adhanSound: 'moroccan_traditional',
    themeMode: 'auto', // Auto Day/Night according to Sunrise and Sunset
    notificationsEnabled: true,
    prePrayerAlertEnabled: true,
    prePrayerAlertMinutes: 5,
    timezoneMode: 'gmt', // Strictly GMT (غرينتش / التوقيت العالمي 🇲🇦)
    isUserExplicitSummerTime: false,
    autoSettings: true,
    fajrOffset: 0,
    sunriseOffset: 0,
    dhuhrOffset: 0,
    asrOffset: 0,
    maghribOffset: 0,
    ishaOffset: 0,
    hijriAdjustment: 0,
    timeFormat24: true,
    fastingTrackerEnabled: false,
    fastingMonThuReminder: false,
    fastingWhiteDaysReminder: false,
    fastingReminderTime: 'evening_before',
    fastingSuhoorAlert: false,
    gpsLiveTracking: true, // Continuous Real-Time GPS Tracking enabled
    animatedBackgroundEnabled: true, // Calm Islamic animated background (clouds, gentle lighting)
    shakeToStopAdhan: true, // Shake phone to stop / silence Adhan
    shakeSensitivity: 5.5, // Acceleration threshold (m/s²): lower = lighter shake, higher = harder shake
    dailyPrayerTrackerEnabled: true, // Daily Prayer Performance Tracker (سجل تتبع الصلوات اليومية)
    dhikrReminderEnabled: true, // Daily Dhikr reminder (تنبيه أذكار الصباح والمساء)
    morningDhikrTime: '07:30', // Default morning time
    eveningDhikrTime: '17:30', // Default evening time
    dhikrReminderSound: true, // Soft gentle chime
    prayerAdhanEnabled: {
      fajr: true,
      dhuhr: true,
      asr: true,
      maghrib: true,
      isha: true,
    },
    keepDeviceAwake: true, // Keep screen and CPU awake via Wake Lock API
    allowInSilentMode: nativeAlarmBridge.isAllowInSilentMode(), // Allow Adhan in Silent & DND mode
    is_silent_mode_enabled: nativeAlarmBridge.isSilentModeEnabled(), // SharedPreferences prayer_settings sync
  };

  // Settings state persisted in localStorage
  const [settings, setSettings] = useState<SettingsState>(() => {
    try {
      const saved = localStorage.getItem('salat_user_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Morocco operates strictly on Greenwich Mean Time (GMT+0 / التوقيت العالمي)
        // Reset any legacy offsets to guarantee accurate uncorrupted Awqaf prayer times and remaining countdown
        return {
          ...defaultSettingsState,
          ...parsed,
          timezoneMode: 'gmt',
          isUserExplicitSummerTime: false,
          fajrOffset: 0,
          sunriseOffset: 0,
          dhuhrOffset: 0,
          asrOffset: 0,
          maghribOffset: 0,
          ishaOffset: 0,
        };
      }
    } catch {}
    return defaultSettingsState;
  });

  // Save settings whenever changed
  useEffect(() => {
    try {
      localStorage.setItem('salat_user_settings', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  // Synchronize city coordinates with native Android AlarmManager
  useEffect(() => {
    nativeAlarmBridge.syncCityWithNative(
      currentCity.nameAr,
      currentCity.lat,
      currentCity.lng,
      settings.timezoneMode
    );
  }, [currentCity, settings.timezoneMode]);

  // Keep Device Awake (Wake Lock API) integration
  useEffect(() => {
    if (settings.keepDeviceAwake !== false) {
      wakeLockService.setEnabled(true).catch(() => {});
    } else {
      wakeLockService.setEnabled(false).catch(() => {});
    }
  }, [settings.keepDeviceAwake]);

  // Synchronize is_silent_mode_enabled & allowInSilentMode with native SharedPreferences ("prayer_settings")
  useEffect(() => {
    nativeAlarmBridge.setSilentModeEnabled(!!settings.is_silent_mode_enabled);
  }, [settings.is_silent_mode_enabled]);

  useEffect(() => {
    nativeAlarmBridge.setAllowInSilentMode(settings.allowInSilentMode !== false);
  }, [settings.allowInSilentMode]);

  // Assigned muezzins for each prayer persisted in localStorage
  const [assignedMuezzins, setAssignedMuezzins] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('salat_assigned_muezzins');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      fajr: 'makkah_fajr',
      dhuhr: 'moroccan_traditional',
      asr: 'moroccan_traditional',
      maghrib: 'moroccan_traditional',
      isha: 'madinah_bukhari',
    };
  });

  // Save assigned muezzins whenever changed
  useEffect(() => {
    try {
      localStorage.setItem('salat_assigned_muezzins', JSON.stringify(assignedMuezzins));
    } catch {}
  }, [assignedMuezzins]);

  const [defaultMuezzinId, setDefaultMuezzinId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('salat_default_muezzin');
      if (saved) return saved;
    } catch {}
    return 'moroccan_traditional';
  });

  useEffect(() => {
    try {
      localStorage.setItem('salat_default_muezzin', defaultMuezzinId);
    } catch {}
  }, [defaultMuezzinId]);

  // Robust clock synchronization using performance.now() monotonic anchor + online NTP time sync check
  // Prevents clock drifting or freezing during mobile device sleep / background throttling
  const clockAnchorRef = React.useRef<{ perfStart: number; epochStart: number; ntpOffset: number }>({
    perfStart: typeof performance !== 'undefined' ? performance.now() : 0,
    epochStart: Date.now(),
    ntpOffset: 0,
  });

  // Calculate current synchronized epoch time
  // Strictly uses Date.now() + ntpOffset so sleep/screen-lock never freezes or skews the clock
  const getSynchronizedTime = useCallback((): number => {
    return Date.now() + clockAnchorRef.current.ntpOffset;
  }, []);

  // Live real-time clock synchronized with monotonic time and Morocco GMT standard
  const [currentTimeMs, setCurrentTimeMs] = useState<number>(() => Date.now());

  // Background network time check (timeapi.io UTC) with fallback to Date.now()
  useEffect(() => {
    let isCancelled = false;

    const syncNetworkTime = async () => {
      try {
        const t0 = Date.now();
        const res = await fetch('https://timeapi.io/api/time/current/zone?timeZone=UTC', {
          signal: AbortSignal.timeout(4000),
          cache: 'no-store',
        });
        if (!res.ok) return;
        const data = await res.json();
        const t1 = Date.now();
        const roundTrip = t1 - t0;
        
        // Parse UTC timestamp from returned server UTC payload
        const serverUtcMs = Date.UTC(
          data.year,
          data.month - 1,
          data.day,
          data.hour,
          data.minute,
          data.seconds,
          data.milliSeconds || 0
        );
        const estimatedServerNow = serverUtcMs + Math.round(roundTrip / 2);
        const offset = estimatedServerNow - t1;

        if (!isCancelled && Math.abs(offset) < 86400000) {
          // Re-anchor performance clock with validated network offset
          clockAnchorRef.current = {
            perfStart: typeof performance !== 'undefined' ? performance.now() : 0,
            epochStart: t1,
            ntpOffset: offset,
          };
          setCurrentTimeMs(estimatedServerNow);
        }
      } catch {
        // Offline or request timed out; purely keep local monotonic anchor
      }
    };

    syncNetworkTime();
    // Re-check network sync every 30 minutes when online
    const syncInterval = setInterval(syncNetworkTime, 30 * 60 * 1000);

    return () => {
      isCancelled = true;
      clearInterval(syncInterval);
    };
  }, []);

  // Initialize @capacitor/local-notifications azan-channel (importance 5, sound azan.mp3) and request permissions
  useEffect(() => {
    const setupNotifications = async () => {
      try {
        await initAdhanChannel();
        await requestAdhanPermissions();
      } catch (err) {
        console.warn('[App] Notification setup error:', err);
      }
    };
    setupNotifications();
  }, []);

  // Proactively unlock browser audio context and request notification permissions on user taps/clicks
  useEffect(() => {
    // Warm up audio context and buffers immediately
    audioAdhanService.unlockAudio();

    const handleGesture = () => {
      audioAdhanService.unlockAudio();
      audioAdhanService.startKeepAliveAudio();
      requestAdhanPermissions().catch(() => {});
      if (notificationService.isSupported() && Notification.permission === 'default') {
        notificationService.requestPermission().catch(() => {});
      }
    };
    window.addEventListener('click', handleGesture, { passive: true });
    window.addEventListener('touchstart', handleGesture, { passive: true });
    window.addEventListener('pointerdown', handleGesture, { passive: true });
    window.addEventListener('keydown', handleGesture, { passive: true });
    window.addEventListener('scroll', handleGesture, { passive: true });
    return () => {
      window.removeEventListener('click', handleGesture);
      window.removeEventListener('touchstart', handleGesture);
      window.removeEventListener('pointerdown', handleGesture);
      window.removeEventListener('keydown', handleGesture);
      window.removeEventListener('scroll', handleGesture);
    };
  }, []);

  // When user unlocks phone or returns to app tab after long inactivity:
  // Re-synchronize monotonic anchor against Date.now() and trigger immediate clock tick
  useEffect(() => {
    const handleReactivation = () => {
      const now = Date.now();
      const anchor = clockAnchorRef.current;
      // Re-anchor to prevent any timer throttling lag from sleep
      anchor.perfStart = typeof performance !== 'undefined' ? performance.now() : 0;
      anchor.epochStart = now;
      setCurrentTimeMs(now + anchor.ntpOffset);
      audioAdhanService.unlockAudio();
      audioAdhanService.startKeepAliveAudio();
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        handleReactivation();
      }
    };

    window.addEventListener('focus', handleReactivation);
    window.addEventListener('online', handleReactivation);
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      window.removeEventListener('focus', handleReactivation);
      window.removeEventListener('online', handleReactivation);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  useEffect(() => {
    // 1. Web Worker background timer: prevents mobile OS from freezing clock on screen lock
    const stopWorker = backgroundTimerService.start(() => {
      setCurrentTimeMs(getSynchronizedTime());
    });

    // 2. High-precision 500ms monotonic UI ticker
    const interval = setInterval(() => {
      setCurrentTimeMs(getSynchronizedTime());
    }, 500);

    return () => {
      stopWorker();
      clearInterval(interval);
    };
  }, [getSynchronizedTime]);

  // Target date based on today's actual civil date in Morocco + dayOffset
  const targetDate = useMemo(() => {
    const tzOffsetMs = settings.timezoneMode === 'gmt+1' ? 3600000 : 0;
    const civilDate = new Date(currentTimeMs + tzOffsetMs);
    const d = new Date(civilDate.getUTCFullYear(), civilDate.getUTCMonth(), civilDate.getUTCDate());
    if (dayOffset !== 0) {
      d.setDate(d.getDate() + dayOffset);
    }
    return d;
  }, [dayOffset, settings.timezoneMode, Math.floor((currentTimeMs + (settings.timezoneMode === 'gmt+1' ? 3600000 : 0)) / (24 * 3600 * 1000))]);

  // Formatted date string
  const dateInfo = useMemo(() => {
    return getFormattedDateInfo(targetDate, settings.hijriAdjustment);
  }, [targetDate, settings.hijriAdjustment]);

  // Prayer offsets from manual adjustment
  const prayerOffsets = useMemo<PrayerOffsets>(() => ({
    fajr: settings.fajrOffset,
    sunrise: settings.sunriseOffset,
    dhuhr: settings.dhuhrOffset,
    asr: settings.asrOffset,
    maghrib: settings.maghribOffset,
    isha: settings.ishaOffset,
  }), [
    settings.fajrOffset,
    settings.sunriseOffset,
    settings.dhuhrOffset,
    settings.asrOffset,
    settings.maghribOffset,
    settings.ishaOffset,
  ]);

  // Prayer times calculated using Moroccan Awqaf method according to selected timezoneMode (GMT) & manual offsets
  const prayers = useMemo(() => {
    return calculatePrayerTimes(targetDate, currentCity, settings.timezoneMode, prayerOffsets);
  }, [targetDate, currentCity, settings.timezoneMode, prayerOffsets]);

  // Today's actual date in Morocco civil time
  const todayDate = useMemo(() => {
    const tzOffsetMs = settings.timezoneMode === 'gmt+1' ? 3600000 : 0;
    const civilDate = new Date(currentTimeMs + tzOffsetMs);
    return new Date(civilDate.getUTCFullYear(), civilDate.getUTCMonth(), civilDate.getUTCDate());
  }, [currentTimeMs, settings.timezoneMode]);

  // Today's real prayer times (strictly for the live scheduler synchronized with Morocco GMT)
  const todayRealPrayers = useMemo(() => {
    return calculatePrayerTimes(todayDate, currentCity, settings.timezoneMode, prayerOffsets);
  }, [todayDate, currentCity, settings.timezoneMode, prayerOffsets]);

  // Tomorrow's real prayer times (for exact tomorrow Fajr calculation when Isha has passed)
  const tomorrowRealPrayers = useMemo(() => {
    const tomorrow = new Date(todayDate);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return calculatePrayerTimes(tomorrow, currentCity, settings.timezoneMode, prayerOffsets);
  }, [todayDate, currentCity, settings.timezoneMode, prayerOffsets]);

  // Schedule hardware exact alarms on Android via native AlarmManager & @capacitor/local-notifications
  useEffect(() => {
    nativeAlarmBridge.scheduleDailyPrayers(
      todayRealPrayers,
      todayDate,
      tomorrowRealPrayers,
      settings.timezoneMode
    );
    backgroundTimerService.scheduleNextAdhan(currentCity, prayerOffsets, settings.timezoneMode);
  }, [todayRealPrayers, todayDate, tomorrowRealPrayers, settings.timezoneMode, currentCity, prayerOffsets]);

  // Dual Adhan & Alert Scheduler: 1) Pre-Prayer Alert (5m before) & 2) Exact Prayer Time Full Adhan (0m)
  useEffect(() => {
    // Time of day synchronized with selected timezoneMode (GMT / GMT+1)
    const currentSecToday = getSecondsForTimezone(currentTimeMs, settings.timezoneMode);
    const curH = Math.floor(currentSecToday / 3600);
    const curM = Math.floor((currentSecToday % 3600) / 60);
    const currentHHMM = `${String(curH).padStart(2, '0')}:${String(curM).padStart(2, '0')}`;
    const alertMinutes = settings.prePrayerAlertMinutes || 5;
    const alertSec = alertMinutes * 60;

    todayRealPrayers.forEach((prayer) => {
      // Exclude sunrise from the 5 obligatory prayer adhans
      if (prayer.id === 'sunrise') return;

      const [h, m] = prayer.time.split(':').map(Number);
      const prayerSec = h * 3600 + m * 60;
      const diffSec = prayerSec - currentSecToday;

      const assignedId =
        assignedMuezzins[prayer.id] || settings.adhanSound || 'moroccan_traditional';
      const muezzin = MUEZZINS_LIST.find((m) => m.id === assignedId) || MUEZZINS_LIST[0];

      // Check if sound is active for this prayer specifically and not silenced globally
      const isPrayerSoundActive = !settings.is_silent_mode_enabled && (
        settings.prayerAdhanEnabled ? settings.prayerAdhanEnabled[prayer.id] !== false : true
      );

      // Preload the upcoming Adhan audio in advance (e.g. 10 minutes before) for 0ms delay
      if (diffSec > 0 && diffSec <= 600) {
        notificationService.preloadUpcomingAdhan(assignedId, prayer.id === 'fajr');
        audioAdhanService.preloadAudioBuffer(muezzin.audioUrl).catch(() => {});
      }

      // 2 minutes before prayer: Pre-warm audio engine & acquire WakeLock so device does not sleep
      if (diffSec > 0 && diffSec <= 120) {
        audioAdhanService.unlockAudio();
        backgroundTimerService.acquireWakeLock();
      }

      // 1. EXACT PRAYER TIME (0 minutes / Entry of Prayer Time): Play Full Chosen Real Adhan strictly on time!
      // Triggers precisely when Morocco timezone time reaches the prayer time (within 1-minute window)
      const isTimeForPrayer =
        currentHHMM === prayer.time &&
        (diffSec <= 0 && diffSec >= -60);

      if (isTimeForPrayer) {
        notificationService.triggerActualPrayerAdhan(
          prayer.id,
          prayer.nameAr,
          prayer.time,
          currentCity.nameAr,
          assignedId,
          muezzin.nameAr,
          isPrayerSoundActive
        );
      }

      // 2. PRE-PRAYER ALERT (e.g. 5 minutes before): Soft reminder alert
      if (settings.prePrayerAlertEnabled && diffSec > 0 && diffSec <= alertSec && diffSec >= alertSec - 45) {
        notificationService.triggerAlert(
          {
            id: `${prayer.id}_pre_${prayer.time}`,
            prayerNameAr: prayer.nameAr,
            cityNameAr: currentCity.nameAr,
            minutesRemaining: alertMinutes,
            prayerTime: prayer.time,
            timestamp: Date.now(),
          },
          settings.notificationsEnabled
        );
      }
    });

    // 3. DAILY MORNING & EVENING DHIKR REMINDERS
    if (settings.dhikrReminderEnabled) {
      const dhikrSec = getSecondsForTimezone(currentTimeMs, settings.timezoneMode);
      const dhikrH = Math.floor(dhikrSec / 3600);
      const dhikrM = Math.floor((dhikrSec % 3600) / 60);
      const currentHHMM = `${String(dhikrH).padStart(2, '0')}:${String(dhikrM).padStart(2, '0')}`;
      const morningTime = settings.morningDhikrTime || '07:30';
      const eveningTime = settings.eveningDhikrTime || '17:30';

      if (currentHHMM === morningTime) {
        notificationService.triggerDhikrReminder('morning', settings.dhikrReminderSound ?? true);
      } else if (currentHHMM === eveningTime) {
        notificationService.triggerDhikrReminder('evening', settings.dhikrReminderSound ?? true);
      }
    }
  }, [
    currentTimeMs,
    todayRealPrayers,
    currentCity.nameAr,
    settings.prePrayerAlertEnabled,
    settings.prePrayerAlertMinutes,
    settings.notificationsEnabled,
    settings.adhanSound,
    settings.dhikrReminderEnabled,
    settings.morningDhikrTime,
    settings.eveningDhikrTime,
    settings.dhikrReminderSound,
    assignedMuezzins,
  ]);

  // Geolocation auto-detect nearest city with Haversine formula and instant visual feedback
  const handleAutoLocate = useCallback((isManual = false) => {
    if (!navigator.geolocation) {
      setGpsStatusMessage('متصفحك لا يدعم خاصية تحديد الموقع الجغرافي (GPS)');
      return;
    }
    setIsLocating(true);
    setGpsStatusMessage('جاري الاتصال بالأقمار الاصطناعية وتحديد موقعك الدقيق...');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        const { city } = findNearestMoroccoCity(latitude, longitude);

        setCurrentCity({
          ...city,
          lat: latitude,
          lng: longitude,
        });

        setIsLocating(false);
        const msg = `✓ تم تحديد موقعك بدقة: ${city.nameAr} (${city.region}) • الدقة: ±${Math.round(accuracy)}م`;
        setGpsStatusMessage(msg);
        setGpsToast({
          message: isManual
            ? `تم تحديث المواقيت بنجاح لمدينة ${city.nameAr}`
            : `تم رصد موقعك: ${city.nameAr}`,
          cityName: city.nameAr,
          regionName: city.region,
        });
      },
      (error) => {
        setIsLocating(false);
        let errorMsg = 'تعذر الوصول إلى إشارة الموقع';
        if (error.code === error.PERMISSION_DENIED) {
          errorMsg = 'تم رفض إذن الموقع. يرجى تفعيل إذن الـ GPS في إعدادات هاتفك والمتصفح.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errorMsg = 'خدمة GPS غير متوفرة حالياً، يرجى تفعيل الموقع في هاتفك.';
        } else if (error.code === error.TIMEOUT) {
          errorMsg = 'انتهت مهلة انتظار إشارة GPS، يرجى المحاولة في مكان مفتوح.';
        }
        setGpsStatusMessage(errorMsg);
      },
      { timeout: 12000, enableHighAccuracy: true, maximumAge: 0 }
    );
  }, []);

  // Automatically locate via GPS on app startup so location & Adhan times match user's real location anywhere
  useEffect(() => {
    if (settings.gpsLiveTracking !== false && typeof navigator !== 'undefined' && navigator.geolocation) {
      handleAutoLocate(false);
    }
  }, [handleAutoLocate, settings.gpsLiveTracking]);

  // Continuous Real-Time GPS Tracking when traveling across Morocco
  useEffect(() => {
    if (settings.gpsLiveTracking === false || !navigator.geolocation) return;

    let lastLat = 0;
    let lastLng = 0;

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;

        // Skip micro-movements of less than 2.5 km
        if (lastLat !== 0 && lastLng !== 0) {
          const dist = calculateDistanceKm(lastLat, lastLng, latitude, longitude);
          if (dist < 2.5) return;
        }

        lastLat = latitude;
        lastLng = longitude;

        const { city } = findNearestMoroccoCity(latitude, longitude);

        setCurrentCity((prev) => {
          if (prev.id !== city.id) {
            setGpsToast({
              message: `تم رصد انتقالك إلى: ${city.nameAr} (${city.region})`,
              cityName: city.nameAr,
              regionName: city.region,
            });
            setGpsStatusMessage(`GPS نشط • الموقع الحالي: ${city.nameAr}`);
          }
          return {
            ...city,
            lat: latitude,
            lng: longitude,
          };
        });
      },
      (err) => {
        console.warn('GPS Live watch:', err.message);
      },
      {
        enableHighAccuracy: true,
        maximumAge: 10000,
        timeout: 15000,
      }
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, [settings.gpsLiveTracking]);

  // Auto-dismiss GPS toast notification after 6 seconds
  useEffect(() => {
    if (!gpsToast) return;
    const timer = setTimeout(() => {
      setGpsToast(null);
    }, 6000);
    return () => clearTimeout(timer);
  }, [gpsToast]);

  const handleUpdateSettings = (newSettings: Partial<SettingsState>) => {
    setSettings((prev) => {
      const updated = {
        ...prev,
        ...newSettings,
        ...(newSettings.timezoneMode !== undefined
          ? { isUserExplicitSummerTime: newSettings.timezoneMode === 'gmt+1' }
          : {}),
      };
      if (newSettings.adhanSound) {
        setDefaultMuezzinId(newSettings.adhanSound);
        setAssignedMuezzins((prevMuezzins) => ({
          ...prevMuezzins,
          dhuhr: newSettings.adhanSound!,
          asr: newSettings.adhanSound!,
          maghrib: newSettings.adhanSound!,
          isha: newSettings.adhanSound!,
          fajr: newSettings.adhanSound === 'makkah_fajr' ? 'makkah_fajr' : newSettings.adhanSound!,
        }));
      }
      return updated;
    });
  };

  return (
    <LanguageProvider>
      <ThemeProvider
        themeMode={settings.themeMode || 'auto'}
        onThemeModeChange={(mode) => handleUpdateSettings({ themeMode: mode })}
        prayers={prayers}
        currentTimeMs={currentTimeMs}
      >
        <AppContent
          currentCity={currentCity}
          setCurrentCity={setCurrentCity}
          targetDate={targetDate}
          dayOffset={dayOffset}
          setDayOffset={setDayOffset}
          dateInfo={dateInfo}
          prayers={prayers}
          todayRealPrayers={todayRealPrayers}
          tomorrowRealPrayers={tomorrowRealPrayers}
          settings={settings}
          handleUpdateSettings={handleUpdateSettings}
          currentTimeMs={currentTimeMs}
          handleAutoLocate={() => handleAutoLocate(true)}
          isLocating={isLocating}
          gpsStatusMessage={gpsStatusMessage}
          gpsToast={gpsToast}
          onDismissGpsToast={() => setGpsToast(null)}
          assignedMuezzins={assignedMuezzins}
          setAssignedMuezzins={setAssignedMuezzins}
          defaultMuezzinId={defaultMuezzinId}
          setDefaultMuezzinId={setDefaultMuezzinId}
        />
      </ThemeProvider>
    </LanguageProvider>
  );
}
