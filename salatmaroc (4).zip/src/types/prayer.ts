export interface PrayerTimeItem {
  id: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
  nameAr: string;
  nameEn: string;
  time: string; // e.g. "19:15" - Official approved time (التوقيت المعتمد)
  timestamp: number; // millisecond timestamp of prayer on selected date
  sunsetTime?: string; // e.g. "19:13" - Astronomical sunset (وقت غروب قرص الشمس الفلكي)
  isNext?: boolean;
  isPassed?: boolean;
}

export interface CityData {
  id: string;
  nameAr: string;
  nameFr: string;
  region: string;
  lat: number;
  lng: number;
  offsetMinutes: number; // Awqaf offset relative to Casablanca/Rabat if applicable
}

export interface HadithItem {
  id: string;
  text: string;
  narrator: string;
  source: string;
  chapter?: string;
}

export interface DhikrItem {
  id: string;
  category: 'morning' | 'evening' | 'after_prayer' | 'sleep';
  categoryAr: string;
  arabic: string;
  count: number;
  virtue?: string;
  reference?: string;
}

export interface SettingsState {
  adhanSound: string; // ID of selected Muezzin / Adhan sound from MUEZZINS_LIST
  themeMode: 'auto' | 'dark' | 'light'; // Automatic day/night according to sunrise & sunset
  notificationsEnabled: boolean;
  prePrayerAlertEnabled: boolean; // Pre-prayer alert (browser notification & alert)
  prePrayerAlertMinutes: number; // e.g. 5 minutes before
  timezoneMode: 'gmt' | 'gmt+1'; // Default: 'gmt' (توقيت غرينتش)
  isUserExplicitSummerTime?: boolean; // Set true only if user explicitly selects GMT+1 summer time
  autoSettings: boolean;
  fajrOffset: number;
  sunriseOffset: number;
  dhuhrOffset: number;
  asrOffset: number;
  maghribOffset: number;
  ishaOffset: number;
  hijriAdjustment: number; // e.g. 0, -1, +1
  timeFormat24: boolean;
  fastingTrackerEnabled: boolean; // Optional Fasting & Iftar tracker for Ramadan and voluntary fasting
  fastingMonThuReminder: boolean; // Reminder for Monday & Thursday fasting
  fastingWhiteDaysReminder: boolean; // Reminder for White Days (13, 14, 15 Hijri)
  fastingReminderTime: 'evening_before' | 'suhoor' | 'both'; // Time to alert
  fastingSuhoorAlert: boolean; // Wakeup alert before Fajr
  gpsLiveTracking: boolean; // Continuous real-time GPS tracking when moving across Morocco
  animatedBackgroundEnabled: boolean; // Calm Islamic animated background (clouds, ambient light) with battery saving option
  shakeToStopAdhan: boolean; // Stop / silence Adhan when shaking the phone
  shakeSensitivity?: number; // Acceleration threshold (m/s²): 3.0 (light) to 12.0 (strong), default 5.5
  dailyPrayerTrackerEnabled: boolean; // سجل تتبع الصلوات اليومية (أديتها في وقتها، جماعة، أو فائتة)
  dhikrReminderEnabled?: boolean; // تفعيل تنبيه أذكار الصباح والمساء
  morningDhikrTime?: string; // توقيت تنبيه أذكار الصباح (مثال: '07:30')
  eveningDhikrTime?: string; // توقيت تنبيه أذكار المساء (مثال: '17:30')
  dhikrReminderSound?: boolean; // تشغيل نغمة خفيفة وهادئة مع التنبيه
  prayerAdhanEnabled?: Record<string, boolean>; // تفعيل أو تعطيل الأذان لكل صلاة بشكل مستقل
  keepDeviceAwake?: boolean; // منع المتصفح من إدخال التطبيق في السكون العميق عبر Wake Lock API
  allowInSilentMode?: boolean; // تشغيل الأذان حتى في الوضع الصامت وعدم الإزعاج
  is_silent_mode_enabled?: boolean; // تفعيل الوضع الصامت وحفظه في SharedPreferences باسم prayer_settings
  adhanAlertMethod?: 'lock_window_unlocked_notification' | 'window' | 'notification'; // طريقة التنبيه بموعد الأذان (نافذة عند قفل الهاتف، وتنبيه إذا كان مفتوحا)
}

export type PrayerRecordStatus = 'on_time' | 'jamaah' | 'qadaa' | 'missed' | 'none';

export interface DailyPrayerRecord {
  dateKey: string; // YYYY-MM-DD
  fajr: PrayerRecordStatus;
  dhuhr: PrayerRecordStatus;
  asr: PrayerRecordStatus;
  maghrib: PrayerRecordStatus;
  isha: PrayerRecordStatus;
}
