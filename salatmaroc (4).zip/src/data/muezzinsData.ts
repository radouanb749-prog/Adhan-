export interface MuezzinItem {
  id: string;
  nameAr: string;
  nameEn?: string;
  muezzinName: string;
  locationAr: string;
  descriptionAr: string;
  audioUrl: string;
  isFajr?: boolean;
}

export const MUEZZINS_LIST: MuezzinItem[] = [
  {
    id: 'moroccan_traditional',
    nameAr: 'الأذان المغربي الأصيل',
    muezzinName: 'مؤذنو مساجد المملكة المغربية',
    locationAr: 'المملكة المغربية',
    descriptionAr: 'الصيغة الأندلسية المغربية العريقة المعتمدة في مساجد المغرب',
    audioUrl: '/audio/adhan-morocco.mp3',
  },
  {
    id: 'makkah_mulla',
    nameAr: 'أذان الحرم المكي الشريف',
    muezzinName: 'الشيخ علي أحمد ملا',
    locationAr: 'مكة المكرمة - الحرم المكي',
    descriptionAr: 'شيخ مؤذني المسجد الحرام لأكثر من أربعة عقود بالنبرة المكية الحجازية',
    audioUrl: '/audio/adhan-makkah.mp3',
  },
  {
    id: 'madinah_bukhari',
    nameAr: 'أذان المسجد النبوي الشريف',
    muezzinName: 'الشيخ عصام بخاري / فاروق حضراوي',
    locationAr: 'المدينة المنورة - المسجد النبوي',
    descriptionAr: 'أذان الحرم النبوي بنبرة مدنية روحانية خاشعة',
    audioUrl: '/audio/adhan-madinah.mp3',
  },
  {
    id: 'al_aqsa',
    nameAr: 'أذان المسجد الأقصى المبارك',
    muezzinName: 'مؤذنو المسجد الأقصى',
    locationAr: 'القدس الشريف - فلسطين',
    descriptionAr: 'أذان القدس الخالد من مآذن المسجد الأقصى وقبة الصخرة',
    audioUrl: 'https://ia800204.us.archive.org/11/items/athan_alaqsa/athan_alaqsa.mp3',
  },
  {
    id: 'makkah_fajr',
    nameAr: 'أذان الفجر من الحرم المكي',
    muezzinName: 'مؤذنو الحرم المكي',
    locationAr: 'مكة المكرمة (خاص بصلاة الفجر)',
    descriptionAr: 'يشمل التثويب: (الصَّلَاةُ خَيْرٌ مِنَ النَّوْمِ)',
    audioUrl: '/audio/adhan-fajr.mp3',
    isFajr: true,
  },
  {
    id: 'qatami_fajr',
    nameAr: 'أذان الفجر - ناصر القطامي',
    muezzinName: 'ناصر القطامي (فجر)',
    locationAr: 'الرياض - المملكة العربية السعودية',
    descriptionAr: 'أذان الفجر الخاشع بصوت الشيخ ناصر القطامي مع التثويب',
    audioUrl: '/audio/adhan-fajr.mp3',
    isFajr: true,
  },
  {
    id: 'deghreri',
    nameAr: 'أذان الشيخ حمد دغريري',
    muezzinName: 'حمد دغريري',
    locationAr: 'مكة المكرمة - الحرم المكي',
    descriptionAr: 'مؤذن المسجد الحرام الشريف بنبرة حجازية رخيمة',
    audioUrl: 'https://ia800708.us.archive.org/30/items/AdhanDeghreri/adhan_deghreri.mp3',
  },
  {
    id: 'abdulbasit',
    nameAr: 'أذان الشيخ عبد الباسط عبد الصمد',
    muezzinName: 'الشيخ عبد الباسط عبد الصمد',
    locationAr: 'جمهورية مصر العربية',
    descriptionAr: 'تلاوة وأذان بأعلى درجات الخشوع وصوت السماء الشهير',
    audioUrl: 'https://ia800301.us.archive.org/15/items/AdhanAbdulBasit/adhan_abdulbasit.mp3',
  },
  {
    id: 'alafasy',
    nameAr: 'أذان الشيخ مشاري بن راشد العفاسي',
    muezzinName: 'الشيخ مشاري راشد العفاسي',
    locationAr: 'دولة الكويت',
    descriptionAr: 'أداء ندي وصوت عذب ذائع الصيت في العالم الإسلامي',
    audioUrl: 'https://ia800201.us.archive.org/12/items/Athan_Alafasy/Athan_Alafasy.mp3',
  },
  {
    id: 'qatami',
    nameAr: 'أذان الشيخ ناصر القطامي',
    muezzinName: 'الشيخ ناصر القطامي',
    locationAr: 'الرياض - المملكة العربية السعودية',
    descriptionAr: 'أذان هادئ ومؤثر يبعث على الطمأنينة والسكينة',
    audioUrl: '/audio/adhan-qatami.mp3',
  },
  {
    id: 'zahrani',
    nameAr: 'أذان الشيخ منصور الزهراني',
    muezzinName: 'الشيخ منصور الزهراني',
    locationAr: 'المملكة العربية السعودية',
    descriptionAr: 'نبرة حجازية أصيلة ومحبوبة',
    audioUrl: 'https://ia800708.us.archive.org/30/items/AdhanZahrani/adhan_zahrani.mp3',
  },
  {
    id: 'turkey_istanbul',
    nameAr: 'الأذان التركي من إسطنبول',
    muezzinName: 'الشيخ حافظ مصطفى أوزجان',
    locationAr: 'إسطنبول - تركيا',
    descriptionAr: 'أداء بديع من مساجد إسطنبول بمقام الصبا والحجاز',
    audioUrl: 'https://ia800305.us.archive.org/24/items/TurkishAdhan/turkish_adhan.mp3',
  },
];
