import { useEffect, useRef } from 'react';

interface UseShakeOptions {
  threshold?: number; // Acceleration delta threshold (default 5.5 m/s^2)
  timeout?: number; // Debounce timeout between triggered shakes (ms, default 1000)
  enabled?: boolean;
  onShake: () => void;
}

// Request permission on iOS 13+ devices
export async function requestMotionPermission(): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  try {
    const DME = (window as unknown as {
      DeviceMotionEvent?: { requestPermission?: () => Promise<'granted' | 'denied'> };
    }).DeviceMotionEvent;

    if (DME && typeof DME.requestPermission === 'function') {
      const res = await DME.requestPermission();
      return res === 'granted';
    }
    return true;
  } catch (err) {
    console.warn('DeviceMotion permission error:', err);
    return false;
  }
}

export function useShakeDetector({
  threshold = 5.5,
  timeout = 1000,
  enabled = true,
  onShake,
}: UseShakeOptions) {
  const onShakeRef = useRef(onShake);
  onShakeRef.current = onShake;

  const lastShakeTime = useRef<number>(0);
  const shakeCount = useRef<number>(0);
  const lastShakePeakTime = useRef<number>(0);

  // Time-windowed tracking for accelerometer (100ms intervals)
  const lastSampleTime = useRef<number>(0);
  const lastX = useRef<number | null>(null);
  const lastY = useRef<number | null>(null);
  const lastZ = useRef<number | null>(null);

  // Time-windowed tracking for gyroscope / tilt
  const lastOrientTime = useRef<number>(0);
  const lastGamma = useRef<number | null>(null);
  const lastBeta = useRef<number | null>(null);

  useEffect(() => {
    if (!enabled || typeof window === 'undefined') return;

    // Auto-request iOS permission on user touch if needed
    const autoRequestPermission = () => {
      requestMotionPermission();
      window.removeEventListener('touchstart', autoRequestPermission);
      window.removeEventListener('click', autoRequestPermission);
    };
    window.addEventListener('touchstart', autoRequestPermission, { passive: true });
    window.addEventListener('click', autoRequestPermission, { passive: true });

    const triggerShake = (source: string = 'motion') => {
      const now = Date.now();
      if (now - lastShakeTime.current > timeout) {
        lastShakeTime.current = now;
        shakeCount.current = 0;
        console.log(`[useShakeDetector] Triggering onShake via ${source}! (timeout: ${timeout}ms)`);
        onShakeRef.current();
      }
    };

    // 1. DeviceMotionEvent (Accelerometer)
    const handleMotion = (event: DeviceMotionEvent) => {
      const now = Date.now();

      // Check method A: Linear acceleration without gravity (most accurate when provided by browser)
      if (event.acceleration && event.acceleration.x !== null) {
        const lx = event.acceleration.x || 0;
        const ly = event.acceleration.y || 0;
        const lz = event.acceleration.z || 0;
        const linearMag = Math.sqrt(lx * lx + ly * ly + lz * lz);

        if (linearMag > threshold) {
          if (now - lastShakePeakTime.current > 100 && now - lastShakePeakTime.current < 850) {
            shakeCount.current += 1;
            console.log('[useShakeDetector] Method A peak #', shakeCount.current, 'linearMag:', linearMag.toFixed(2));
            if (shakeCount.current >= 2) {
              triggerShake('linear-acceleration');
              return;
            }
          } else if (now - lastShakePeakTime.current >= 850) {
            shakeCount.current = 1;
          }
          lastShakePeakTime.current = now;
        }
      }

      // Check method B: Acceleration including gravity (difference from resting gravity 9.8 m/s^2)
      const acc = event.accelerationIncludingGravity;
      if (acc && acc.x !== null && acc.y !== null && acc.z !== null) {
        const x = acc.x;
        const y = acc.y;
        const z = acc.z;
        const totalMag = Math.sqrt(x * x + y * y + z * z);
        const diffFromGravity = Math.abs(totalMag - 9.806);

        if (diffFromGravity > threshold) {
          if (now - lastShakePeakTime.current > 100 && now - lastShakePeakTime.current < 850) {
            shakeCount.current += 1;
            console.log('[useShakeDetector] Method B gravity peak #', shakeCount.current, 'diff:', diffFromGravity.toFixed(2));
            if (shakeCount.current >= 2) {
              triggerShake('gravity-deviation');
              return;
            }
          } else if (now - lastShakePeakTime.current >= 850) {
            shakeCount.current = 1;
          }
          lastShakePeakTime.current = now;
        }

        // Method C: Windowed velocity delta (over 90-150ms window)
        if (now - lastSampleTime.current > 90) {
          if (lastX.current !== null && lastY.current !== null && lastZ.current !== null) {
            const deltaX = Math.abs(x - lastX.current);
            const deltaY = Math.abs(y - lastY.current);
            const deltaZ = Math.abs(z - lastZ.current);
            const deltaSum = deltaX + deltaY + deltaZ;

            if (deltaSum > threshold * 1.5) {
              console.log('[useShakeDetector] Method C delta window triggered:', deltaSum.toFixed(2));
              triggerShake('windowed-delta');
              return;
            }
          }
          lastX.current = x;
          lastY.current = y;
          lastZ.current = z;
          lastSampleTime.current = now;
        }
      }
    };

    // 2. DeviceOrientationEvent (Tilt / Gyroscope fallback for devices where acceleration is restricted)
    const handleOrientation = (event: DeviceOrientationEvent) => {
      const now = Date.now();
      const gamma = event.gamma; // [-90, 90]
      const beta = event.beta; // [-180, 180]

      if (gamma === null || beta === null) return;

      // Sample tilt every 100ms
      if (now - lastOrientTime.current > 100) {
        if (lastGamma.current !== null && lastBeta.current !== null) {
          const deltaGamma = Math.abs(gamma - lastGamma.current);
          const deltaBeta = Math.abs(beta - lastBeta.current);
          const totalAngularChange = deltaGamma + deltaBeta;

          // If the phone rotated/swung more than 28 degrees in 100ms (fast shake gesture)
          if (totalAngularChange > 28) {
            triggerShake();
          }
        }
        lastGamma.current = gamma;
        lastBeta.current = beta;
        lastOrientTime.current = now;
      }
    };

    window.addEventListener('devicemotion', handleMotion, { passive: true });
    window.addEventListener('deviceorientation', handleOrientation, { passive: true });

    return () => {
      window.removeEventListener('devicemotion', handleMotion);
      window.removeEventListener('deviceorientation', handleOrientation);
      window.removeEventListener('touchstart', autoRequestPermission);
      window.removeEventListener('click', autoRequestPermission);
      lastX.current = null;
      lastY.current = null;
      lastZ.current = null;
      lastGamma.current = null;
      lastBeta.current = null;
      shakeCount.current = 0;
    };
  }, [enabled, threshold, timeout]);
}
