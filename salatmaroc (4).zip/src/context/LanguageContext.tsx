import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'ar' | 'en';

export interface Translations {
  // Navigation & General
  today: string;
  virtues: string;
  qibla: string;
  more: string;
  moreOptions: string;
  settings: string;
  backToToday: string;
  previousDay: string;
  nextDay: string;
  stopAdhan: string;
  listenAdhan: string;
  adhanPreview: string;
  loading: string;
  close: string;
  save: string;
  cancel: string;
  success: string;
  copied: string;
  
  // Prayer names
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
  
  // Next prayer and countdown
  nextPrayerLabel: string;
  nextBadge: string;
  remaining: string;
  hoursShort: string;
  minutesShort: string;
  secondsShort: string;
  adhanMaghribIftar: string;
  adhanFajrImsak: string;
  prayerOf: string;
  
  // Timezone and city
  gmt: string;
  gmtSummer: string;
  locateCity: string;
  citySettings: string;
  autoGpsTravel: string;
  autoGpsTravelDesc: string;
  gpsActive: string;
  gpsManual: string;
  locatingGps: string;
  locateGpsNow: string;
  changeCityManual: string;
  
  // Settings & features
  adjustPrayerTimes: string;
  adjustPrayerTimesDesc: string;
  adjustNewBadge: string;
  adhanSettings: string;
  adhanSettingsDesc: string;
  adhanCustomBadge: string;
  adhanLog: string;
  adhanLogDesc: string;
  dailyTracker: string;
  dailyTrackerDesc: string;
  dailyTrackerBadge: string;
  prePrayerAlert: string;
  prePrayerAlertDesc: string;
  prePrayerMinutes: string;
  prePrayerTest: string;
  browserPermissionAllowed: string;
  browserPermissionRequest: string;
  dhikrReminder: string;
  dhikrReminderDesc: string;
  dhikrMorning: string;
  dhikrEvening: string;
  dhikrSound: string;
  dhikrTestMorning: string;
  dhikrTestEvening: string;
  timezoneSettings: string;
  timezoneDesc: string;
  themeTitle: string;
  themeDesc: string;
  themeAuto: string;
  themeDark: string;
  themeLight: string;
  themeAutoDesc: string;
  themeLightDesc: string;
  themeDarkDesc: string;
  animatedBgTitle: string;
  animatedBgDesc: string;
  animatedBgActive: string;
  animatedBgBattery: string;
  animatedBgToggle: string;
  animatedBgToggleDesc: string;
  shakeTitle: string;
  shakeDesc: string;
  shakeActive: string;
  shakeDisabled: string;
  shakeToggle: string;
  shakeToggleDesc: string;
  shakeSensitivity: string;
  shakeTestBtn: string;
  shakeTestingActive: string;
  wakeLockTitle: string;
  wakeLockDesc: string;
  wakeLockActive: string;
  wakeLockDisabled: string;
  wakeLockToggle: string;
  wakeLockToggleDesc: string;
  wakeLockNotSupported: string;
  bgAlarmTestTitle: string;
  bgAlarmTestDesc: string;
  bgAlarmTestBtn: string;
  bgAlarmTestCounting: string;
  pwaInstallTitle: string;
  pwaInstallDesc: string;
  pwaBadge: string;
  appLanguage: string;
  chooseAppLang: string;
  arabicLang: string;
  englishLang: string;

  // More menu bottom sheet
  tasbeeh: string;
  tasbeehDesc: string;
  tasbeehBadge: string;
  virtuesTitle: string;
  virtuesDesc: string;
  adhkarMenuTitle: string;
  adhkarMenuDesc: string;
  hadithsMenuTitle: string;
  hadithsMenuDesc: string;
  monthlyMenuTitle: string;
  monthlyMenuDesc: string;
  settingsMenuTitle: string;
  settingsMenuDesc: string;
  downloadZipTitle: string;
  downloadZipDesc: string;
  supervisorBadge: string;

  // Additional Settings & Options
  chooseAdhanSound: string;
  chooseAdhanSoundDesc: string;
  customSelection: string;
  currentAdhanSelected: string;
  stopPreview: string;
  playPreview: string;
  prayerNotifications: string;
  prayerNotificationsDesc: string;
  hijriAdjustment: string;
  hijriAdjustmentDesc: string;
  hijriOfficial: string;
  day: string;
  days: string;
  moroccoCalcInfo: string;
  moroccoCalcDesc: string;
  supervisorLogin: string;
  saved: string;
  saveDone: string;
  presets: string;
  errorsRecorded: string;
  healthyAndActive: string;
  themeCurrentAuto: string;
  themeCurrentLight: string;
  themeCurrentDark: string;
  shakeLight: string;
  shakeBalanced: string;
  shakeFirm: string;
  shakeTestSuccess: string;

  // Inside Adhan Settings Modal
  adhanSettingsTitle: string;
  back: string;
  audioTest: string;
  stopAdhanBtn: string;
  silentModeAlert: string;
  silentModeAlertDesc: string;
  stopShortcuts: string;
  stopShortcutsDesc: string;
  stopByVolume: string;
  stopByVolumeDesc: string;
  stopByShake: string;
  stopByShakeDesc: string;
  stopByFlip: string;
  stopByFlipDesc: string;
  fridayAdhan: string;
  fridayAdhanDesc: string;
  silentNotification: string;
  silentNotificationDesc: string;
  assignedMuezzinsTitle: string;
  assignedMuezzinsDesc: string;
  changeMuezzin: string;
  allPrayers: string;

  // Inside Prayer Times Adjust Modal
  prayerTimesAdjustTitle: string;
  autoSettings: string;
  autoSettingsDesc: string;
  fineTuneMinutes: string;
  fineTuneMinutesDesc: string;
  resetAll: string;
  minute: string;
  minutesPlural: string;

  // Cities Modal
  selectCityTitle: string;
  searchCityPlaceholder: string;
  noCitiesFound: string;
  currentLocationGps: string;

  // Adhan Log Modal
  adhanLogTitle: string;
  adhanLogSubtitle: string;
  totalAdhansPlayed: string;
  successfulPlays: string;
  failedPlays: string;
  lastAdhanTime: string;
  clearLog: string;
  emptyLog: string;

  // Share App & Schedule
  share: string;
  shareTitle: string;
  shareDesc: string;
  shareViaApps: string;
  copySchedule: string;
  copyAppLink: string;
  shareWhatsApp: string;
  scheduleCopied: string;
  linkCopied: string;
}

const translationsAr: Translations = {
  today: 'اليوم',
  virtues: 'فضل الصلاة',
  qibla: 'القبلة',
  more: 'المزيد',
  moreOptions: 'المزيد من الخيارات',
  settings: 'الإعدادات',
  backToToday: 'العودة لليوم',
  previousDay: 'اليوم السابق',
  nextDay: 'اليوم التالي',
  stopAdhan: 'إيقاف الأذان ⏹',
  listenAdhan: 'الأذان',
  adhanPreview: 'استماع للأذان',
  loading: 'جاري التحميل...',
  close: 'إغلاق',
  save: 'حفظ',
  cancel: 'إلغاء',
  success: 'تم بنجاح',
  copied: 'تم النسخ',

  fajr: 'الفجر',
  sunrise: 'الشروق',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',

  nextPrayerLabel: 'الصلاة القادمة',
  nextBadge: 'القادمة',
  remaining: 'المتبقي:',
  hoursShort: 'س',
  minutesShort: 'د',
  secondsShort: 'ث',
  adhanMaghribIftar: 'أذان المغرب (الإفطار)',
  adhanFajrImsak: 'أذان الفجر (الإمساك)',
  prayerOf: 'صلاة',

  gmt: 'توقيت غرينتش (GMT+0) ★',
  gmtSummer: 'التوقيت الصيفي (GMT+1)',
  locateCity: 'تحديد الموقع الجغرافي',
  citySettings: 'إعدادات الموقع والمدينة',
  autoGpsTravel: 'التعديل التلقائي للمواقيت عند التنقل (GPS Live)',
  autoGpsTravelDesc: 'يتم تحديث مواقيت الصلاة تلقائياً عند السفر والتنقل بين مدن ومناطق المملكة المغربية',
  gpsActive: 'GPS نشط وتلقائي',
  gpsManual: 'محدد يدوياً',
  locatingGps: 'جاري الاتصال بالـ GPS...',
  locateGpsNow: 'تحديد عبر GPS الآن',
  changeCityManual: 'تغيير المدينة يدوياً',

  adjustPrayerTimes: 'تعديل أوقات الصلاة',
  adjustPrayerTimesDesc: 'تعديل دقيق لدقائق الفجر، الظهر، العصر، المغرب، العشاء (+ / -)',
  adjustNewBadge: 'جديد',
  adhanSettings: 'إعدادات الأذان واختيار المؤذن لكل صلاة',
  adhanSettingsDesc: 'تخصيص مؤذن مستقل لكل صلاة (الفجر، الظهر، العصر، المغرب، العشاء)',
  adhanCustomBadge: 'مخصص',
  adhanLog: 'سجل نشاط الأذان (Adhan Log)',
  adhanLogDesc: 'متابعة دقة تشغيل الأذان في مواعيده والتحقق من سلامة الملف الصوتي',
  dailyTracker: 'سجل تتبع الصلوات اليومية',
  dailyTrackerDesc: 'تتبع أداء صلواتك الخمس يومياً (في وقتها، جماعة في المسجد، أو قضاءً) مع رصد الصلوات الفائتة',
  dailyTrackerBadge: 'متابعة الفريضة',
  prePrayerAlert: 'تنبيه وإشعارات المتصفح قبل الصلاة',
  prePrayerAlertDesc: 'إشعار ورنين قبل كل صلاة بعدة دقائق',
  prePrayerMinutes: 'وقت التنبيه المسبق:',
  prePrayerTest: 'تجربة الإشعار الآن (5 د)',
  browserPermissionAllowed: '✓ إشعارات المتصفح مسموح بها',
  browserPermissionRequest: 'طلب إذن إشعارات المتصفح',
  dhikrReminder: 'تنبيه أذكار الصباح والمساء',
  dhikrReminderDesc: 'إرسال إشعار لطيف وهادئ في موعد الصباح والمساء لتذكيرك بالأذكار اليومية',
  dhikrMorning: 'أذكار الصباح',
  dhikrEvening: 'أذكار المساء',
  dhikrSound: 'نغمة رنين روحانية خفيفة مع التذكير',
  dhikrTestMorning: 'تجربة الصباح',
  dhikrTestEvening: 'تجربة المساء',
  timezoneSettings: 'نظام التوقيت بالمملكة المغربية',
  timezoneDesc: 'اعتماد التوقيت الرسمي المعمول به حالياً بالمملكة المغربية: التوقيت العالمي (غرينتش GMT+0)',
  themeTitle: 'المظهر والوضع الليلي / النهاري',
  themeDesc: 'التبديل التلقائي يضبط الوضع النهاري المريح للعين عند الشروق والوضع الليلي عند الغروب حسب مدينتك.',
  themeAuto: 'تلقائي ★',
  themeDark: 'ليلي داكن',
  themeLight: 'نهاري مريح',
  themeAutoDesc: 'شروق / غروب',
  themeLightDesc: 'راحة للعين',
  themeDarkDesc: 'إضاءة خافتة',
  animatedBgTitle: 'خلفيات إسلامية متحركة هادئة',
  animatedBgDesc: 'حركة سحاب هادئة وإضاءة سماوية خفيفة في الخلفية',
  animatedBgActive: 'مفعلة ✨',
  animatedBgBattery: 'توفير البطارية 🔋',
  animatedBgToggle: 'تفعيل حركة السحاب والإضاءة الخافتة',
  animatedBgToggleDesc: 'يمكنك إيقافها في أي وقت لتوفير شحن بطارية هاتفك',
  shakeTitle: 'إيقاف الأذان بهز الهاتف',
  shakeDesc: 'إسكات وإيقاف صوت الأذان فوراً عند هز أو تحريك الهاتف',
  shakeActive: 'مفعل 📳',
  shakeDisabled: 'معطل',
  shakeToggle: 'تفعيل مستشعر الحركة لإيقاف الأذان',
  shakeToggleDesc: 'عند تشغيل الأذان، يكفي هز هاتفك حركة خفيفة ليتوقف الصوت فوراً مع اهتزاز تأكيدي',
  shakeSensitivity: 'مستوى حساسية قوة الهز:',
  shakeTestBtn: 'تجربة مستشعر هز الهاتف الآن 📳',
  shakeTestingActive: 'جاري تشغيل الصوت... هز هاتفك الآن لإيقافه!',
  wakeLockTitle: 'إبقاء الجهاز نشطاً لمنع السكون (Keep Device Awake)',
  wakeLockDesc: 'يمنع المتصفح من إدخال التطبيق في وضع السكون العميق لضمان رفع الأذان والتنبيهات في موعدها',
  wakeLockActive: 'مفعل لمنع السكون ⚡',
  wakeLockDisabled: 'معطل',
  wakeLockToggle: 'تفعيل ميزة إبقاء الشاشة والمعالج نشطين (Wake Lock API)',
  wakeLockToggleDesc: 'يستخدم واجهة Screen Wake Lock API الرسمية لمنع النظام من تعليق التطبيق أو كتم مؤقتات الصلاة عند ترك الهاتف',
  wakeLockNotSupported: 'هذا المتصفح لا يدعم Screen Wake Lock API، يُفضل استخدام Google Chrome لتشغيل حارس الصوت في الخلفية',
  bgAlarmTestTitle: 'اختبار الأذان في الخلفية والوضع الصامت (15 ثانية)',
  bgAlarmTestDesc: 'يستخدم منبه العتاد الرسمي AlarmManager.setAlarmClock() لإيقاظ الهاتف من النوم العميق وتشغيل الأذان بصوت المنبه حتى لو كان الهاتف صامتاً.',
  bgAlarmTestBtn: 'بدء اختبار الأذان بعد 15 ثانية (جرّب والشاشة مطفأة)',
  bgAlarmTestCounting: 'جارِ العد التنازلي... اخرج من التطبيق واقفل شاشة الهاتف الآن!',
  pwaInstallTitle: 'تثبيت التطبيق على هاتفك',
  pwaInstallDesc: 'تثبيت كأيقونة مستقلة سريعة بدون متجر',
  pwaBadge: 'PWA',
  appLanguage: 'لغة التطبيق (App Language)',
  chooseAppLang: 'اختر لغة واجهة التطبيق والإعدادات',
  arabicLang: 'العربية',
  englishLang: 'English',

  tasbeeh: 'عداد التسبيح',
  tasbeehDesc: 'سبحة إلكترونية بلمسة واحدة مع حفظ تلقائي وإعادة تعيين',
  tasbeehBadge: 'مميز',
  virtuesTitle: 'فضل الصلاة والجماعة',
  virtuesDesc: 'أحاديث فضل الصلوات الخمس وصلاة المسجد',
  adhkarMenuTitle: 'أذكار الصباح والمساء',
  adhkarMenuDesc: 'أذكار الصباح والمساء والسبحة الإلكترونية',
  hadithsMenuTitle: 'أحاديث نبوية',
  hadithsMenuDesc: 'أحاديث نبوية شريفة وصحيحة يومية',
  monthlyMenuTitle: 'الحصة الشهرية',
  monthlyMenuDesc: 'جدول مواقيت الصلاة لكامل الشهر للمملكة',
  settingsMenuTitle: 'الإعدادات وتحديد الموقع',
  settingsMenuDesc: 'تغيير المدينة، صوت الأذان، التنبيهات وتعديل التقويم',
  downloadZipTitle: 'تحميل التطبيق كملف ZIP',
  downloadZipDesc: 'تنزيل كود المشروع كاملاً (محمي بكلمة مرور المشرف)',
  supervisorBadge: 'خاص بالمشرف 🔒',

  chooseAdhanSound: 'اختيار صوت الأذان عند دخول الوقت',
  chooseAdhanSoundDesc: 'انقر على أيقونة الاستماع لتجربة الأذان، أو انقر على الخانة لاعتماده كأذان رسمي عند حلول الوقت',
  customSelection: 'حرية الاختيار للمستخدم',
  currentAdhanSelected: 'الأذان المعتمد حالياً:',
  stopPreview: 'إيقاف الاستماع',
  playPreview: 'استماع لصوت الأذان',
  prayerNotifications: 'تنبيهات دخول وقت الصلاة',
  prayerNotificationsDesc: 'إشعار صوتي عند حلول وقت الصلاة',
  hijriAdjustment: 'تعديل التقويم الهجري',
  hijriAdjustmentDesc: 'تقديم أو تأخير التاريخ الهجري بيوم حسب الرؤية الشرعية بالمملكة',
  hijriOfficial: 'مطابق للرؤية الرسمية (0)',
  day: 'يوم',
  days: 'أيام',
  moroccoCalcInfo: 'معلومات الحساب والتوقيت',
  moroccoCalcDesc: 'المواقيت مستخرجة ومعتمدة وفق معايير وزارة الأوقاف والشؤون الإسلامية بالمملكة المغربية، مع مراعاة فارق الدقائق بين المدن المغربية وزاوية الفجر (19°).',
  supervisorLogin: 'دخول المشرف 🔐',
  saved: 'تم الحفظ',
  saveDone: 'تم الحفظ',
  presets: 'اقتراحات:',
  errorsRecorded: 'أخطاء مسجلة',
  healthyAndActive: 'سليم ويعمل 🟢',
  themeCurrentAuto: 'تلقائي (شروق وغروب)',
  themeCurrentLight: 'نهاري دائم',
  themeCurrentDark: 'ليلي دائم',
  shakeLight: 'خفيف (سريع الاستجابة)',
  shakeBalanced: 'متوازن ★',
  shakeFirm: 'قوي (حماية)',
  shakeTestSuccess: '✓ تم استشعار اهتزاز هاتفك بنجاح وتم إيقاف الأذان! 📳',

  adhanSettingsTitle: 'إعدادات الأذان',
  back: 'رجوع',
  audioTest: 'تجربة الصوت 🔊',
  stopAdhanBtn: 'إيقاف الأذان',
  silentModeAlert: 'التنبيه في الوضع الصامت',
  silentModeAlertDesc: 'تشغيل الأذان حتى وإن كان الجهاز في الوضع الصامت',
  stopShortcuts: 'اختصارات إيقاف الأذان',
  stopShortcutsDesc: 'طرق سريعة لإسكات الأذان فوراً عند بدء تشغيله',
  stopByVolume: 'أزرار الصوت',
  stopByVolumeDesc: 'الضغط على زر خفض أو رفع الصوت لإسكات الأذان',
  stopByShake: 'هز الهاتف',
  stopByShakeDesc: 'هز الهاتف حركة خفيفة لإيقاف الأذان',
  stopByFlip: 'قلب الهاتف',
  stopByFlipDesc: 'وضع شاشة الهاتف للأسفل على الطاولة لإسكات الصوت',
  fridayAdhan: 'أذان صلاة الجمعة',
  fridayAdhanDesc: 'تخصيص أذان وتنبيه خاص بيوم الجمعة المبارك',
  silentNotification: 'إشعار صامت بدون صوت',
  silentNotificationDesc: 'عرض الإشعار على الشاشة فقط دون تشغيل أي صوت',
  assignedMuezzinsTitle: 'تخصيص مؤذن لكل صلاة',
  assignedMuezzinsDesc: 'اختر المؤذن المفضل لكل صلاة من الصلوات الخمس بشكل مستقل',
  changeMuezzin: 'تغيير',
  allPrayers: 'جميع الصلوات',

  prayerTimesAdjustTitle: 'أوقات الصلوات',
  autoSettings: 'الإعدادات التلقائية',
  autoSettingsDesc: 'اعتماد الحساب الفلكي الرسمي لوزارة الأوقاف والشؤون الإسلامية بالمملكة المغربية',
  fineTuneMinutes: 'تعديل الدقائق (+ / -)',
  fineTuneMinutesDesc: 'تعديل يدوي بالدقائق ليتطابق مع أذان مسجد حيك',
  resetAll: 'إعادة ضبط الكل (0)',
  minute: 'دقيقة',
  minutesPlural: 'دقائق',

  selectCityTitle: 'اختيار المدينة (المغرب)',
  searchCityPlaceholder: 'ابحث عن اسم المدينة...',
  noCitiesFound: 'لم يتم العثور على مدن مطابقة',
  currentLocationGps: 'تحديد موقعي تلقائياً عبر GPS',

  adhanLogTitle: 'سجل نشاط الأذان (Adhan Log)',
  adhanLogSubtitle: 'مراقبة تشغيل الأذان ودقة المواعيد',
  totalAdhansPlayed: 'إجمالي الأذان',
  successfulPlays: 'ناجح',
  failedPlays: 'تعذر',
  lastAdhanTime: 'آخر أذان',
  clearLog: 'مسح السجل',
  emptyLog: 'لا توجد تسجيلات بعد',

  // Share
  share: 'مشاركة',
  shareTitle: 'مشاركة التطبيق ومواقيت الصلاة',
  shareDesc: 'شارك جدول مواقيت الصلاة لمدينتك أو انسخ رابط التطبيق المباشر',
  shareViaApps: 'مشاركة عبر التطبيقات 📲',
  copySchedule: 'نسخ جدول مواقيت الصلاة 📋',
  copyAppLink: 'نسخ رابط التطبيق 🔗',
  shareWhatsApp: 'إرسال عبر واتساب 💬',
  scheduleCopied: '✓ تم نسخ جدول مواقيت الصلاة بنجاح',
  linkCopied: '✓ تم نسخ رابط التطبيق بنجاح',
};

const translationsEn: Translations = {
  today: 'Today',
  virtues: 'Virtues',
  qibla: 'Qibla',
  more: 'More',
  moreOptions: 'More Options',
  settings: 'Settings',
  backToToday: 'Back to Today',
  previousDay: 'Previous Day',
  nextDay: 'Next Day',
  stopAdhan: 'Stop Adhan ⏹',
  listenAdhan: 'Adhan',
  adhanPreview: 'Listen to Adhan',
  loading: 'Loading...',
  close: 'Close',
  save: 'Save',
  cancel: 'Cancel',
  success: 'Success',
  copied: 'Copied',

  fajr: 'Fajr',
  sunrise: 'Sunrise',
  dhuhr: 'Dhuhr',
  asr: 'Asr',
  maghrib: 'Maghrib',
  isha: 'Isha',

  nextPrayerLabel: 'Next Prayer',
  nextBadge: 'Next',
  remaining: 'Remaining:',
  hoursShort: 'h',
  minutesShort: 'm',
  secondsShort: 's',
  adhanMaghribIftar: 'Maghrib (Iftar)',
  adhanFajrImsak: 'Fajr (Imsak)',
  prayerOf: 'Prayer',

  gmt: 'GMT Standard (GMT+0) ★',
  gmtSummer: 'Summer Time (GMT+1)',
  locateCity: 'Locate City',
  citySettings: 'Location & City Settings',
  autoGpsTravel: 'Automatic GPS Updates while Traveling (GPS Live)',
  autoGpsTravelDesc: 'Prayer times automatically update when traveling between Moroccan regions',
  gpsActive: 'GPS Live Active',
  gpsManual: 'Manual City',
  locatingGps: 'Connecting to GPS...',
  locateGpsNow: 'Locate via GPS Now',
  changeCityManual: 'Change City Manually',

  adjustPrayerTimes: 'Adjust Prayer Times',
  adjustPrayerTimesDesc: 'Fine-tune minutes for Fajr, Dhuhr, Asr, Maghrib, Isha (+ / -)',
  adjustNewBadge: 'New',
  adhanSettings: 'Adhan & Muezzin Selection',
  adhanSettingsDesc: 'Assign a dedicated muezzin for each prayer (Fajr, Dhuhr, Asr, Maghrib, Isha)',
  adhanCustomBadge: 'Custom',
  adhanLog: 'Adhan Activity Log',
  adhanLogDesc: 'Monitor on-time Adhan playback precision and audio file status',
  dailyTracker: 'Daily Prayer Tracker',
  dailyTrackerDesc: 'Track your 5 prayers daily (on time, in congregation, or made up)',
  dailyTrackerBadge: 'Prayer Tracker',
  prePrayerAlert: 'Pre-Prayer Browser Notifications',
  prePrayerAlertDesc: 'Notification and chime several minutes before every prayer',
  prePrayerMinutes: 'Alert minutes in advance:',
  prePrayerTest: 'Test Alert Now (5m)',
  browserPermissionAllowed: '✓ Browser notifications allowed',
  browserPermissionRequest: 'Enable browser notifications',
  dhikrReminder: 'Morning & Evening Dhikr Reminder',
  dhikrReminderDesc: 'Gentle notification in morning and evening to remind of daily remembrance',
  dhikrMorning: 'Morning Dhikr',
  dhikrEvening: 'Evening Dhikr',
  dhikrSound: 'Gentle spiritual chime with reminder',
  dhikrTestMorning: 'Test Morning',
  dhikrTestEvening: 'Test Evening',
  timezoneSettings: 'Morocco Timezone Standard',
  timezoneDesc: 'Current official time standard in Morocco: Universal Coordinated Time (GMT+0)',
  themeTitle: 'Appearance & Day/Night Mode',
  themeDesc: 'Automatic mode activates eye-comfort light theme at sunrise and dark theme at sunset.',
  themeAuto: 'Auto ★',
  themeDark: 'Dark Theme',
  themeLight: 'Light Theme',
  themeAutoDesc: 'Sunrise / Sunset',
  themeLightDesc: 'Eye Comfort',
  themeDarkDesc: 'Soft Lighting',
  animatedBgTitle: 'Peaceful Animated Islamic Background',
  animatedBgDesc: 'Calm moving clouds and subtle ambient lighting in background',
  animatedBgActive: 'Active ✨',
  animatedBgBattery: 'Battery Saver 🔋',
  animatedBgToggle: 'Enable calm clouds and subtle lighting',
  animatedBgToggleDesc: 'Turn off anytime to conserve device battery power',
  shakeTitle: 'Shake Phone to Stop Adhan',
  shakeDesc: 'Instantly silence Adhan by shaking or moving your phone',
  shakeActive: 'Enabled 📳',
  shakeDisabled: 'Disabled',
  shakeToggle: 'Enable motion sensor to silence Adhan',
  shakeToggleDesc: 'During Adhan, a gentle shake immediately silences the sound with haptic feedback',
  shakeSensitivity: 'Shake sensitivity threshold:',
  shakeTestBtn: 'Test Shake Detector Now 📳',
  shakeTestingActive: 'Playing test audio... Shake your phone now to stop!',
  wakeLockTitle: 'Keep Device Awake (Wake Lock)',
  wakeLockDesc: 'Prevents the browser from putting the tab into deep sleep, avoiding missed silent alarms',
  wakeLockActive: 'Active & Awake ⚡',
  wakeLockDisabled: 'Disabled',
  wakeLockToggle: 'Enable Screen Wake Lock API',
  wakeLockToggleDesc: 'Keeps CPU & display awake to prevent the browser from throttling timers or silencing background prayer alarms',
  wakeLockNotSupported: 'Wake Lock API is not supported on this browser. Google Chrome recommended for background audio guard.',
  bgAlarmTestTitle: 'Background & Silent Mode Adhan Test (15s)',
  bgAlarmTestDesc: 'Uses official AlarmManager.setAlarmClock() to wake device from deep sleep and ring aloud over lock screen in silent mode.',
  bgAlarmTestBtn: 'Start Background Adhan Test (15s)',
  bgAlarmTestCounting: 'Countdown active... Exit app and lock your screen now!',
  pwaInstallTitle: 'Install App on Your Phone',
  pwaInstallDesc: 'Install standalone icon directly without an app store',
  pwaBadge: 'PWA',
  appLanguage: 'App Language (لغة التطبيق)',
  chooseAppLang: 'Choose application interface and settings language',
  arabicLang: 'العربية',
  englishLang: 'English',

  tasbeeh: 'Tasbeeh Counter',
  tasbeehDesc: 'Digital prayer beads with auto-save and reset',
  tasbeehBadge: 'Featured',
  virtuesTitle: 'Prayer Virtues & Congregation',
  virtuesDesc: 'Prophetic traditions on the five daily prayers',
  adhkarMenuTitle: 'Morning & Evening Adhkar',
  adhkarMenuDesc: 'Daily remembrances and electronic tasbeeh',
  hadithsMenuTitle: 'Prophetic Hadiths',
  hadithsMenuDesc: 'Authentic daily prophetic traditions',
  monthlyMenuTitle: 'Monthly Timetable',
  monthlyMenuDesc: 'Full month prayer timetable for Morocco',
  settingsMenuTitle: 'Settings & Location',
  settingsMenuDesc: 'Change city, adhan sounds, alerts and calendar',
  downloadZipTitle: 'Download App as ZIP',
  downloadZipDesc: 'Download complete project source code (supervisor protected)',
  supervisorBadge: 'Supervisor 🔒',

  chooseAdhanSound: 'Select Adhan Sound for Prayer Time',
  chooseAdhanSoundDesc: 'Tap the listen icon to preview, or tap the card to set as your official Adhan sound',
  customSelection: 'User custom choice',
  currentAdhanSelected: 'Currently active Adhan:',
  stopPreview: 'Stop preview',
  playPreview: 'Listen to Adhan',
  prayerNotifications: 'Prayer Time Alerts',
  prayerNotificationsDesc: 'Audio notification when prayer time arrives',
  hijriAdjustment: 'Adjust Hijri Calendar',
  hijriAdjustmentDesc: 'Shift Hijri date by a day according to official moon sighting in Morocco',
  hijriOfficial: 'Official Sighting (0)',
  day: 'day',
  days: 'days',
  moroccoCalcInfo: 'Calculation & Time Standard Information',
  moroccoCalcDesc: 'Prayer times are calculated and verified in accordance with the standards of the Ministry of Endowments and Islamic Affairs in the Kingdom of Morocco, taking into account local city coordinates and 19° Fajr angle.',
  supervisorLogin: 'Supervisor Login 🔐',
  saved: 'Saved successfully',
  saveDone: 'Done',
  presets: 'Presets:',
  errorsRecorded: 'errors recorded',
  healthyAndActive: 'Active & verified 🟢',
  themeCurrentAuto: 'Auto (Sunrise / Sunset)',
  themeCurrentLight: 'Always Light',
  themeCurrentDark: 'Always Dark',
  shakeLight: 'Light (Responsive)',
  shakeBalanced: 'Balanced ★',
  shakeFirm: 'Firm (Safe)',
  shakeTestSuccess: '✓ Shake detected successfully, Adhan silenced! 📳',

  adhanSettingsTitle: 'Adhan Settings',
  back: 'Back',
  audioTest: 'Audio Test 🔊',
  stopAdhanBtn: 'Stop Adhan',
  silentModeAlert: 'Alert in Silent Mode',
  silentModeAlertDesc: 'Play Adhan audio even when the device is set to silent mode',
  stopShortcuts: 'Shortcuts to Silence Adhan',
  stopShortcutsDesc: 'Quick ways to immediately silence the Adhan upon playback',
  stopByVolume: 'Volume Buttons',
  stopByVolumeDesc: 'Press volume up/down to silence the Adhan',
  stopByShake: 'Shake Phone',
  stopByShakeDesc: 'Gently shake the phone to stop the Adhan',
  stopByFlip: 'Flip Phone',
  stopByFlipDesc: 'Place screen face-down on the table to silence audio',
  fridayAdhan: 'Friday (Jumuah) Adhan',
  fridayAdhanDesc: 'Special dedicated reminder and Adhan for Friday',
  silentNotification: 'Silent Banner Notification',
  silentNotificationDesc: 'Display banner on screen only without audio playback',
  assignedMuezzinsTitle: 'Assign Muezzin for Each Prayer',
  assignedMuezzinsDesc: 'Choose a distinct muezzin for each of the five daily prayers',
  changeMuezzin: 'Change',
  allPrayers: 'All Prayers',

  prayerTimesAdjustTitle: 'Prayer Times Adjustment',
  autoSettings: 'Automatic Settings',
  autoSettingsDesc: 'Adopt official calculation of Morocco Ministry of Islamic Affairs',
  fineTuneMinutes: 'Fine-Tune Minutes (+ / -)',
  fineTuneMinutesDesc: 'Manual minute offset to match your local neighborhood mosque',
  resetAll: 'Reset All (0)',
  minute: 'min',
  minutesPlural: 'min',

  selectCityTitle: 'Select City (Morocco)',
  searchCityPlaceholder: 'Search city name...',
  noCitiesFound: 'No matching cities found',
  currentLocationGps: 'Detect My Location via GPS',

  adhanLogTitle: 'Adhan Activity Log',
  adhanLogSubtitle: 'Adhan playback monitor and timing precision',
  totalAdhansPlayed: 'Total Played',
  successfulPlays: 'Successful',
  failedPlays: 'Failed',
  lastAdhanTime: 'Last Adhan',
  clearLog: 'Clear Log',
  emptyLog: 'No log entries yet',

  // Share
  share: 'Share',
  shareTitle: 'Share App & Prayer Schedule',
  shareDesc: 'Share prayer times for your city or copy direct app link',
  shareViaApps: 'Share via Apps 📲',
  copySchedule: 'Copy Prayer Schedule 📋',
  copyAppLink: 'Copy App Link 🔗',
  shareWhatsApp: 'Send via WhatsApp 💬',
  scheduleCopied: '✓ Prayer schedule copied successfully',
  linkCopied: '✓ App link copied successfully',
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: Translations;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType>({
  language: 'ar',
  setLanguage: () => {},
  toggleLanguage: () => {},
  t: translationsAr,
  isRTL: true,
});

export const useLanguage = () => useContext(LanguageContext);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('salat_app_language');
      if (saved === 'en' || saved === 'ar') return saved;
    } catch {}
    return 'ar';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('salat_app_language', lang);
    } catch {}
  };

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  useEffect(() => {
    // Keep html lang attribute in sync
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const value = {
    language,
    setLanguage,
    toggleLanguage,
    t: language === 'en' ? translationsEn : translationsAr,
    isRTL: language === 'ar',
  };

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
};
