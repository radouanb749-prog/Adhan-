import React, { createContext, useContext, useMemo, useEffect } from 'react';
import { PrayerTimeItem } from '../types/prayer';

export type ThemeMode = 'auto' | 'dark' | 'light';

interface ThemeContextType {
  themeMode: ThemeMode;
  isDark: boolean;
  isAuto: boolean;
  sunriseTime?: string;
  sunsetTime?: string;
  setThemeMode: (mode: ThemeMode) => void;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType>({
  themeMode: 'auto',
  isDark: true,
  isAuto: true,
  setThemeMode: () => {},
  toggleTheme: () => {},
});

export const useTheme = () => useContext(ThemeContext);

interface ThemeProviderProps {
  children: React.ReactNode;
  themeMode: ThemeMode;
  onThemeModeChange: (mode: ThemeMode) => void;
  prayers: PrayerTimeItem[];
  currentTimeMs: number;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({
  children,
  themeMode,
  onThemeModeChange,
  prayers,
  currentTimeMs,
}) => {
  const sunrisePrayer = useMemo(() => prayers.find((p) => p.id === 'sunrise'), [prayers]);
  const maghribPrayer = useMemo(() => prayers.find((p) => p.id === 'maghrib'), [prayers]);

  // Determine if it is currently daytime between sunrise and sunset based on local time
  const isDaytime = useMemo(() => {
    if (!sunrisePrayer || !maghribPrayer) return false;
    const now = new Date(currentTimeMs);
    const currentSecToday =
      now.getUTCHours() * 3600 + now.getUTCMinutes() * 60 + now.getUTCSeconds();
    const [sH, sM] = sunrisePrayer.time.split(':').map(Number);
    const [mH, mM] = maghribPrayer.time.split(':').map(Number);
    const sunriseSec = sH * 3600 + sM * 60;
    const maghribSec = mH * 3600 + mM * 60;

    return currentSecToday >= sunriseSec && currentSecToday < maghribSec;
  }, [currentTimeMs, sunrisePrayer, maghribPrayer]);

  // Determine isDark based on themeMode
  const isDark = useMemo(() => {
    if (themeMode === 'dark') return true;
    if (themeMode === 'light') return false;
    // auto: daytime -> light, nighttime -> dark
    return !isDaytime;
  }, [themeMode, isDaytime]);

  // Sync document class and meta theme-color
  useEffect(() => {
    if (typeof document !== 'undefined') {
      const root = document.documentElement;
      if (isDark) {
        root.classList.add('dark');
        root.classList.remove('light');
        document.body.style.backgroundColor = '#121212';
        document.body.style.color = '#FFFFFF';
      } else {
        root.classList.add('light');
        root.classList.remove('dark');
        document.body.style.backgroundColor = '#F7F5F0'; // Soft warm eye-comfort daylight parchment
        document.body.style.color = '#1F2937';
      }
    }
  }, [isDark]);

  const toggleTheme = () => {
    if (themeMode === 'auto') {
      onThemeModeChange(isDark ? 'light' : 'dark');
    } else if (themeMode === 'dark') {
      onThemeModeChange('light');
    } else {
      onThemeModeChange('auto');
    }
  };

  const value = useMemo(
    () => ({
      themeMode,
      isDark,
      isAuto: themeMode === 'auto',
      sunriseTime: sunrisePrayer?.time,
      sunsetTime: maghribPrayer?.time,
      setThemeMode: onThemeModeChange,
      toggleTheme,
    }),
    [themeMode, isDark, sunrisePrayer?.time, maghribPrayer?.time, onThemeModeChange]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};
