import { Component, ErrorInfo, ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';



interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('App runtime error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#121212] text-white flex flex-col items-center justify-center p-6 text-center font-['Cairo',sans-serif]">
          <div className="w-16 h-16 rounded-full bg-[#C5A059]/20 border border-[#C5A059]/40 flex items-center justify-center mb-4 text-2xl text-[#C5A059]">
            🕌
          </div>
          <h2 className="text-xl font-bold mb-2">صلاتك - مواقيت الصلاة</h2>
          <p className="text-sm text-white/70 max-w-sm mb-6 leading-relaxed">
            حدث تحديث في التطبيق. يرجى الضغط على الزر أدناه لتحديث الصفحة وعرض المواقيت.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-2.5 rounded-full bg-[#C5A059] text-black font-bold text-sm shadow-lg hover:bg-[#d6b063] transition-all cursor-pointer active:scale-95"
          >
            تحديث الصفحة الآن
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
