import React, { useState, useEffect, useCallback } from 'react';
import { Clock, AlertTriangle, ChevronLeft, X, CheckCircle2 } from 'lucide-react';
import { nativeAlarmBridge } from '../services/nativeAlarmBridge';

export const ExactAlarmBanner: React.FC = () => {
  const [isExactAlarmAllowed, setIsExactAlarmAllowed] = useState(true);
  const [isFullScreenAllowed, setIsFullScreenAllowed] = useState(true);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isGrantedJustNow, setIsGrantedJustNow] = useState(false);

  const checkAlarmPermissions = useCallback(() => {
    if (!nativeAlarmBridge.isAvailable()) {
      setIsExactAlarmAllowed(true);
      setIsFullScreenAllowed(true);
      return;
    }

    const exactAllowed = nativeAlarmBridge.canScheduleExactAlarms();
    const fullScreenAllowed = nativeAlarmBridge.canUseFullScreenIntent();

    if (exactAllowed && fullScreenAllowed && (!isExactAlarmAllowed || !isFullScreenAllowed)) {
      setIsGrantedJustNow(true);
      setTimeout(() => {
        setIsExactAlarmAllowed(true);
        setIsFullScreenAllowed(true);
        setIsGrantedJustNow(false);
      }, 2500);
    } else {
      setIsExactAlarmAllowed(exactAllowed);
      setIsFullScreenAllowed(fullScreenAllowed);
    }
  }, [isExactAlarmAllowed, isFullScreenAllowed]);

  useEffect(() => {
    checkAlarmPermissions();

    // Automatically re-verify when the user returns to the app from the Android Settings screen
    const handleRecheck = () => {
      checkAlarmPermissions();
    };

    window.addEventListener('focus', handleRecheck);
    window.addEventListener('visibilitychange', handleRecheck);

    return () => {
      window.removeEventListener('focus', handleRecheck);
      window.removeEventListener('visibilitychange', handleRecheck);
    };
  }, [checkAlarmPermissions]);

  const allAllowed = isExactAlarmAllowed && isFullScreenAllowed;

  if (allAllowed && !isGrantedJustNow) {
    return null;
  }

  if (isDismissed && !isGrantedJustNow) {
    return null;
  }

  const missingExactAlarm = !isExactAlarmAllowed;

  const handleRequestPermission = () => {
    if (missingExactAlarm) {
      nativeAlarmBridge.requestExactAlarmPermission();
    } else {
      nativeAlarmBridge.requestFullScreenIntentPermission();
    }
  };

  return (
    <div
      role="alert"
      aria-live="assertive"
      className="fixed top-3 left-3 right-3 max-w-md mx-auto z-50 animate-in fade-in slide-in-from-top-3 duration-300 select-none font-['Cairo',sans-serif]"
    >
      <div className="relative rounded-2xl bg-gradient-to-r from-[#211B14] via-[#1A1612] to-[#211B14] border-2 border-[#C5A059] p-3.5 shadow-2xl backdrop-blur-md text-white overflow-hidden text-right">
        {/* Glow accent */}
        <div className="absolute -top-8 -right-8 w-28 h-28 bg-[#C5A059]/20 rounded-full blur-2xl pointer-events-none" />

        {isGrantedJustNow ? (
          <div className="flex items-center justify-between gap-3 text-emerald-400">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div className="flex-1 text-right">
              <h4 className="text-sm font-bold text-white">تم تفعيل صلاحيات الأذان بنجاح!</h4>
              <p className="text-xs text-emerald-300/90 mt-0.5">ستنطلق تنبيهات الأذان وتظهر فوق شاشة القفل في مواعيدها المحددة.</p>
            </div>
          </div>
        ) : (
          <div className="flex items-start justify-between gap-3">
            <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/50 shrink-0 mt-0.5 shadow-inner animate-pulse">
              <Clock className="w-5 h-5 text-[#C5A059]" />
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-1.5 justify-end mb-1">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>{missingExactAlarm ? 'تنبيه نظام أندرويد 12+' : 'تنبيه نظام أندرويد 14+'}</span>
                </span>
              </div>

              <h4 className="text-sm font-bold text-[#C5A059] leading-tight">
                {missingExactAlarm
                  ? 'تفعيل صلاحية المنبه الدقيق (SCHEDULE_EXACT_ALARM)'
                  : 'تفعيل إذن الظهور الفوري فوق شاشة القفل (USE_FULL_SCREEN_INTENT)'}
              </h4>

              <p className="text-xs text-white/80 mt-1 leading-relaxed">
                {missingExactAlarm
                  ? 'يتطلب أندرويد 12 فأحدث تفعيل إذن المنبه الدقيق لضمان انطلاق صوت الأذان في موعده بالثانية حتى عند إغلاق الشاشة أو في وضع السكون.'
                  : 'يتطلب أندرويد 14 فأحدث السماح بإشعارات ملء الشاشة لتظهر واجهة الأذان فوراً فوق شاشة القفل عند دخول وقت الصلاة.'}
              </p>

              <div className="mt-3 flex items-center gap-2 justify-end">
                <button
                  type="button"
                  onClick={handleRequestPermission}
                  className="flex items-center gap-1 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#C5A059] to-[#8C6D32] hover:brightness-110 text-black font-bold text-xs active:scale-95 transition-all shadow-md cursor-pointer"
                >
                  <span>تفعيل الصلاحية الآن</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => setIsDismissed(true)}
                  className="px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/60 hover:text-white text-xs transition-colors cursor-pointer"
                >
                  تخطي مؤقتاً
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsDismissed(true)}
              aria-label="إغلاق التنبيه"
              className="p-1 rounded-full text-white/40 hover:text-white hover:bg-white/10 transition-colors shrink-0 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
