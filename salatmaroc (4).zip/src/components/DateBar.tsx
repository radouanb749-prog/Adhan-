import React from 'react';
import { ChevronRight, ChevronLeft, RotateCcw } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';

interface DateBarProps {
  dateString: string;
  dayOffset: number;
  onPrevDay: () => void;
  onNextDay: () => void;
  onResetToday: () => void;
}

export const DateBar: React.FC<DateBarProps> = ({
  dateString,
  dayOffset,
  onPrevDay,
  onNextDay,
  onResetToday,
}) => {
  const { isDark } = useTheme();
  const { t } = useLanguage();

  return (
    <div
      className={`w-full border-y py-3 px-4 flex items-center justify-between select-none transition-colors duration-300 ${
        isDark
          ? 'bg-[#181818] border-white/5 text-white'
          : 'bg-[#F2EFE9] border-[#C5A059]/20 text-gray-800'
      }`}
    >
      {/* Previous day arrow (Golden) */}
      <button
        onClick={onPrevDay}
        className="p-1.5 rounded-full hover:bg-[#C5A059]/10 text-[#C5A059] hover:text-[#d8b56f] transition-all active:scale-90 cursor-pointer"
        title={t.previousDay}
        aria-label={t.previousDay}
      >
        <ChevronRight className="w-6 h-6 stroke-[2.5]" />
      </button>

      {/* Center Hijri & Gregorian date */}
      <div className="flex flex-col items-center justify-center text-center px-2">
        <span
          className={`text-sm sm:text-base font-semibold tracking-wide font-['Cairo',sans-serif] ${
            isDark ? 'text-white/95' : 'text-gray-900'
          }`}
        >
          {dateString}
        </span>
        {dayOffset !== 0 && (
          <button
            onClick={onResetToday}
            className="mt-1 flex items-center gap-1 text-[11px] text-[#C5A059] bg-[#C5A059]/10 px-2 py-0.5 rounded-full hover:bg-[#C5A059]/20 transition-all cursor-pointer font-bold"
          >
            <RotateCcw className="w-3 h-3" />
            <span>{t.backToToday}</span>
          </button>
        )}
      </div>

      {/* Next day arrow (Golden) */}
      <button
        onClick={onNextDay}
        className="p-1.5 rounded-full hover:bg-[#C5A059]/10 text-[#C5A059] hover:text-[#d8b56f] transition-all active:scale-90 cursor-pointer"
        title={t.nextDay}
        aria-label={t.nextDay}
      >
        <ChevronLeft className="w-6 h-6 stroke-[2.5]" />
      </button>
    </div>
  );
};
