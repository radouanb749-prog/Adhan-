import React from 'react';
import { Sun, Moon, ChevronLeft } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface AdhkarQuickWidgetProps {
  onOpenMorning: () => void;
  onOpenEvening: () => void;
}

export const AdhkarQuickWidget: React.FC<AdhkarQuickWidgetProps> = ({
  onOpenMorning,
  onOpenEvening,
}) => {
  const { isDark } = useTheme();

  return (
    <div className="w-full px-4 pb-4 select-none">
      <div className="grid grid-cols-2 gap-3">
        {/* Morning Adhkar Card */}
        <button
          onClick={onOpenMorning}
          className={`relative flex items-center justify-between p-3.5 rounded-2xl border transition-all text-right group active:scale-[0.98] shadow-md cursor-pointer ${
            isDark
              ? 'bg-gradient-to-br from-[#222222] to-[#1A1A1A] border-amber-500/20 hover:border-amber-500/50'
              : 'bg-white border-amber-400/30 hover:border-amber-500 shadow-[0_4px_16px_rgba(0,0,0,0.05)]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-500 group-hover:scale-110 transition-transform">
              <Sun className="w-4 h-4" />
            </div>
            <div>
              <h4
                className={`text-xs sm:text-sm font-bold font-['Cairo',sans-serif] ${
                  isDark
                    ? 'text-white group-hover:text-amber-300'
                    : 'text-gray-900 group-hover:text-amber-600'
                }`}
              >
                أذكار الصباح
              </h4>
              <span className={`text-[10px] ${isDark ? 'text-white/50' : 'text-gray-500'}`}>
                تمرير + عداد
              </span>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-amber-500/60 group-hover:text-amber-500 group-hover:-translate-x-0.5 transition-all" />
        </button>

        {/* Evening Adhkar Card */}
        <button
          onClick={onOpenEvening}
          className={`relative flex items-center justify-between p-3.5 rounded-2xl border transition-all text-right group active:scale-[0.98] shadow-md cursor-pointer ${
            isDark
              ? 'bg-gradient-to-br from-[#222222] to-[#1A1A1A] border-indigo-500/20 hover:border-indigo-500/50'
              : 'bg-white border-indigo-400/30 hover:border-indigo-500 shadow-[0_4px_16px_rgba(0,0,0,0.05)]'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/15 text-indigo-500 group-hover:scale-110 transition-transform">
              <Moon className="w-4 h-4" />
            </div>
            <div>
              <h4
                className={`text-xs sm:text-sm font-bold font-['Cairo',sans-serif] ${
                  isDark
                    ? 'text-white group-hover:text-indigo-300'
                    : 'text-gray-900 group-hover:text-indigo-600'
                }`}
              >
                أذكار المساء
              </h4>
              <span className={`text-[10px] ${isDark ? 'text-white/50' : 'text-gray-500'}`}>
                تمرير + عداد
              </span>
            </div>
          </div>
          <ChevronLeft className="w-4 h-4 text-indigo-500/60 group-hover:text-indigo-500 group-hover:-translate-x-0.5 transition-all" />
        </button>
      </div>
    </div>
  );
};
