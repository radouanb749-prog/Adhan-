import React, { useState, useEffect } from 'react';
import { VolumeX, Volume2, X, AlertTriangle, Smartphone, Sparkles, CheckCircle2 } from 'lucide-react';
import { audioAdhanService, AudioSystemAlert } from '../services/audioAdhan';

export const AudioIssueBanner: React.FC = () => {
  const [activeIssue, setActiveIssue] = useState<AudioSystemAlert | null>(null);
  const [hasManuallyStarted, setHasManuallyStarted] = useState(false);

  useEffect(() => {
    const unsubscribe = audioAdhanService.onAudioIssue((issue) => {
      setActiveIssue(issue);
      setHasManuallyStarted(false);
    });
    return unsubscribe;
  }, []);

  // Auto-dismiss after 25 seconds if not interacted with
  useEffect(() => {
    if (!activeIssue) return;
    const timer = setTimeout(() => {
      audioAdhanService.dismissAudioIssue();
    }, 25000);
    return () => clearTimeout(timer);
  }, [activeIssue]);

  if (!activeIssue) return null;

  const handleEnableSoundNow = () => {
    // 1. Proactively unlock Web Audio Context & HTML5 Audio
    audioAdhanService.unlockAudio();

    // 2. Play Adhan audio or fallback
    if (activeIssue.audioUrl) {
      audioAdhanService.playRealAdhan(
        activeIssue.audioUrl,
        `manual_retry_${activeIssue.id}`,
        activeIssue.title || 'أذان الصلاة',
        activeIssue.muezzinName || 'المؤذن الشرعي',
        {
          prayerNameAr: activeIssue.prayerNameAr,
          triggerType: 'manual_test',
        }
      );
    } else {
      audioAdhanService.playRepeatingAlertTone(
        activeIssue.title || 'تنبيه موعد الصلاة',
        'نغمة تنبيه مكررة',
        activeIssue.prayerNameAr
      );
    }

    setHasManuallyStarted(true);

    // Auto dismiss banner after short delay so user sees confirmation
    setTimeout(() => {
      audioAdhanService.dismissAudioIssue();
    }, 2200);
  };

  const handleDismiss = () => {
    audioAdhanService.dismissAudioIssue();
  };

  const isPhoneSettings = activeIssue.type === 'phone_settings';

  return (
    <div
      role="alert"
      aria-live="assertive"
      className="fixed top-3 left-3 right-3 z-50 max-w-md mx-auto animate-in slide-in-from-top duration-300 select-none"
    >
      <div className="relative rounded-2xl bg-gradient-to-br from-[#211B14] via-[#1A1612] to-[#14110E] border-2 border-amber-500/80 p-4 shadow-[0_16px_45px_rgba(0,0,0,0.88)] overflow-hidden text-right">
        {/* Amber radial glow */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start justify-between gap-3">
          {/* Animated icon indicator */}
          <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/50 shrink-0 shadow-inner flex items-center justify-center animate-pulse">
            {isPhoneSettings ? (
              <Smartphone className="w-5 h-5 text-amber-400" />
            ) : (
              <VolumeX className="w-5 h-5 text-amber-400" />
            )}
          </div>

          <div className="flex-1">
            {/* Header badge */}
            <div className="flex items-center gap-2 mb-1 justify-end flex-wrap">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                <span>{isPhoneSettings ? 'إعدادات نظام الهاتف' : 'تنبيه الصوت'}</span>
              </span>
              {activeIssue.prayerNameAr && (
                <span className="text-[11px] font-semibold text-white/60">
                  صلاة {activeIssue.prayerNameAr}
                </span>
              )}
            </div>

            <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] leading-tight">
              {activeIssue.title}
            </h4>

            <p className="text-xs text-amber-100/80 mt-1 leading-relaxed">
              {activeIssue.message}
            </p>

            {/* Practical tip on phone hardware / system audio settings */}
            <div className="mt-2 p-2 rounded-xl bg-black/40 border border-white/10 text-[11px] text-white/70 leading-normal flex items-start gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
              <span>
                <strong>تذكير مهم:</strong> يرجى التأكد من إلغاء وضع الصامت (Silent Mode) ورفع مستوى صوت الوسائط في الهاتف لسماع الأذان دائماً في وقته.
              </span>
            </div>

            {/* Action buttons */}
            <div className="mt-3 flex items-center gap-2 justify-end">
              {hasManuallyStarted ? (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تم تفعيل الصوت بنجاح!</span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleEnableSoundNow}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-[#C5A059] text-black font-bold text-xs hover:brightness-110 active:scale-95 transition-all shadow-md cursor-pointer"
                >
                  <Volume2 className="w-4 h-4 fill-black/70" />
                  <span>تشغيل الأذان وتفعيل الصوت الآن</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleDismiss}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white text-xs font-medium transition-colors cursor-pointer"
              >
                حسناً، فهمت
              </button>
            </div>
          </div>

          {/* Close button */}
          <button
            type="button"
            onClick={handleDismiss}
            aria-label="إغلاق التنبيه"
            className="p-1.5 rounded-full text-white/40 hover:text-white hover:bg-white/10 transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
