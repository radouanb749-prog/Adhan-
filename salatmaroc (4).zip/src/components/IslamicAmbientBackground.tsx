import React from 'react';
import { useTheme } from '../context/ThemeContext';

interface IslamicAmbientBackgroundProps {
  enabled?: boolean;
}

export const IslamicAmbientBackground: React.FC<IslamicAmbientBackgroundProps> = ({
  enabled = true,
}) => {
  const { isDark } = useTheme();

  if (!enabled) {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none overflow-hidden z-0 select-none transition-opacity duration-1000"
    >
      {/* 1. Gentle Ambient Breathing Glow */}
      <div
        className={`absolute -top-32 left-1/2 -translate-x-1/2 w-[600px] h-[500px] rounded-full blur-[100px] opacity-25 animate-ambient-pulse ${
          isDark
            ? 'bg-gradient-to-b from-[#C5A059]/20 via-emerald-600/15 to-transparent'
            : 'bg-gradient-to-b from-amber-300/30 via-[#C5A059]/20 to-transparent'
        }`}
      />

      {/* 2. Soft Drifting Clouds (Layer 1 - Slower, larger) */}
      <div className="absolute top-0 left-0 w-[200%] h-64 opacity-25 animate-cloud-drift-slow">
        <svg
          className="w-full h-full"
          viewBox="0 0 1440 320"
          preserveAspectRatio="none"
          fill="none"
        >
          <path
            fill={isDark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(255, 255, 255, 0.35)'}
            d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,128C672,128,768,160,864,165.3C960,171,1056,149,1152,133.3C1248,117,1344,107,1392,101.3L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"
          />
        </svg>
      </div>

      {/* 3. Soft Drifting Clouds (Layer 2 - Subtle, higher up) */}
      <div className="absolute -top-10 left-0 w-[200%] h-52 opacity-20 animate-cloud-drift-fast">
        <svg
          className="w-full h-full"
          viewBox="0 0 1440 320"
          preserveAspectRatio="none"
          fill="none"
        >
          <path
            fill={isDark ? 'rgba(197, 160, 89, 0.05)' : 'rgba(255, 248, 220, 0.3)'}
            d="M0,160L48,144C96,128,192,96,288,106.7C384,117,480,171,576,176C672,181,768,139,864,117.3C960,96,1056,96,1152,112C1248,128,1344,160,1392,176L1440,192L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"
          />
        </svg>
      </div>

      {/* 4. Nighttime Celestial Twinkling Stars (Only visible in Dark/Night mode) */}
      {isDark && (
        <div className="absolute inset-0">
          <div className="absolute top-8 left-[15%] w-1.5 h-1.5 rounded-full bg-[#C5A059] opacity-70 animate-twinkle-1" />
          <div className="absolute top-20 right-[20%] w-1 h-1 rounded-full bg-white opacity-60 animate-twinkle-2" />
          <div className="absolute top-36 left-[30%] w-1 h-1 rounded-full bg-amber-200 opacity-50 animate-twinkle-3" />
          <div className="absolute top-14 right-[35%] w-1.5 h-1.5 rounded-full bg-[#C5A059] opacity-80 animate-twinkle-1" />
          <div className="absolute top-48 right-[10%] w-1 h-1 rounded-full bg-white opacity-40 animate-twinkle-2" />
          <div className="absolute top-64 left-[10%] w-1 h-1 rounded-full bg-amber-100 opacity-50 animate-twinkle-3" />
        </div>
      )}

      {/* 5. Soft Light Ray Beams drifting through the sky */}
      <div className="absolute -top-20 left-1/4 w-32 h-[450px] bg-gradient-to-b from-[#C5A059]/10 via-[#C5A059]/5 to-transparent rotate-[25deg] blur-2xl animate-light-beam pointer-events-none" />
      <div className="absolute -top-24 right-1/4 w-28 h-[400px] bg-gradient-to-b from-[#C5A059]/10 via-[#C5A059]/5 to-transparent -rotate-[20deg] blur-2xl animate-light-beam-reverse pointer-events-none" />
    </div>
  );
};
