import React, { useState, useMemo } from 'react';
import { Sparkles, Heart, Share2, Copy, Check, Users, Search, BookOpen, Sun, Moon, ArrowLeft } from 'lucide-react';
import { PRAYER_VIRTUES_DATA, VIRTUES_CATEGORIES, PrayerVirtueItem } from '../data/prayerVirtuesData';
import { useTheme } from '../context/ThemeContext';
import { PrayerTimeItem } from '../types/prayer';

interface PrayerVirtuesViewProps {
  onBack?: () => void;
  nextPrayer?: PrayerTimeItem;
}

export const PrayerVirtuesView: React.FC<PrayerVirtuesViewProps> = ({ onBack, nextPrayer }) => {
  const { isDark } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Pick today's featured virtue dynamically based on nextPrayer or day
  const dailyFeaturedVirtue = useMemo(() => {
    if (nextPrayer) {
      if (nextPrayer.id === 'fajr') {
        return PRAYER_VIRTUES_DATA.find((v) => v.category === 'fajr') || PRAYER_VIRTUES_DATA[0];
      }
      if (nextPrayer.id === 'asr') {
        return PRAYER_VIRTUES_DATA.find((v) => v.category === 'asr') || PRAYER_VIRTUES_DATA[0];
      }
      if (nextPrayer.id === 'isha') {
        return PRAYER_VIRTUES_DATA.find((v) => v.category === 'isha') || PRAYER_VIRTUES_DATA[0];
      }
    }
    // Default to the first prominent mosque congregation virtue
    return PRAYER_VIRTUES_DATA[0];
  }, [nextPrayer]);

  // Filtered virtues
  const filteredVirtues = useMemo(() => {
    return PRAYER_VIRTUES_DATA.filter((item) => {
      const matchesCategory =
        selectedCategory === 'all' || item.category === selectedCategory;

      if (!matchesCategory) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      const cleanText = item.hadithText.replace(/[\u064B-\u065F\u0670]/g, '').toLowerCase();
      const cleanTitle = item.title.replace(/[\u064B-\u065F\u0670]/g, '').toLowerCase();
      const cleanExpl = item.explanationAr.replace(/[\u064B-\u065F\u0670]/g, '').toLowerCase();

      return (
        cleanTitle.includes(q) ||
        cleanText.includes(q) ||
        cleanExpl.includes(q) ||
        item.categoryAr.includes(q)
      );
    });
  }, [selectedCategory, searchQuery]);

  const handleCopy = (item: PrayerVirtueItem) => {
    const text = `${item.title}\n\n${item.hadithText}\n${item.narrator ? item.narrator + '\n' : ''}[${item.reference}]\n\nالشرح: ${item.explanationAr}\n\nالوصية: ${item.actionRecommendation}`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = async (item: PrayerVirtueItem) => {
    const text = `${item.title}\n\n${item.hadithText}\n[${item.reference}]\n\n${item.explanationAr}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text,
        });
      } catch {
        // cancelled
      }
    } else {
      handleCopy(item);
    }
  };

  return (
    <div className="w-full flex-1 flex flex-col select-none pb-8 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-4 mb-2">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 rounded-2xl bg-gradient-to-br from-[#C5A059] to-[#8C6B28] text-black shadow-md">
            <Heart className="w-5 h-5 fill-black" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold font-['Cairo',sans-serif] text-[#C5A059] flex items-center gap-2">
              <span>فضل الصلاة</span>
              <Sparkles className="w-4 h-4" />
            </h2>
            <p className={`text-xs ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
              فضائل الصلوات الخمس وصلاة الجماعة في المسجد
            </p>
          </div>
        </div>

        {onBack && (
          <button
            onClick={onBack}
            className={`p-2 rounded-full border transition-colors cursor-pointer ${
              isDark
                ? 'bg-white/5 border-white/10 text-white/80 hover:bg-white/10'
                : 'bg-black/5 border-black/10 text-gray-700 hover:bg-black/10'
            }`}
            title="رجوع للرئيسية"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Featured Today Banner */}
      <div
        className={`relative rounded-3xl p-5 mb-4 border overflow-hidden shadow-xl ${
          isDark
            ? 'bg-gradient-to-br from-[#241E15] via-[#1A1820] to-[#12111A] border-[#C5A059]/40'
            : 'bg-gradient-to-br from-[#FFF9EE] via-[#F9F4EA] to-[#F1E8D5] border-[#C5A059]/50 shadow-[0_8px_25px_rgba(197,160,89,0.15)]'
        }`}
      >
        <div className="absolute top-0 left-0 w-32 h-32 bg-radial from-[#C5A059]/20 to-transparent rounded-full pointer-events-none blur-2xl" />

        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-bold text-[#C5A059] bg-[#C5A059]/15 border border-[#C5A059]/30 px-2.5 py-0.5 rounded-full flex items-center gap-1.5">
            <Sparkles className="w-3 h-3" />
            <span>فضيلة اليوم المختارة</span>
          </span>
          <span className="text-[11px] text-white/50">{dailyFeaturedVirtue.categoryAr}</span>
        </div>

        <h3 className="text-base sm:text-lg font-bold text-[#C5A059] mb-2 font-['Cairo',sans-serif]">
          {dailyFeaturedVirtue.title}
        </h3>

        <p className="text-base sm:text-lg font-['Amiri',serif] leading-relaxed mb-3 text-justify [text-align-last:right]">
          {dailyFeaturedVirtue.hadithText}
        </p>

        <div className="flex items-center justify-between text-xs pt-2 border-t border-[#C5A059]/20">
          <span className="text-[11px] text-[#C5A059]/80 truncate">
            {dailyFeaturedVirtue.reference}
          </span>
          <button
            onClick={() => handleCopy(dailyFeaturedVirtue)}
            className="flex items-center gap-1 text-xs text-[#C5A059] hover:underline cursor-pointer font-bold"
          >
            {copiedId === dailyFeaturedVirtue.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedId === dailyFeaturedVirtue.id ? 'تم النسخ' : 'نسخ الفضيلة'}</span>
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="mb-3">
        <div
          className={`relative flex items-center rounded-2xl border px-3 py-2 transition-all ${
            isDark
              ? 'bg-[#181720] border-white/10 focus-within:border-[#C5A059]'
              : 'bg-white border-[#C5A059]/30 focus-within:border-[#C5A059] shadow-sm'
          }`}
        >
          <Search className="w-4 h-4 text-[#C5A059] shrink-0 ml-2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في فضائل الصلاة والجماعة..."
            className="w-full bg-transparent text-xs sm:text-sm focus:outline-none placeholder:text-white/40"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-[#C5A059] hover:underline shrink-0"
            >
              مسح
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div className="pb-3 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0 mb-1">
        {VIRTUES_CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#C5A059] text-black shadow-md'
                  : isDark
                  ? 'bg-white/5 text-white/70 hover:bg-white/10'
                  : 'bg-black/5 text-gray-600 hover:bg-black/10'
              }`}
            >
              {cat.nameAr}
            </button>
          );
        })}
      </div>

      {/* Virtues Card Grid */}
      <div className="space-y-3.5">
        {filteredVirtues.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="w-10 h-10 text-[#C5A059]/40 mx-auto mb-2" />
            <p className="text-sm font-bold text-[#C5A059]">لا توجد فضائل مطابقة لبحثك</p>
          </div>
        ) : (
          filteredVirtues.map((item) => {
            return (
              <div
                key={item.id}
                className={`p-4 rounded-3xl border transition-all ${
                  isDark
                    ? 'bg-[#181722] border-white/5 hover:border-[#C5A059]/30'
                    : 'bg-white border-[#C5A059]/25 hover:border-[#C5A059]/50 shadow-sm'
                }`}
              >
                {/* Card Title & Category Tag */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <h4 className="text-sm sm:text-base font-bold text-[#C5A059] font-['Cairo',sans-serif]">
                    {item.title}
                  </h4>
                  <span
                    className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${
                      item.category === 'congregation'
                        ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                        : isDark
                        ? 'bg-white/5 text-white/60'
                        : 'bg-black/5 text-gray-600'
                    }`}
                  >
                    {item.categoryAr}
                  </span>
                </div>

                {/* Hadith Arabic Text */}
                <p className="text-base sm:text-lg leading-relaxed font-['Amiri',serif] font-medium text-justify [text-align-last:right] mb-2.5">
                  {item.hadithText}
                </p>

                {item.narrator && (
                  <span className={`text-xs block mb-2 ${isDark ? 'text-white/50' : 'text-gray-500'}`}>
                    {item.narrator}
                  </span>
                )}

                {/* Wisdom & Explanation */}
                <div
                  className={`p-3 rounded-2xl mb-2.5 text-xs leading-relaxed ${
                    isDark ? 'bg-[#121118] text-white/80' : 'bg-[#FAF8F4] text-gray-700'
                  }`}
                >
                  <span className="font-bold text-[#C5A059] block mb-1">الفائدة والفضل:</span>
                  <p>{item.explanationAr}</p>
                </div>

                {/* Recommendation */}
                <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 mb-3 flex items-start gap-1.5">
                  <span className="font-bold shrink-0">💡 وصية:</span>
                  <span>{item.actionRecommendation}</span>
                </div>

                {/* Bottom row: Reference, Copy, Share */}
                <div
                  className={`pt-2.5 border-t flex items-center justify-between text-xs ${
                    isDark ? 'border-white/5 text-white/50' : 'border-black/5 text-gray-500'
                  }`}
                >
                  <span className="text-[11px] truncate max-w-[200px] sm:max-w-[260px]">
                    {item.reference}
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCopy(item)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'
                      }`}
                      title="نسخ الفضيلة"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 text-[#C5A059]" />
                      )}
                    </button>

                    <button
                      onClick={() => handleShare(item)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'
                      }`}
                      title="مشاركة الفضيلة"
                    >
                      <Share2 className="w-3.5 h-3.5 text-[#C5A059]" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
