import React, { useState, useEffect, useCallback } from 'react';
import { Volume2, VolumeX, Square, BellOff, Smartphone } from 'lucide-react';
import { audioAdhanService, AdhanPlaybackState } from '../services/audioAdhan';
import { notificationService } from '../services/notificationService';
import { useShakeDetector } from '../hooks/useShakeDetector';
import { nativeAlarmBridge } from '../services/nativeAlarmBridge';

interface AdhanMiniPlayerProps {
  shakeEnabled?: boolean;
  shakeThreshold?: number;
  onAdhanStoppedByShake?: (message: string) => void;
}

export const AdhanMiniPlayer: React.FC<AdhanMiniPlayerProps> = ({
  shakeEnabled = true,
  shakeThreshold = 5.5,
  onAdhanStoppedByShake,
}) => {
  const [playbackState, setPlaybackState] = useState<AdhanPlaybackState>(() =>
    audioAdhanService.getPlaybackState()
  );
  const [shakeStoppedToast, setShakeStoppedToast] = useState(false);

  useEffect(() => {
    const unsubscribe = audioAdhanService.subscribe((state) => {
      setPlaybackState(state);
    });
    return unsubscribe;
  }, []);

  // Explicit 'shakeToStopAdhan' callback function
  const shakeToStopAdhan = useCallback(() => {
    console.log('[AdhanMiniPlayer] >>> EXECUTING shakeToStopAdhan() handler via motion sensor <<<');

    // Check audio element reference in notificationService
    const currentAudioRef = notificationService.getCurrentAudio();
    console.log('[AdhanMiniPlayer] Audio element reference in notificationService:', {
      exists: !!currentAudioRef,
      src: currentAudioRef?.src,
      paused: currentAudioRef?.paused,
      currentTime: currentAudioRef?.currentTime,
    });

    // Stop audio via notificationService, audioAdhanService, and native Android bridge
    const stopped = notificationService.stopAdhan();
    audioAdhanService.stopAll();
    nativeAlarmBridge.stopAdhan();
    console.log('[AdhanMiniPlayer] notificationService.stopAdhan() executed. Result:', stopped);

    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(0);
      } catch {
        // ignore
      }
    }
    setShakeStoppedToast(true);
    if (onAdhanStoppedByShake) {
      onAdhanStoppedByShake('تم إيقاف الأذان عبر اهتزاز الهاتف 📳');
    }
    setTimeout(() => {
      setShakeStoppedToast(false);
    }, 4000);
  }, [onAdhanStoppedByShake]);

  // Diagnostic monitoring of DeviceMotionEvent and DeviceOrientationEvent availability & hardware telemetry
  useEffect(() => {
    const isClient = typeof window !== 'undefined';
    const isSecure = isClient && window.isSecureContext;
    const hasDeviceMotion = isClient && 'DeviceMotionEvent' in window;
    const hasDeviceOrientation = isClient && 'DeviceOrientationEvent' in window;
    const needsIosPermission =
      hasDeviceMotion &&
      typeof (window as unknown as { DeviceMotionEvent?: { requestPermission?: unknown } })
        .DeviceMotionEvent?.requestPermission === 'function';

    console.log('[AdhanMiniPlayer] Sensor Availability & Context Diagnostics:', {
      isSecureContext: isSecure,
      DeviceMotionEventAvailable: hasDeviceMotion,
      DeviceOrientationEventAvailable: hasDeviceOrientation,
      requiresIosPermissionFlow: needsIosPermission,
      playbackState: {
        isPlaying: playbackState.isPlaying,
        activeId: playbackState.activeId,
        title: playbackState.title,
      },
      shakeToStopAdhanSetting: {
        enabled: shakeEnabled,
        isReachable: typeof shakeToStopAdhan === 'function',
      },
    });

    // Query Permissions API if supported in browser
    if (typeof navigator !== 'undefined' && 'permissions' in navigator && navigator.permissions?.query) {
      try {
        navigator.permissions
          .query({ name: 'accelerometer' as PermissionName })
          .then((res) => {
            console.log('[AdhanMiniPlayer] Accelerometer Permission status:', res.state);
          })
          .catch(() => {
            // Accelerometer query not implemented in some browsers, safe to ignore
          });
      } catch {
        // ignore
      }
    }
  }, [playbackState.isPlaying, playbackState.activeId, playbackState.title, shakeEnabled, shakeToStopAdhan]);

  // Motion event capture verification and live accelerationIncludingGravity telemetry stream
  useEffect(() => {
    if (!playbackState.isPlaying || !shakeEnabled || typeof window === 'undefined') {
      console.log('[AdhanMiniPlayer] devicemotion listener inactive (isPlaying:', playbackState.isPlaying, ', shakeEnabled:', shakeEnabled, ')');
      return;
    }

    console.log('[AdhanMiniPlayer] ATTACHING devicemotion & deviceorientation listeners. Target: shakeToStopAdhan');

    let motionEventCount = 0;
    let orientationEventCount = 0;
    let liveDataConfirmed = false;

    const verifyMotionListener = (event: DeviceMotionEvent) => {
      motionEventCount++;

      const accG = event.accelerationIncludingGravity;
      const accLinear = event.acceleration;

      const hasAccG = !!accG && accG.x !== null && accG.y !== null && accG.z !== null;
      const hasAccLinear = !!accLinear && accLinear.x !== null && accLinear.y !== null && accLinear.z !== null;

      if (hasAccG && !liveDataConfirmed) {
        liveDataConfirmed = true;
        const totalG = Math.sqrt((accG.x ?? 0) ** 2 + (accG.y ?? 0) ** 2 + (accG.z ?? 0) ** 2);
        console.log('[AdhanMiniPlayer] CONFIRMED: accelerationIncludingGravity is receiving LIVE telemetry from mobile hardware!', {
          firstPacketAtEvent: motionEventCount,
          accelerationIncludingGravity: {
            x: Number(accG.x?.toFixed(3)),
            y: Number(accG.y?.toFixed(3)),
            z: Number(accG.z?.toFixed(3)),
            magnitude: Number(totalG.toFixed(3)),
          },
          linearAccelerationAvailable: hasAccLinear,
          shakeToStopAdhanReachable: typeof shakeToStopAdhan === 'function',
        });
      }

      // Periodic stream telemetry log (every 60 samples ~ once per second)
      if (motionEventCount % 60 === 0) {
        const totalG = accG ? Math.sqrt((accG.x ?? 0) ** 2 + (accG.y ?? 0) ** 2 + (accG.z ?? 0) ** 2) : 0;
        console.log('[AdhanMiniPlayer] [devicemotion Stream Heartbeat]', {
          eventCount: motionEventCount,
          interval: event.interval,
          x: accG?.x !== null && accG?.x !== undefined ? Number(accG.x.toFixed(2)) : null,
          y: accG?.y !== null && accG?.y !== undefined ? Number(accG.y.toFixed(2)) : null,
          z: accG?.z !== null && accG?.z !== undefined ? Number(accG.z.toFixed(2)) : null,
          magnitude: Number(totalG.toFixed(2)),
          shakeToStopAdhanReady: typeof shakeToStopAdhan === 'function',
        });
      }
    };

    const verifyOrientationListener = (event: DeviceOrientationEvent) => {
      orientationEventCount++;
      if (orientationEventCount === 1) {
        console.log('[AdhanMiniPlayer] CONFIRMED: deviceorientation fallback receiving data:', {
          alpha: event.alpha !== null ? Number(event.alpha.toFixed(1)) : null,
          beta: event.beta !== null ? Number(event.beta.toFixed(1)) : null,
          gamma: event.gamma !== null ? Number(event.gamma.toFixed(1)) : null,
        });
      }
    };

    window.addEventListener('devicemotion', verifyMotionListener, { passive: true });
    window.addEventListener('deviceorientation', verifyOrientationListener, { passive: true });

    return () => {
      window.removeEventListener('devicemotion', verifyMotionListener);
      window.removeEventListener('deviceorientation', verifyOrientationListener);
      console.log('[AdhanMiniPlayer] devicemotion & deviceorientation listeners detached and cleaned up.');
    };
  }, [playbackState.isPlaying, shakeEnabled, shakeToStopAdhan]);

  // Shake Phone to Stop Adhan
  useShakeDetector({
    enabled: playbackState.isPlaying && shakeEnabled,
    threshold: shakeThreshold,
    onShake: shakeToStopAdhan,
  });

  const handleStopAdhan = () => {
    console.log('[AdhanMiniPlayer] User tapped stop button');
    const currentAudioRef = notificationService.getCurrentAudio();
    console.log('[AdhanMiniPlayer] Current audio element before manual stop:', {
      src: currentAudioRef?.src,
      paused: currentAudioRef?.paused,
    });
    notificationService.stopAdhan();
    audioAdhanService.stopAll();
    nativeAlarmBridge.stopAdhan();
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(0);
      } catch {}
    }
  };

  // Toast confirming stopped by shake
  if (shakeStoppedToast) {
    return (
      <div className="fixed bottom-24 left-4 right-4 z-50 max-w-sm mx-auto animate-in fade-in slide-in-from-bottom-4 duration-300">
        <div className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-emerald-950/95 border border-emerald-500/60 shadow-2xl backdrop-blur-md text-emerald-300 text-xs font-bold text-center">
          <Smartphone className="w-4 h-4 animate-bounce" />
          <span>تم إيقاف الأذان بنجاح عبر اهتزاز الهاتف 📳</span>
        </div>
      </div>
    );
  }

  // Appears ONLY when Adhan is actively playing
  if (!playbackState.isPlaying) {
    return null;
  }

  return (
    <aside
      aria-label="لوحة إيقاف الأذان"
      className="fixed bottom-20 left-3 right-3 z-50 max-w-md mx-auto animate-in slide-in-from-bottom-6 duration-300 select-none"
    >
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#1E1B18] via-[#241F1A] to-[#1E1B18] border-2 border-[#C5A059] shadow-[0_12px_40px_rgba(0,0,0,0.95)] p-3 sm:p-3.5 ring-4 ring-[#C5A059]/20">
        {/* Ambient background glow */}
        <div className="absolute -top-12 -left-12 w-32 h-32 rounded-full bg-red-500/20 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-32 h-32 rounded-full bg-[#C5A059]/20 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex items-center justify-between gap-2.5">
          {/* Audio Visualizer & Name */}
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="relative flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-br from-[#C5A059] to-[#8C6D32] text-black shrink-0 shadow-lg animate-pulse">
              <Volume2 className="w-6 h-6 fill-black" />
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-500 border-2 border-black animate-ping" />
            </div>

            <div className="text-right min-w-0 flex-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-xs sm:text-sm font-extrabold text-white font-['Cairo',sans-serif] truncate">
                  {playbackState.title || 'أذان الصلاة'}
                </span>
                <span className="flex items-center gap-0.5 h-3">
                  <span className="w-1 h-3.5 bg-red-400 rounded-full animate-bounce [animation-delay:0.1s]" />
                  <span className="w-1 h-2.5 bg-[#C5A059] rounded-full animate-bounce [animation-delay:0.3s]" />
                  <span className="w-1 h-4 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                </span>
              </div>
              <p className="text-[11px] text-[#C5A059] truncate font-medium mt-0.5">
                {playbackState.muezzinName || 'صوت الأذان المبارك'}
              </p>
            </div>
          </div>

          {/* Prominent Stop Adhan Button (الأيقونة المطلوبة لإيقاف الأذان) */}
          <button
            onClick={handleStopAdhan}
            title="إيقاف الأذان الآن"
            className="flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-xs sm:text-sm shadow-xl active:scale-95 transition-all cursor-pointer border border-red-400/50 shrink-0 group animate-pulse"
          >
            <Square className="w-4 h-4 fill-white shrink-0 group-hover:scale-110 transition-transform" />
            <span>إيقاف الأذان</span>
          </button>
        </div>

        {/* Shake to Stop Helpful Hint */}
        {shakeEnabled && (
          <div className="relative z-10 mt-2 pt-2 border-t border-white/10 flex items-center justify-center gap-1.5 text-[11px] text-amber-200/90 font-medium text-center">
            <Smartphone className="w-3.5 h-3.5 text-[#C5A059] animate-pulse" />
            <span>يمكنك أيضاً هز الهاتف 📳 لإيقاف الأذان فوراً</span>
          </div>
        )}
      </div>
    </aside>
  );
};
