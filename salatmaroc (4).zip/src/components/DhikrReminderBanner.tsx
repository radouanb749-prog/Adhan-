import React, { useState, useEffect } from 'react';
import { Sun, Moon, X, BookOpen } from 'lucide-react';
import { DhikrReminderData, notificationService } from '../services/notificationService';

interface DhikrReminderBannerProps {
  onOpenAdhkar: (category: 'morning' | 'evening') => void;
}

export const DhikrReminderBanner: React.FC<DhikrReminderBannerProps> = ({ onOpenAdhkar }) => {
  const [activeReminder, setActiveReminder] = useState<DhikrReminderData | null>(null);

  useEffect(() => {
    const unsubscribe = notificationService.onDhikrReminder((data) => {
      setActiveReminder(data);
    });
    return unsubscribe;
  }, []);

  // Auto dismiss after 18 seconds
  useEffect(() => {
    if (!activeReminder) return;
    const timer = setTimeout(() => {
      setActiveReminder(null);
    }, 18000);
    return () => clearTimeout(timer);
  }, [activeReminder]);

  if (!activeReminder) return null;

  const isMorning = activeReminder.type === 'morning';

  return (
    <div className="fixed top-4 left-4 right-4 z-50 max-w-md mx-auto animate-in slide-in-from-top duration-300 select-none">
      <div className="relative rounded-2xl bg-gradient-to-r from-[#1E1B18] via-[#1A1816] to-[#161412] border-2 border-[#C5A059] p-4 shadow-[0_12px_40px_rgba(0,0,0,0.85)] overflow-hidden">
        {/* Glow */}
        <div
          className={`absolute -top-12 -right-12 w-28 h-28 rounded-full blur-xl pointer-events-none ${
            isMorning ? 'bg-amber-500/20' : 'bg-indigo-500/20'
          }`}
        />

        <div className="flex items-start justify-between gap-3">
          {/* Icon */}
          <div
            className={`p-2.5 rounded-xl border shrink-0 ${
              isMorning
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40 animate-pulse'
                : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 animate-pulse'
            }`}
          >
            {isMorning ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </div>

          <div className="flex-1 text-right">
            <div className="flex items-center gap-2">
              <span
                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                  isMorning
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
                }`}
              >
                {isMorning ? 'ورد الصباح ☀️' : 'ورد المساء 🌙'}
              </span>
              <span className="text-[11px] text-white/50">تذكير يومي</span>
            </div>

            <h4 className="text-base font-bold text-white mt-1.5 font-['Cairo',sans-serif]">
              {activeReminder.title}
            </h4>

            <p className="text-xs text-white/75 mt-0.5 leading-relaxed">
              {activeReminder.body}
            </p>

            <div className="mt-3 flex items-center gap-2">
              <button
                onClick={() => {
                  const type = activeReminder.type;
                  setActiveReminder(null);
                  onOpenAdhkar(type);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#C5A059] hover:bg-[#d4b065] text-black font-bold text-xs transition-all active:scale-95 shadow cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>قراءة الأذكار الآن</span>
              </button>

              <button
                onClick={() => setActiveReminder(null)}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white font-medium text-xs transition-all cursor-pointer"
              >
                لاحقاً
              </button>
            </div>
          </div>

          <button
            onClick={() => setActiveReminder(null)}
            className="p-1 rounded-full text-white/40 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
