import React, { useState, useMemo } from 'react';
import { Copy, Check, Share2, BookOpen, RotateCw } from 'lucide-react';
import { AUTHENTIC_HADITHS, getDailyHadith } from '../data/hadithsData';
import { useTheme } from '../context/ThemeContext';

interface HadithCardProps {
  onOpenHadithsModal: () => void;
  targetDate?: Date;
}

export const HadithCard: React.FC<HadithCardProps> = ({ onOpenHadithsModal, targetDate }) => {
  const { isDark } = useTheme();
  const [copied, setCopied] = useState(false);
  const [rotationOffset, setRotationOffset] = useState(0);

  // Daily Hadith based on date, with optional user rotation
  const hadith = useMemo(() => {
    const base = getDailyHadith(targetDate || new Date());
    if (rotationOffset === 0) return base;
    const baseIndex = AUTHENTIC_HADITHS.findIndex((h) => h.id === base.id);
    const newIndex = (baseIndex + rotationOffset + AUTHENTIC_HADITHS.length) % AUTHENTIC_HADITHS.length;
    return AUTHENTIC_HADITHS[newIndex];
  }, [targetDate, rotationOffset]);

  const handleNextHadith = () => {
    setRotationOffset((prev) => prev + 1);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(`${hadith.text}\n[${hadith.source}]`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'حديث اليوم',
          text: `${hadith.text}\n[${hadith.source}]`,
        });
      } catch {
        // cancelled or unsupported
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="w-full px-4 py-3 select-none">
      <div
        className={`relative rounded-2xl p-5 overflow-hidden transition-all duration-300 ${
          isDark
            ? 'bg-[#1E1E1E] border border-white/5 shadow-lg hover:border-[#C5A059]/30'
            : 'bg-white border border-[#C5A059]/30 shadow-[0_4px_20px_rgba(0,0,0,0.06)] hover:border-[#C5A059]/60'
        }`}
      >
        {/* Subtle decorative Islamic arch pattern in top corner */}
        <div className="absolute top-0 left-0 w-24 h-24 bg-gradient-to-br from-[#C5A059]/10 to-transparent rounded-br-full pointer-events-none" />

        {/* Centered Title */}
        <div className="flex flex-col items-center justify-center mb-3">
          <div className="flex items-center gap-2">
            <span className="h-[1px] w-6 bg-[#C5A059]/40" />
            <h3 className="text-base sm:text-lg font-bold text-[#C5A059] tracking-wide font-['Cairo',sans-serif]">
              حديث اليوم
            </h3>
            <span className="h-[1px] w-6 bg-[#C5A059]/40" />
          </div>
        </div>

        {/* Hadith Arabic Text */}
        <div className="text-center px-2 py-2">
          <p
            className={`text-base sm:text-lg leading-relaxed font-['Amiri',serif] font-medium text-justify [text-align-last:center] ${
              isDark ? 'text-white/95' : 'text-gray-900'
            }`}
          >
            {hadith.text}
          </p>

          {/* Reference */}
          <span
            className={`inline-block mt-3 text-xs font-['Cairo',sans-serif] ${
              isDark ? 'text-[#C5A059]/80' : 'text-[#8B6508]'
            }`}
          >
            {hadith.source}
          </span>
        </div>

        {/* Action icons bar */}
        <div
          className={`mt-4 pt-3 border-t flex items-center justify-between text-xs ${
            isDark
              ? 'border-white/5 text-white/60'
              : 'border-[#C5A059]/15 text-gray-600'
          }`}
        >
          <button
            onClick={onOpenHadithsModal}
            className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
              isDark ? 'text-white/70 hover:text-[#C5A059]' : 'text-gray-700 hover:text-[#8B6508]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>المزيد من الأحاديث</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleNextHadith}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer flex items-center gap-1 text-[11px] ${
                isDark
                  ? 'hover:bg-white/5 text-white/70 hover:text-[#C5A059]'
                  : 'hover:bg-gray-100 text-gray-600 hover:text-[#8B6508]'
              }`}
              title="حديث آخر مداورة"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">مداورة</span>
            </button>

            <button
              onClick={handleCopy}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isDark
                  ? 'hover:bg-white/5 text-white/70 hover:text-[#C5A059]'
                  : 'hover:bg-gray-100 text-gray-600 hover:text-[#8B6508]'
              }`}
              title="نسخ الحديث"
            >
              {copied ? (
                <Check className="w-4 h-4 text-emerald-500" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </button>

            <button
              onClick={handleShare}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isDark
                  ? 'hover:bg-white/5 text-white/70 hover:text-[#C5A059]'
                  : 'hover:bg-gray-100 text-gray-600 hover:text-[#8B6508]'
              }`}
              title="مشاركة الحديث"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
