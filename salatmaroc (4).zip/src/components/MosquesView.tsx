import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import L from 'leaflet';
import {
  MapPin,
  Navigation,
  ExternalLink,
  Search,
  Crosshair,
  Layers,
  Map as MapIcon,
  List,
  Sparkles,
  CheckCircle2,
  ChevronLeft,
  Info,
} from 'lucide-react';
import { CityData } from '../types/prayer';
import { MosqueIcon } from './BottomNav';
import { MOROCCO_MOSQUES, MosqueItem } from '../data/mosquesData';
import { calculateDistanceKm } from '../data/moroccoCities';
import { useTheme } from '../context/ThemeContext';

interface MosquesViewProps {
  currentCity: CityData;
  onBack: () => void;
}

export const MosquesView: React.FC<MosquesViewProps> = ({ currentCity, onBack }) => {
  const { isDark } = useTheme();
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const userAccuracyCircleRef = useRef<L.Circle | null>(null);

  // User GPS coordinates (starts with current city coordinates, updates with real-time device GPS)
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number }>({
    lat: currentCity.lat,
    lng: currentCity.lng,
  });
  const [isLocating, setIsLocating] = useState(false);
  const [gpsAccuracy, setGpsAccuracy] = useState<number | null>(null);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // View mode: 'split' (map on top + list below), 'map' (full map), 'list' (list only)
  const [viewMode, setViewMode] = useState<'split' | 'map' | 'list'>('split');

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [filterJumuahOnly, setFilterJumuahOnly] = useState(false);
  const [filterNearbyOnly, setFilterNearbyOnly] = useState(false);
  const [selectedMosqueId, setSelectedMosqueId] = useState<string | null>(null);

  // Dynamic nearby mosques fetched via OSM Overpass when user is in Morocco
  const [liveMosques, setLiveMosques] = useState<MosqueItem[]>([]);

  // 1. Live Geolocation Handler
  const handleLocateUser = useCallback(() => {
    if (!navigator.geolocation) {
      setGpsError('خاصية تحديد الموقع الجغرافي (GPS) غير مدعومة في متصفحك.');
      return;
    }

    setIsLocating(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        setUserCoords({ lat: latitude, lng: longitude });
        setGpsAccuracy(accuracy);
        setIsLocating(false);

        // Center map to user position if map is initialized
        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo([latitude, longitude], 15, {
            duration: 1.2,
          });
        }
      },
      (err) => {
        setIsLocating(false);
        if (err.code === err.PERMISSION_DENIED) {
          setGpsError('تم رفض إذن الوصول إلى الموقع. يمكنك تفعيله من إعدادات المتصفح.');
        } else {
          setGpsError('تعذر التقاط إشارة GPS الدقيقة حالياً. يتم استخدام إحداثيات المدينة.');
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
    );
  }, []);

  // Try locating on initial view mount
  useEffect(() => {
    handleLocateUser();
  }, [handleLocateUser]);

  // Sync userCoords with currentCity if city changes
  useEffect(() => {
    setUserCoords({ lat: currentCity.lat, lng: currentCity.lng });
  }, [currentCity.id, currentCity.lat, currentCity.lng]);

  // 2. Fetch additional neighborhood mosques via Overpass API within 5km of GPS coords
  useEffect(() => {
    let isCancelled = false;
    const fetchOsmMosques = async () => {
      try {
        const query = `[out:json][timeout:8];node["amenity"="place_of_worship"]["religion"="muslim"](around:6000,${userCoords.lat},${userCoords.lng});out 30;`;
        const res = await fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`);
        if (!res.ok) return;
        const data = await res.json();
        if (isCancelled || !data.elements) return;

        const mapped: MosqueItem[] = data.elements
          .filter((el: any) => el.tags && (el.tags.name || el.tags['name:ar']))
          .map((el: any, index: number) => ({
            id: `osm-${el.id || index}`,
            name: el.tags['name:ar'] || el.tags.name || 'مسجد محلي',
            neighborhood: el.tags['addr:street'] || el.tags['addr:suburb'] || currentCity.nameAr,
            city: currentCity.nameAr,
            coordinates: { lat: el.lat, lng: el.lon },
            jumuah: true,
            features: ['مسجد معتمد بـ OSM'],
          }));

        if (!isCancelled && mapped.length > 0) {
          setLiveMosques(mapped);
        }
      } catch {
        // Fallback gracefully to built-in verified mosques
      }
    };

    fetchOsmMosques();
    return () => {
      isCancelled = true;
    };
  }, [userCoords.lat, userCoords.lng, currentCity.nameAr]);

  // 3. Merge built-in mosques + live mosques, compute distance, and sort closest first
  const allSortedMosques = useMemo(() => {
    const combined = [...MOROCCO_MOSQUES];

    // Merge live OSM mosques avoiding exact duplicate names
    liveMosques.forEach((osm) => {
      const exists = combined.some(
        (m) =>
          m.name.trim() === osm.name.trim() ||
          calculateDistanceKm(m.coordinates.lat, m.coordinates.lng, osm.coordinates.lat, osm.coordinates.lng) < 0.1
      );
      if (!exists) {
        combined.push(osm);
      }
    });

    // Compute dynamic distance from user GPS coordinates
    const withDistance = combined.map((m) => {
      const dist = calculateDistanceKm(
        userCoords.lat,
        userCoords.lng,
        m.coordinates.lat,
        m.coordinates.lng
      );
      return {
        ...m,
        distanceKm: Number(dist.toFixed(2)),
      };
    });

    // Sort strictly closest first
    withDistance.sort((a, b) => (a.distanceKm ?? 999) - (b.distanceKm ?? 999));

    return withDistance;
  }, [userCoords.lat, userCoords.lng, liveMosques]);

  // 4. Filtered mosques based on search & filter chips
  const filteredMosques = useMemo(() => {
    return allSortedMosques.filter((m) => {
      const matchesSearch =
        m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.neighborhood.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.city.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesJumuah = !filterJumuahOnly || m.jumuah;
      const matchesNearby = !filterNearbyOnly || (m.distanceKm !== undefined && m.distanceKm <= 3.5);

      return matchesSearch && matchesJumuah && matchesNearby;
    });
  }, [allSortedMosques, searchTerm, filterJumuahOnly, filterNearbyOnly]);

  // 5. Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (viewMode === 'list') return;

    if (!mapInstanceRef.current) {
      // Create Leaflet map instance
      const map = L.map(mapContainerRef.current, {
        center: [userCoords.lat, userCoords.lng],
        zoom: 14,
        zoomControl: false,
        attributionControl: false,
      });

      // Add elegant CartoDB dark/light tile layer
      const tileUrl = isDark
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';

      L.tileLayer(tileUrl, {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      // Custom Zoom control at bottom left (RTL friendly)
      L.control.zoom({ position: 'bottomleft' }).addTo(map);

      // Layer group for mosque markers
      const markersLayer = L.layerGroup().addTo(map);
      markersLayerRef.current = markersLayer;
      mapInstanceRef.current = map;
    } else {
      // Invalidate size in case container dimensions changed
      mapInstanceRef.current.invalidateSize();
    }
  }, [viewMode, isDark, userCoords.lat, userCoords.lng]);

  // 6. Update User Location Pin on Map
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Remove existing user marker & circle
    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
    }
    if (userAccuracyCircleRef.current) {
      userAccuracyCircleRef.current.remove();
    }

    // User location pulsing marker
    const userIconHtml = `
      <div class="relative flex items-center justify-center w-8 h-8">
        <span class="absolute inline-flex w-full h-full rounded-full bg-blue-500 opacity-60 animate-ping"></span>
        <span class="relative inline-flex items-center justify-center w-5 h-5 rounded-full bg-gradient-to-tr from-blue-600 to-cyan-400 border-2 border-white shadow-lg text-white text-[10px] font-bold">
          📍
        </span>
      </div>
    `;

    const userIcon = L.divIcon({
      html: userIconHtml,
      className: 'user-location-pin',
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });

    const userMarker = L.marker([userCoords.lat, userCoords.lng], { icon: userIcon }).addTo(map);
    userMarker.bindPopup(`
      <div style="font-family: 'Cairo', sans-serif; text-align: right; direction: rtl; padding: 4px;">
        <strong style="color: #2563EB; font-size: 13px;">📍 موقعك الحالي (GPS)</strong>
        <p style="margin: 4px 0 0 0; font-size: 11px; color: #4B5563;">
          ${currentCity.nameAr} • الدقة: ±${gpsAccuracy ? Math.round(gpsAccuracy) : '15'} متر
        </p>
      </div>
    `);

    userMarkerRef.current = userMarker;

    // Optional subtle accuracy halo
    if (gpsAccuracy && gpsAccuracy < 500) {
      const circle = L.circle([userCoords.lat, userCoords.lng], {
        radius: gpsAccuracy,
        color: '#3B82F6',
        fillColor: '#3B82F6',
        fillOpacity: 0.12,
        weight: 1,
      }).addTo(map);
      userAccuracyCircleRef.current = circle;
    }
  }, [userCoords, gpsAccuracy, currentCity.nameAr]);

  // 7. Update Mosque Markers on Map
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();

    // Mosque Minaret Custom Marker Icon
    filteredMosques.forEach((mosque) => {
      const isSelected = selectedMosqueId === mosque.id;

      const mosqueIconHtml = `
        <div class="relative flex flex-col items-center cursor-pointer transition-transform duration-200 ${
          isSelected ? 'scale-125 z-50' : 'hover:scale-110'
        }">
          <div class="w-8 h-8 rounded-full flex items-center justify-center shadow-md border ${
            isSelected
              ? 'bg-[#C5A059] text-black border-white ring-2 ring-[#C5A059]'
              : 'bg-[#1E1E1E] text-[#C5A059] border-[#C5A059]/60 hover:bg-[#C5A059] hover:text-black'
          }">
            <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
              <path d="M12 2c.4 0 .8.2 1 .5l1.5 2.5h1.5c1.1 0 2 .9 2 2v1h1c1.1 0 2 .9 2 2v10c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V10c0-1.1.9-2 2-2h1V7c0-1.1.9-2 2-2h1.5L11 2.5c.2-.3.6-.5 1-.5zm0 11a3 3 0 0 0-3 3v4h6v-4a3 3 0 0 0-3-3z"/>
            </svg>
          </div>
          <span class="text-[9px] font-bold px-1.5 py-0.5 rounded-full mt-0.5 shadow-sm whitespace-nowrap ${
            isSelected
              ? 'bg-[#C5A059] text-black'
              : 'bg-black/80 text-white border border-white/20'
          }">
            ${mosque.distanceKm !== undefined ? `${mosque.distanceKm} كم` : ''}
          </span>
        </div>
      `;

      const customIcon = L.divIcon({
        html: mosqueIconHtml,
        className: 'mosque-map-pin',
        iconSize: [36, 44],
        iconAnchor: [18, 42],
        popupAnchor: [0, -42],
      });

      const marker = L.marker([mosque.coordinates.lat, mosque.coordinates.lng], {
        icon: customIcon,
      }).addTo(layer);

      // Popup Content
      const popupHtml = `
        <div style="font-family: 'Cairo', sans-serif; text-align: right; direction: rtl; min-width: 190px; padding: 4px;">
          <h4 style="margin: 0 0 4px 0; color: #C5A059; font-size: 14px; font-weight: bold;">
            ${mosque.name}
          </h4>
          <p style="margin: 0 0 4px 0; font-size: 11px; color: #6B7280;">
            📍 ${mosque.neighborhood}
          </p>
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; font-size: 11px;">
            <span style="color: #10B981; font-weight: bold;">
              ${mosque.distanceKm !== undefined ? `يبعد ${mosque.distanceKm} كم` : ''}
            </span>
            ${
              mosque.jumuah
                ? '<span style="background: rgba(197,160,89,0.15); color: #C5A059; padding: 1px 6px; border-radius: 4px; font-size: 10px;">تقام فيه الجمعة 🕌</span>'
                : ''
            }
          </div>
          <a
            href="https://www.google.com/maps/dir/?api=1&destination=${mosque.coordinates.lat},${mosque.coordinates.lng}"
            target="_blank"
            rel="noopener noreferrer"
            style="display: block; text-align: center; background: #C5A059; color: #000; padding: 6px 10px; border-radius: 8px; font-size: 11px; font-weight: bold; text-decoration: none;"
          >
            🧭 فتح المسار والملاحة (GPS)
          </a>
        </div>
      `;

      marker.bindPopup(popupHtml);

      marker.on('click', () => {
        setSelectedMosqueId(mosque.id);
      });
    });
  }, [filteredMosques, selectedMosqueId]);

  // Focus and fly to a mosque
  const handleSelectMosque = (mosque: MosqueItem) => {
    setSelectedMosqueId(mosque.id);
    if (mapInstanceRef.current && viewMode !== 'list') {
      mapInstanceRef.current.flyTo([mosque.coordinates.lat, mosque.coordinates.lng], 16, {
        duration: 1.0,
      });
    }
  };

  const openGoogleMapsDirections = (m: MosqueItem) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${m.coordinates.lat},${m.coordinates.lng}`;
    window.open(url, '_blank');
  };

  return (
    <div className="flex flex-col min-h-[620px] text-white select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-['Cairo',sans-serif] flex items-center gap-2 text-white">
            <MosqueIcon className="w-6 h-6 text-[#C5A059]" />
            <span>مساجد {currentCity.nameAr} والقريبة</span>
          </h2>
          <p className="text-xs text-white/50 mt-0.5">
            خريطة تفاعلية ترصد المساجد الأقرب لموقعك عبر الأقمار الاصطناعية (GPS)
          </p>
        </div>

        <button
          onClick={onBack}
          className="px-3.5 py-1.5 rounded-full bg-white/10 hover:bg-white/15 text-xs text-white/90 font-bold transition-all cursor-pointer flex items-center gap-1 active:scale-95"
        >
          <span>العودة</span>
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Control Toolbar: GPS button, View Mode toggles, Count */}
      <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
        {/* Locate Me Button */}
        <button
          onClick={handleLocateUser}
          disabled={isLocating}
          className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 ${
            isLocating
              ? 'bg-[#C5A059]/20 text-[#C5A059] border-[#C5A059] animate-pulse'
              : 'bg-[#1E1E1E] hover:bg-[#252525] text-white border-white/10 hover:border-[#C5A059]'
          }`}
          title="تحديث موقعك الحالي عبر GPS"
        >
          <Crosshair className={`w-3.5 h-3.5 text-[#C5A059] ${isLocating ? 'animate-spin' : ''}`} />
          <span>{isLocating ? 'جاري تحديد موقعك...' : 'تحديد موقعي الآن 📍'}</span>
        </button>

        {/* View Mode Switcher */}
        <div className="flex items-center bg-[#1A1A1A] p-0.5 rounded-xl border border-white/10">
          <button
            onClick={() => setViewMode('split')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
              viewMode === 'split' ? 'bg-[#C5A059] text-black shadow-sm' : 'text-white/60 hover:text-white'
            }`}
            title="عرض مقسوم: خريطة وقائمة"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">مقسوم</span>
          </button>
          <button
            onClick={() => setViewMode('map')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
              viewMode === 'map' ? 'bg-[#C5A059] text-black shadow-sm' : 'text-white/60 hover:text-white'
            }`}
            title="خريطة كاملة"
          >
            <MapIcon className="w-3.5 h-3.5" />
            <span>خريطة</span>
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
              viewMode === 'list' ? 'bg-[#C5A059] text-black shadow-sm' : 'text-white/60 hover:text-white'
            }`}
            title="قائمة فقط"
          >
            <List className="w-3.5 h-3.5" />
            <span>قائمة</span>
          </button>
        </div>
      </div>

      {/* GPS Error Alert if any */}
      {gpsError && (
        <div className="mb-3 p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
          <Info className="w-4 h-4 shrink-0" />
          <span>{gpsError}</span>
        </div>
      )}

      {/* Interactive Leaflet Map Container */}
      {viewMode !== 'list' && (
        <div className="relative mb-3.5 rounded-2xl overflow-hidden border border-[#C5A059]/40 shadow-xl">
          <div
            ref={mapContainerRef}
            className={`w-full transition-all duration-300 ${
              viewMode === 'map' ? 'h-[460px] sm:h-[520px]' : 'h-[250px] sm:h-[300px]'
            }`}
          />

          {/* Overlay Map Badge */}
          <div className="absolute top-2.5 right-2.5 z-[1000] pointer-events-none">
            <span className="text-[11px] font-bold bg-black/75 backdrop-blur-md text-[#C5A059] px-2.5 py-1 rounded-full border border-[#C5A059]/40 shadow-md">
              {filteredMosques.length} مسجد متوفر بالخريطة
            </span>
          </div>
        </div>
      )}

      {/* Search Input & Filter Chips */}
      {viewMode !== 'map' && (
        <div className="space-y-2.5 mb-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3.5 top-3 text-white/40" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث عن مسجد بالاسم أو بالحي..."
              className="w-full bg-[#1A1A1A] border border-white/10 rounded-xl pr-10 pl-4 py-2.5 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#C5A059] transition-all"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute left-3 top-2.5 text-xs text-white/50 hover:text-white cursor-pointer"
              >
                مسح
              </button>
            )}
          </div>

          {/* Quick Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => {
                setFilterJumuahOnly(false);
                setFilterNearbyOnly(false);
              }}
              className={`py-1.5 px-3 rounded-xl border font-bold transition-all cursor-pointer whitespace-nowrap ${
                !filterJumuahOnly && !filterNearbyOnly
                  ? 'bg-[#C5A059] text-black border-[#C5A059]'
                  : 'bg-[#1E1E1E] text-white/70 border-white/10 hover:border-white/20'
              }`}
            >
              جميع المساجد ({allSortedMosques.length})
            </button>

            <button
              onClick={() => setFilterJumuahOnly((prev) => !prev)}
              className={`py-1.5 px-3 rounded-xl border font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                filterJumuahOnly
                  ? 'bg-[#C5A059] text-black border-[#C5A059]'
                  : 'bg-[#1E1E1E] text-white/70 border-white/10 hover:border-white/20'
              }`}
            >
              <span>صلاة الجمعة 🕌</span>
            </button>

            <button
              onClick={() => setFilterNearbyOnly((prev) => !prev)}
              className={`py-1.5 px-3 rounded-xl border font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                filterNearbyOnly
                  ? 'bg-[#C5A059] text-black border-[#C5A059]'
                  : 'bg-[#1E1E1E] text-white/70 border-white/10 hover:border-white/20'
              }`}
            >
              <span>الأقرب إليك (&lt; 3.5 كم) ⚡</span>
            </button>
          </div>
        </div>
      )}

      {/* Mosques List (Closest First) */}
      {viewMode !== 'map' && (
        <div className="flex-1 flex flex-col gap-2.5 overflow-y-auto max-h-[380px] pr-1">
          {filteredMosques.length === 0 ? (
            <div className="p-8 text-center bg-[#1A1A1A] rounded-2xl border border-white/5 text-white/60 text-xs">
              <MosqueIcon className="w-8 h-8 text-white/30 mx-auto mb-2" />
              <p>لم يتم العثور على مساجد تطابق بحثك في هذا النطاق.</p>
            </div>
          ) : (
            filteredMosques.map((mosque, idx) => {
              const isSelected = selectedMosqueId === mosque.id;
              return (
                <div
                  key={mosque.id}
                  onClick={() => handleSelectMosque(mosque)}
                  className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all cursor-pointer group ${
                    isSelected
                      ? 'bg-gradient-to-r from-[#C5A059]/20 to-[#1E1E1E] border-[#C5A059] shadow-lg ring-1 ring-[#C5A059]'
                      : 'bg-[#1A1A1A] border-white/5 hover:border-[#C5A059]/50 hover:bg-[#202020]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Number Badge or Icon */}
                    <div
                      className={`w-10 h-10 rounded-2xl flex flex-col items-center justify-center shrink-0 font-bold transition-colors ${
                        isSelected
                          ? 'bg-[#C5A059] text-black'
                          : 'bg-[#242424] text-[#C5A059] group-hover:bg-[#C5A059]/20'
                      }`}
                    >
                      <MosqueIcon className="w-4 h-4" />
                      <span className="text-[9px] mt-0.5 font-mono">{idx + 1}</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm sm:text-base font-bold text-white font-['Cairo',sans-serif]">
                          {mosque.name}
                        </h4>
                        {mosque.distanceKm !== undefined && mosque.distanceKm <= 1.0 && (
                          <span className="text-[9px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.2 rounded border border-emerald-500/30">
                            قريب جداً
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 text-xs text-white/50 mt-0.5">
                        <MapPin className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                        <span>{mosque.neighborhood}</span>
                      </div>

                      <div className="flex items-center gap-2.5 mt-1.5 text-[11px] font-medium flex-wrap">
                        {mosque.distanceKm !== undefined && (
                          <span className="text-emerald-400 font-bold">
                            يبعد {mosque.distanceKm >= 1 ? `${mosque.distanceKm} كم` : `${Math.round(mosque.distanceKm * 1000)} متر`}
                          </span>
                        )}

                        {mosque.jumuah && (
                          <span className="bg-[#C5A059]/15 text-[#C5A059] px-2 py-0.5 rounded border border-[#C5A059]/30 font-bold">
                            تقام فيه الجمعة 🕌
                          </span>
                        )}

                        {mosque.features && mosque.features.slice(0, 2).map((feat, fIdx) => (
                          <span key={fIdx} className="text-white/40 text-[10px]">
                            • {feat}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Google Maps GPS Navigation button */}
                  <div className="flex items-center gap-1.5 shrink-0 mr-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openGoogleMapsDirections(mosque);
                      }}
                      className="p-2.5 rounded-xl bg-white/5 hover:bg-[#C5A059] text-white hover:text-black transition-all cursor-pointer shadow-sm active:scale-90"
                      title="الملاحة وخط السير عبر خرائط Google"
                    >
                      <Navigation className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
