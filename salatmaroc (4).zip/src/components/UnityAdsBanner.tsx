import React, { useEffect, useState } from 'react';
import { unityAdsService } from '../services/unityAdsService';
import { useLanguage } from '../context/LanguageContext';
import { Sparkles, X } from 'lucide-react';

interface UnityAdsBannerProps {
  className?: string;
  placementId?: string;
}

export const UnityAdsBanner: React.FC<UnityAdsBannerProps> = ({
  className = '',
  placementId = 'Banner_Android',
}) => {
  const { language } = useLanguage();
  const [isVisible, setIsVisible] = useState(true);
  const [status, setStatus] = useState(() => ({
    isInitialized: unityAdsService.isReady(),
    bannerActive: false,
  }));

  useEffect(() => {
    return unityAdsService.subscribe((newStatus) => {
      setStatus(newStatus);
    });
  }, []);

  if (!isVisible) return null;

  return (
    <div
      id="unity-ads-banner-container"
      data-game-id="800400769"
      data-placement-id={placementId}
      className={`w-full max-w-xl mx-auto px-3 my-2 select-none animate-in fade-in duration-300 ${className}`}
    >
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#1c1a24] via-[#24222f] to-[#1c1a24] border border-[#C5A059]/25 p-2.5 sm:p-3 shadow-md">
        {/* Subtle decorative top bar */}
        <div className="flex items-center justify-between pb-1.5 border-b border-white/5 text-[10px]">
          <div className="flex items-center gap-1.5 text-white/50">
            <span className="px-1.5 py-0.5 rounded bg-black/40 border border-white/10 text-[9px] font-mono tracking-wider text-[#C5A059] font-bold">
              {language === 'en' ? 'Unity Ads' : 'إعلان Unity'}
            </span>
            <span className="text-white/40 hidden xs:inline">
              ID: 800400769
            </span>
          </div>

          <button
            onClick={() => setIsVisible(false)}
            className="p-1 rounded-full text-white/40 hover:text-white/80 hover:bg-white/5 transition-colors cursor-pointer"
            title={language === 'en' ? 'Hide' : 'إخفاء'}
            aria-label="Hide Ad"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Ad container content */}
        <div className="pt-2 flex items-center justify-between gap-3 min-h-[48px]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#C5A059]/30 to-[#C5A059]/10 border border-[#C5A059]/40 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 text-[#C5A059]" />
            </div>
            <div className="text-right">
              <h5 className="text-xs font-bold text-white font-['Cairo',sans-serif]">
                {language === 'en' ? 'Quran Karim & Islamic Apps' : 'القرآن الكريم وتطبيقات إسلامية موثوقة'}
              </h5>
              <p className="text-[10px] text-white/50 mt-0.5 line-clamp-1">
                {language === 'en'
                  ? 'Supported by Unity Ads Network (Game ID: 800400769)'
                  : 'مدعوم بشبكة Unity Ads الإعلانية (Game ID: 800400769)'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              unityAdsService.showInterstitial();
            }}
            className="px-2.5 py-1 rounded-lg bg-[#C5A059]/20 hover:bg-[#C5A059]/30 border border-[#C5A059]/40 text-[#C5A059] text-[11px] font-bold transition-all shrink-0 active:scale-95 cursor-pointer"
          >
            {language === 'en' ? 'Learn More' : 'المزيد'}
          </button>
        </div>
      </div>
    </div>
  );
};
