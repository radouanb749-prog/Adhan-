import React, { useState } from 'react';
import { X, Search, MapPin, LocateFixed, Check } from 'lucide-react';
import { MOROCCO_CITIES } from '../../data/moroccoCities';
import { CityData } from '../../types/prayer';
import { useLanguage } from '../../context/LanguageContext';

interface CitiesModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCity: CityData;
  onSelectCity: (city: CityData) => void;
  onAutoLocate: () => void;
  isLocating: boolean;
}

export const CitiesModal: React.FC<CitiesModalProps> = ({
  isOpen,
  onClose,
  currentCity,
  onSelectCity,
  onAutoLocate,
  isLocating,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const { language, t } = useLanguage();

  if (!isOpen) return null;

  const filtered = MOROCCO_CITIES.filter(
    (c) =>
      c.nameAr.includes(searchTerm) ||
      c.nameFr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.region.includes(searchTerm)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-md bg-[#1E1E1E] border border-white/10 rounded-2xl p-5 shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-[#C5A059]" />
            <h3 className="text-xl font-bold text-white font-['Cairo',sans-serif]">
              {t.selectCityTitle}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* GPS Auto locate button */}
        <button
          onClick={onAutoLocate}
          disabled={isLocating}
          className="my-3 w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#C5A059]/15 hover:bg-[#C5A059]/25 border border-[#C5A059]/30 text-[#C5A059] text-sm font-bold transition-all active:scale-[0.98] cursor-pointer"
        >
          <LocateFixed className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
          <span>
            {isLocating ? t.locatingGps : t.currentLocationGps}
          </span>
        </button>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 absolute right-3 top-3 text-white/40" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={
              language === 'en'
                ? 'Search city (e.g. Mohammedia, Casablanca, Fes...)'
                : 'ابحث عن مدينة (مثلاً: المحمدية، الدار البيضاء، فاس...)'
            }
            className="w-full bg-[#161616] border border-white/10 rounded-xl pr-9 pl-4 py-2 text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#C5A059]"
          />
        </div>

        {/* Cities list */}
        <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 divide-y divide-white/5">
          {filtered.map((city) => {
            const isSelected = city.id === currentCity.id;
            return (
              <button
                key={city.id}
                onClick={() => {
                  onSelectCity(city);
                  onClose();
                }}
                className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                  isSelected
                    ? 'bg-[#C5A059]/15 border border-[#C5A059]/40 text-[#C5A059]'
                    : 'hover:bg-white/5 text-white/90'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold font-['Cairo',sans-serif]">
                      {language === 'en' ? (city.nameFr || city.nameAr) : city.nameAr}
                    </span>
                    <span className="text-xs text-white/40">
                      ({language === 'en' ? city.nameAr : city.nameFr})
                    </span>
                  </div>
                  <span className="text-xs text-white/50">{city.region}</span>
                </div>

                {isSelected && <Check className="w-5 h-5 text-[#C5A059]" />}
              </button>
            );
          })}
          {filtered.length === 0 && (
            <div className="text-center py-8 text-white/50 text-sm">
              {language === 'en' ? 'No matching cities found' : 'لم يتم العثور على مدن مطابقة'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
