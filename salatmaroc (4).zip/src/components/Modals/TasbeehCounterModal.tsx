import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X,
  RotateCcw,
  Volume2,
  VolumeX,
  Vibrate,
  VibrateOff,
  Sparkles,
  Minus,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Settings2,
  Trophy,
} from 'lucide-react';

interface TasbeehCounterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface DhikrPreset {
  id: string;
  arabic: string;
  meaning?: string;
  defaultTarget: number;
}

const DHIKR_PRESETS: DhikrPreset[] = [
  {
    id: 'subhanallah',
    arabic: 'سُبْحَانَ اللَّهِ',
    meaning: 'تنـزيه الله تعالى عن كل نقص',
    defaultTarget: 33,
  },
  {
    id: 'alhamdulillah',
    arabic: 'الْحَمْدُ لِلَّهِ',
    meaning: 'الثناء على الله بصفات الكمال وبنعمه',
    defaultTarget: 33,
  },
  {
    id: 'allahuakbar',
    arabic: 'اللَّهُ أَكْبَرُ',
    meaning: 'الله أعظم وأجل من كل شيء',
    defaultTarget: 33,
  },
  {
    id: 'la_ilaha_illallah',
    arabic: 'لَا إِلَهَ إِلَّا اللَّهُ',
    meaning: 'لا معبود بحق إلا الله وحده',
    defaultTarget: 100,
  },
  {
    id: 'astaghfirullah',
    arabic: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
    meaning: 'طلب المغفرة والتوبة من الذنوب',
    defaultTarget: 100,
  },
  {
    id: 'salawat',
    arabic: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
    meaning: 'الصلاة والتسليم على النبي ﷺ',
    defaultTarget: 100,
  },
  {
    id: 'hawqala',
    arabic: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    meaning: 'كنز من كنوز الجنة والبراءة من الحول والقوة',
    defaultTarget: 100,
  },
  {
    id: 'subhanallah_wa_bihamdihi',
    arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
    meaning: 'كلمتان خفيفتان على اللسان ثقيلتان في الميزان',
    defaultTarget: 100,
  },
  {
    id: 'free',
    arabic: 'ذِكْرٌ حُرّ (مفتوح)',
    meaning: 'تسبيح وذكر عام بدون تقييد',
    defaultTarget: 0,
  },
];

const STORAGE_KEY = 'morocco_prayer_tasbeeh_state_v2';

export const TasbeehCounterModal: React.FC<TasbeehCounterModalProps> = ({ isOpen, onClose }) => {
  // Load initial persistent state from localStorage
  const [count, setCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return typeof parsed.count === 'number' ? parsed.count : 0;
      }
    } catch {
      // fallback
    }
    return 0;
  });

  const [totalLifetime, setTotalLifetime] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return typeof parsed.totalLifetime === 'number' ? parsed.totalLifetime : 0;
      }
    } catch {
      // fallback
    }
    return 0;
  });

  const [selectedDhikrId, setSelectedDhikrId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.selectedDhikrId || 'subhanallah';
      }
    } catch {
      // fallback
    }
    return 'subhanallah';
  });

  const [target, setTarget] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.target === 'number') return parsed.target;
      }
    } catch {
      // fallback
    }
    return 33;
  });

  const [cycles, setCycles] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return typeof parsed.cycles === 'number' ? parsed.cycles : 0;
      }
    } catch {
      // fallback
    }
    return 0;
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.soundEnabled !== false;
      }
    } catch {
      // fallback
    }
    return true;
  });

  const [vibrateEnabled, setVibrateEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.vibrateEnabled !== false;
      }
    } catch {
      // fallback
    }
    return true;
  });

  const [isPressing, setIsPressing] = useState<boolean>(false);
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const [showCelebration, setShowCelebration] = useState<boolean>(false);

  // Audio synthesizer for crisp, low-latency mechanical tick sound
  const playClickSound = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(520, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(180, ctx.currentTime + 0.035);

      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.035);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.04);
    } catch {
      // AudioContext not allowed or not supported
    }
  }, [soundEnabled]);

  const playCelebrationSound = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();

      // Play joyful two-tone chime
      [
        { freq: 523.25, time: 0 },
        { freq: 659.25, time: 0.1 },
        { freq: 783.99, time: 0.2 },
      ].forEach(({ freq, time }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + time);
        gain.gain.setValueAtTime(0.2, ctx.currentTime + time);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + time + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + time);
        osc.stop(ctx.currentTime + time + 0.26);
      });
    } catch {
      // Ignore
    }
  }, [soundEnabled]);

  // Haptic feedback
  const triggerHaptic = useCallback(
    (pattern: number | number[] = 20) => {
      if (vibrateEnabled && typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate(pattern);
        } catch {
          // ignore
        }
      }
    },
    [vibrateEnabled]
  );

  // Sync state to localStorage whenever count/target/settings change
  useEffect(() => {
    try {
      const dataToSave = {
        count,
        totalLifetime,
        selectedDhikrId,
        target,
        cycles,
        soundEnabled,
        vibrateEnabled,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
    } catch (e) {
      console.warn('Failed to save tasbeeh count to localStorage', e);
    }
  }, [count, totalLifetime, selectedDhikrId, target, cycles, soundEnabled, vibrateEnabled]);

  // Current dhikr object
  const currentDhikr =
    DHIKR_PRESETS.find((d) => d.id === selectedDhikrId) || DHIKR_PRESETS[0];

  // Increment function (one-touch action)
  const handleIncrement = useCallback(() => {
    playClickSound();
    triggerHaptic(25);

    setIsPressing(true);
    setTimeout(() => setIsPressing(false), 120);

    setCount((prev) => {
      const nextCount = prev + 1;

      // Check if target reached
      if (target > 0 && nextCount === target) {
        triggerHaptic([40, 80, 50, 80]);
        playCelebrationSound();
        setShowCelebration(true);
        setCycles((c) => c + 1);
        setTimeout(() => setShowCelebration(false), 2000);
      }

      return nextCount;
    });

    setTotalLifetime((prev) => prev + 1);
  }, [playClickSound, triggerHaptic, playCelebrationSound, target]);

  // Decrement function (fix accidental touch)
  const handleDecrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (count <= 0) return;
    triggerHaptic(15);
    setCount((prev) => Math.max(0, prev - 1));
    setTotalLifetime((prev) => Math.max(0, prev - 1));
  };

  // Reset function
  const handleReset = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    triggerHaptic([30, 40]);
    setCount(0);
    setShowResetConfirm(false);
  };

  // Keyboard shortcut listener (Spacebar, Enter, ArrowUp)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.key === ' ' || e.code === 'Enter') {
        e.preventDefault();
        handleIncrement();
      } else if (e.code === 'KeyR') {
        handleReset();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleIncrement]);

  if (!isOpen) return null;

  // Percentage for progress ring (0 if open target)
  const progressPercent =
    target > 0 ? Math.min(100, Math.round((count % target) / target * 100)) : 0;
  const isTargetAchieved = target > 0 && count >= target;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 select-none animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-md transition-opacity cursor-pointer"
      />

      {/* Modal Dialog Card */}
      <div className="relative z-10 w-full max-w-md bg-gradient-to-b from-[#1C1B26] via-[#15141D] to-[#0E0E14] border border-[#C5A059]/30 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] overflow-hidden text-white font-['Cairo',sans-serif]">
        
        {/* Top Header Controls */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-br from-[#C5A059]/30 to-[#C5A059]/10 border border-[#C5A059]/40 text-[#C5A059] shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>عداد التسبيح</span>
                <span className="text-[11px] font-normal text-[#C5A059] bg-[#C5A059]/10 border border-[#C5A059]/20 px-2 py-0.5 rounded-full">
                  السبحة الإلكترونية
                </span>
              </h2>
              <p className="text-[11px] text-white/50">
                انقر بلمسة واحدة لزيادة العداد (يُحفظ تلقائياً)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Sound toggle */}
            <button
              onClick={() => setSoundEnabled((prev) => !prev)}
              title={soundEnabled ? 'كتم الصوت' : 'تفعيل صوت النقر'}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                soundEnabled
                  ? 'bg-[#C5A059]/15 border-[#C5A059]/40 text-[#C5A059]'
                  : 'bg-white/5 border-white/10 text-white/40'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Vibrate toggle */}
            <button
              onClick={() => setVibrateEnabled((prev) => !prev)}
              title={vibrateEnabled ? 'تعطيل الاهتزاز' : 'تفعيل الاهتزاز'}
              className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                vibrateEnabled
                  ? 'bg-[#C5A059]/15 border-[#C5A059]/40 text-[#C5A059]'
                  : 'bg-white/5 border-white/10 text-white/40'
              }`}
            >
              {vibrateEnabled ? <Vibrate className="w-4 h-4" /> : <VibrateOff className="w-4 h-4" />}
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 hover:text-white transition-colors cursor-pointer mr-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Area */}
        <div className="overflow-y-auto flex-1 py-3 space-y-4 pr-0.5">

          {/* 1. Dhikr Selection Pills (Quick Switcher) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-white/60 px-1">
              <span>اختر الذكر المبارك:</span>
              <span className="text-[10px] text-[#C5A059]">اسحب للتمرير ↔</span>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1.5 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent">
              {DHIKR_PRESETS.map((preset) => {
                const isSelected = preset.id === selectedDhikrId;
                return (
                  <button
                    key={preset.id}
                    onClick={() => {
                      setSelectedDhikrId(preset.id);
                      if (preset.defaultTarget !== undefined) {
                        setTarget(preset.defaultTarget);
                      }
                      triggerHaptic(15);
                    }}
                    className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all border cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-r from-[#C5A059] to-[#DFBA6B] text-black font-bold border-[#C5A059] shadow-md shadow-[#C5A059]/20 scale-[1.02]'
                        : 'bg-white/5 hover:bg-white/10 text-white/80 border-white/10'
                    }`}
                  >
                    {preset.arabic}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Active Dhikr Display Banner */}
          <div className="p-3 rounded-2xl bg-gradient-to-br from-[#242333] to-[#171622] border border-[#C5A059]/25 text-center shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 left-0 h-0.5 bg-gradient-to-r from-transparent via-[#C5A059] to-transparent" />
            <p className="text-lg sm:text-xl font-bold text-white font-['Amiri',serif] leading-relaxed drop-shadow-sm">
              {currentDhikr.arabic}
            </p>
            {currentDhikr.meaning && (
              <p className="text-[11px] text-[#C5A059]/90 mt-0.5 font-['Cairo',sans-serif]">
                {currentDhikr.meaning}
              </p>
            )}
          </div>

          {/* 3. The Grand Tactile Counter Button (Big interactive touch disk) */}
          <div className="flex flex-col items-center justify-center my-2">
            <div className="relative flex items-center justify-center">
              {/* Target Completed Celebration Aura */}
              {showCelebration && (
                <div className="absolute -inset-4 rounded-full bg-gradient-to-r from-[#C5A059]/40 via-amber-400/40 to-[#C5A059]/40 blur-xl animate-pulse" />
              )}

              {/* Outer SVG Circular Progress Ring */}
              <svg className="w-56 h-56 sm:w-64 sm:h-64 -rotate-90 pointer-events-none absolute">
                {/* Background Ring Track */}
                <circle
                  cx="50%"
                  cy="50%"
                  r="42%"
                  className="stroke-white/10"
                  strokeWidth="6"
                  fill="transparent"
                />
                {/* Active Progress Ring */}
                {target > 0 && (
                  <circle
                    cx="50%"
                    cy="50%"
                    r="42%"
                    className="stroke-[#C5A059] transition-all duration-200"
                    strokeWidth="7"
                    strokeDasharray="264"
                    strokeDashoffset={264 - (264 * progressPercent) / 100}
                    strokeLinecap="round"
                    fill="transparent"
                  />
                )}
              </svg>

              {/* Master Touch Surface */}
              <button
                type="button"
                onClick={handleIncrement}
                className={`relative w-48 h-48 sm:w-56 sm:h-56 rounded-full flex flex-col items-center justify-center cursor-pointer select-none transition-transform duration-100 shadow-[0_15px_35px_rgba(0,0,0,0.6)] border-4 ${
                  isPressing
                    ? 'scale-[0.94] border-[#DFBA6B] bg-gradient-to-b from-[#2A273C] via-[#1E1C2B] to-[#12111B]'
                    : isTargetAchieved
                    ? 'border-[#C5A059] bg-gradient-to-b from-[#242133] via-[#191824] to-[#0E0D14]'
                    : 'border-[#C5A059]/40 hover:border-[#C5A059] bg-gradient-to-b from-[#222030] via-[#181622] to-[#0F0E17]'
                }`}
                title="اضغط هنا أو اضغط مفتاح المسافة للتسبيح"
              >
                {/* Subtle Inner Ring Texture */}
                <div className="absolute inset-2 rounded-full border border-white/5 pointer-events-none" />
                <div className="absolute inset-4 rounded-full border border-white/5 pointer-events-none" />

                {/* Sub-label: Target or Mode */}
                <div className="text-[11px] font-medium text-white/50 tracking-wider mb-1 flex items-center gap-1">
                  {target > 0 ? (
                    <>
                      <span>الهدف: {target}</span>
                      {cycles > 0 && (
                        <span className="text-[#C5A059] bg-[#C5A059]/15 px-1.5 py-0.2 rounded-full text-[10px]">
                          دورة {cycles}
                        </span>
                      )}
                    </>
                  ) : (
                    <span>تسبيح حر بدون حد</span>
                  )}
                </div>

                {/* Main Digital Count */}
                <span className="text-6xl sm:text-7xl font-black tracking-tight text-white font-mono drop-shadow-[0_4px_16px_rgba(0,0,0,0.8)] transition-all">
                  {count.toLocaleString('en-US')}
                </span>

                {/* Touch hint */}
                <div className="mt-2 text-[10px] sm:text-xs text-[#C5A059] bg-[#C5A059]/10 px-3 py-0.5 rounded-full border border-[#C5A059]/25 font-bold animate-pulse">
                  المس للتسبيح
                </div>
              </button>
            </div>

            {/* Quick Action Buttons Under Counter */}
            <div className="flex items-center justify-center gap-3 mt-4">
              {/* Minus 1 Button */}
              <button
                type="button"
                onClick={handleDecrement}
                disabled={count === 0}
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-30 border border-white/10 text-white/70 hover:text-white transition-all text-xs flex items-center gap-1 cursor-pointer active:scale-95"
                title="إنقاص العداد بمقدار 1 في حال الخطأ"
              >
                <Minus className="w-3.5 h-3.5" />
                <span>إنقاص (-1)</span>
              </button>

              {/* Reset Button */}
              {!showResetConfirm ? (
                <button
                  type="button"
                  onClick={() => setShowResetConfirm(true)}
                  className="px-3.5 py-1.5 rounded-xl bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-300 transition-all text-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
                  title="إعادة تعيين العداد وتصفيره"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>تصفير العداد</span>
                </button>
              ) : (
                <div className="flex items-center gap-1 bg-red-950/80 border border-red-500/50 rounded-xl p-1 animate-in fade-in zoom-in-95 duration-150">
                  <span className="text-[11px] text-red-200 px-1 font-bold">تأكيد التصفير؟</span>
                  <button
                    onClick={() => handleReset()}
                    className="px-2 py-0.5 bg-red-600 hover:bg-red-700 text-white rounded text-[11px] font-bold cursor-pointer"
                  >
                    نعم
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="px-2 py-0.5 bg-white/10 hover:bg-white/20 text-white/80 rounded text-[11px] cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* 4. Target Preset Buttons (33, 99, 100, Free) */}
          <div className="p-3 rounded-2xl bg-[#1A1924] border border-white/5 space-y-2">
            <div className="flex items-center justify-between text-xs text-white/60">
              <span className="flex items-center gap-1">
                <Settings2 className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>تحديد هدف الدورة:</span>
              </span>
              <span className="text-[11px] text-[#C5A059] font-medium">
                {target === 0 ? 'مفتوح (لا نهاية)' : `${target} تسبيحة`}
              </span>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[
                { val: 33, label: '33 (دبر الصلاة)' },
                { val: 99, label: '99' },
                { val: 100, label: '100' },
                { val: 0, label: 'مفتوح ∞' },
              ].map((item) => (
                <button
                  key={item.val}
                  type="button"
                  onClick={() => {
                    setTarget(item.val);
                    triggerHaptic(15);
                  }}
                  className={`py-1.5 px-2 rounded-xl text-xs font-bold transition-all border cursor-pointer text-center ${
                    target === item.val
                      ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-sm'
                      : 'bg-white/5 hover:bg-white/10 text-white/70 border-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* 5. Statistics & Lifetime Storage */}
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="p-2.5 rounded-2xl bg-white/5 border border-white/5">
              <p className="text-[10px] text-white/50">إجمالي التسبيحات المحفوظة</p>
              <p className="text-base font-bold text-[#C5A059] font-mono mt-0.5">
                {totalLifetime.toLocaleString('en-US')}
              </p>
            </div>
            <div className="p-2.5 rounded-2xl bg-white/5 border border-white/5">
              <p className="text-[10px] text-white/50">الدورات المكتملة</p>
              <p className="text-base font-bold text-emerald-400 font-mono mt-0.5">
                {cycles.toLocaleString('en-US')}
              </p>
            </div>
          </div>

          {/* LocalStorage confirmation notice */}
          <p className="text-[10px] text-center text-white/40 leading-normal">
            ✓ يتم حفظ رقم العداد تلقائياً في المتصفح (localStorage) حتى عند إغلاق التطبيق.
          </p>
        </div>

        {/* Bottom Drawer Close / Back Button */}
        <div className="pt-2 border-t border-white/10 shrink-0">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-[#C5A059] to-[#DFBA6B] hover:brightness-110 active:scale-[0.99] text-black font-extrabold text-sm transition-all shadow-md cursor-pointer flex items-center justify-center gap-1.5"
          >
            <span>إغلاق والعودة للتطبيق</span>
          </button>
        </div>

      </div>
    </div>
  );
};
