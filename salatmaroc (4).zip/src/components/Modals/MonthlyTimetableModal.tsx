import React from 'react';
import { X, CalendarDays, Download, MapPin } from 'lucide-react';
import { CityData } from '../../types/prayer';
import { calculatePrayerTimes } from '../../services/prayerCalculation';

interface MonthlyTimetableModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCity: CityData;
  timezoneMode: 'gmt' | 'gmt+1';
}

export const MonthlyTimetableModal: React.FC<MonthlyTimetableModalProps> = ({
  isOpen,
  onClose,
  currentCity,
  timezoneMode,
}) => {
  if (!isOpen) return null;

  // Generate days of current month dynamically
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthIndex = now.getMonth();
  const currentMonthNameAr = new Intl.DateTimeFormat('ar-MA', { month: 'long' }).format(now);
  const daysInMonth = new Date(currentYear, currentMonthIndex + 1, 0).getDate();
  const todayDayNumber = now.getDate();

  const monthlyData = Array.from({ length: daysInMonth }, (_, i) => {
    const d = new Date(currentYear, currentMonthIndex, i + 1);
    const prayers = calculatePrayerTimes(d, currentCity, timezoneMode);
    const isToday = i + 1 === todayDayNumber;
    return {
      day: i + 1,
      isToday,
      fajr: prayers.find((p) => p.id === 'fajr')?.time ?? '--:--',
      sunrise: prayers.find((p) => p.id === 'sunrise')?.time ?? '--:--',
      dhuhr: prayers.find((p) => p.id === 'dhuhr')?.time ?? '--:--',
      asr: prayers.find((p) => p.id === 'asr')?.time ?? '--:--',
      maghrib: prayers.find((p) => p.id === 'maghrib')?.time ?? '--:--',
      isha: prayers.find((p) => p.id === 'isha')?.time ?? '--:--',
    };
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-2xl bg-[#1E1E1E] border border-white/10 rounded-2xl p-4 sm:p-6 shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2">
              <CalendarDays className="w-5 h-5 text-[#C5A059]" />
              <h3 className="text-lg sm:text-xl font-bold text-white font-['Cairo',sans-serif]">
                الحصة الشهرية لمواقيت الصلاة
              </h3>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#C5A059] mt-0.5">
              <MapPin className="w-3.5 h-3.5" />
              <span>
                {currentCity.nameAr} - {currentMonthNameAr} {currentYear} ({timezoneMode === 'gmt' ? 'توقيت غرينتش GMT' : 'التوقيت الصيفي GMT+1'})
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Timetable Table */}
        <div className="flex-1 overflow-x-auto overflow-y-auto my-3 pr-1">
          <table className="w-full text-center border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-[#141414] text-[#C5A059] border-b border-white/10 font-bold">
                <th className="py-2.5 px-2">اليوم</th>
                <th className="py-2.5 px-2">الفجر</th>
                <th className="py-2.5 px-2">الشروق</th>
                <th className="py-2.5 px-2">الظهر</th>
                <th className="py-2.5 px-2">العصر</th>
                <th className="py-2.5 px-2">المغرب</th>
                <th className="py-2.5 px-2">العشاء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono">
              {monthlyData.map((row) => (
                <tr
                  key={row.day}
                  className={`transition-colors ${
                    row.isToday
                      ? 'bg-[#C5A059]/20 text-[#C5A059] font-bold border-y border-[#C5A059]/40'
                      : 'hover:bg-white/[0.02] text-white/90'
                  }`}
                >
                  <td className="py-2 px-2 font-sans font-bold">
                    {row.day}
                    {row.isToday && (
                      <span className="block text-[10px] text-[#C5A059]">اليوم</span>
                    )}
                  </td>
                  <td className="py-2 px-2">{row.fajr}</td>
                  <td className="py-2 px-2 text-white/60">{row.sunrise}</td>
                  <td className="py-2 px-2">{row.dhuhr}</td>
                  <td className="py-2 px-2">{row.asr}</td>
                  <td className="py-2 px-2">{row.maghrib}</td>
                  <td className="py-2 px-2">{row.isha}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer info */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-white/50">
          <span>حسب توقيت وزارة الأوقاف والشؤون الإسلامية للمملكة المغربية</span>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 text-[#C5A059] hover:underline"
          >
            <Download className="w-3.5 h-3.5" />
            <span>طباعة / حفظ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
