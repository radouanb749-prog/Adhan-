import React, { useState, useMemo } from 'react';
import { X, Search, BookOpen, Copy, Check, Share2, Sparkles, RotateCcw } from 'lucide-react';
import { HISN_AL_MUSLIM_DATA, HISN_CATEGORIES, HisnDhikrItem } from '../../data/hisnAlMuslimData';
import { audioAdhanService } from '../../services/audioAdhan';
import { useTheme } from '../../context/ThemeContext';

interface HisnAlMuslimModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HisnAlMuslimModal: React.FC<HisnAlMuslimModalProps> = ({ isOpen, onClose }) => {
  const { isDark } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  // Filtered adhkar based on category and search query
  const filteredAdhkar = useMemo(() => {
    return HISN_AL_MUSLIM_DATA.filter((item) => {
      const matchesCategory =
        selectedCategory === 'all' || item.category === selectedCategory;

      if (!matchesCategory) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      const cleanArabic = item.arabic.replace(/[\u064B-\u065F\u0670]/g, '').toLowerCase();
      const cleanTitle = item.title.replace(/[\u064B-\u065F\u0670]/g, '').toLowerCase();
      const cleanVirtue = (item.virtue || '').replace(/[\u064B-\u065F\u0670]/g, '').toLowerCase();

      return (
        cleanTitle.includes(q) ||
        cleanArabic.includes(q) ||
        cleanVirtue.includes(q) ||
        item.categoryAr.includes(q)
      );
    });
  }, [selectedCategory, searchQuery]);

  const handleIncrement = (item: HisnDhikrItem) => {
    const current = counts[item.id] || 0;
    if (current < item.repeat) {
      setCounts((prev) => ({
        ...prev,
        [item.id]: current + 1,
      }));
      audioAdhanService.playClickSound();
    }
  };

  const handleResetCount = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCounts((prev) => ({
      ...prev,
      [id]: 0,
    }));
  };

  const handleCopy = (item: HisnDhikrItem) => {
    const text = `${item.title}\n\n${item.arabic}\n\n[${item.reference}]`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = async (item: HisnDhikrItem) => {
    const text = `${item.title}\n\n${item.arabic}\n\n[${item.reference}]`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text,
        });
      } catch {
        // user cancelled or share failed
      }
    } else {
      handleCopy(item);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm select-none animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-xl rounded-3xl border shadow-2xl max-h-[92vh] flex flex-col overflow-hidden transition-colors ${
          isDark
            ? 'bg-[#16151E] border-white/10 text-white'
            : 'bg-white border-[#C5A059]/30 text-gray-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between p-4 sm:p-5 border-b ${
            isDark ? 'border-white/10 bg-[#16151E]' : 'border-[#C5A059]/20 bg-[#FAF8F5]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-[#C5A059] text-black shadow-md">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-bold font-['Cairo',sans-serif] text-[#C5A059]">
                  حصن المسلم
                </h3>
                <span className="text-[10px] bg-[#C5A059]/20 text-[#C5A059] px-2 py-0.5 rounded-full font-bold">
                  أذكار وأدعية
                </span>
              </div>
              <p className={`text-xs ${isDark ? 'text-white/60' : 'text-gray-500'}`}>
                الأذكار الصحيحة مصنفة حسب المناسبات مع البحث الذكي
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-2 rounded-full transition-colors cursor-pointer ${
              isDark ? 'hover:bg-white/10 text-white/80' : 'hover:bg-black/5 text-gray-600'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Smart Search Bar */}
        <div className="p-3 sm:p-4 pb-2">
          <div
            className={`relative flex items-center rounded-2xl border px-3 py-2.5 transition-all ${
              isDark
                ? 'bg-[#1C1A24] border-white/10 focus-within:border-[#C5A059]'
                : 'bg-[#F5F2EB] border-[#C5A059]/30 focus-within:border-[#C5A059]'
            }`}
          >
            <Search className="w-4 h-4 text-[#C5A059] shrink-0 ml-2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في أذكار حصن المسلم (مثلاً: السفر، البيت، الشفاء، النوم...)"
              className="w-full bg-transparent text-sm focus:outline-none placeholder:text-white/40"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-[#C5A059] hover:underline shrink-0"
              >
                مسح
              </button>
            )}
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="px-3 sm:px-4 pb-3 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0">
          {HISN_CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#C5A059] text-black shadow-md'
                    : isDark
                    ? 'bg-white/5 text-white/70 hover:bg-white/10'
                    : 'bg-black/5 text-gray-600 hover:bg-black/10'
                }`}
              >
                {cat.nameAr}
              </button>
            );
          })}
        </div>

        {/* Adhkar List */}
        <div className="flex-1 overflow-y-auto px-3 sm:px-4 pb-4 space-y-3">
          {filteredAdhkar.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="w-10 h-10 text-[#C5A059]/40 mx-auto mb-2" />
              <p className="text-sm font-bold text-[#C5A059]">لا توجد أذكار مطابقة لبحثك</p>
              <p className={`text-xs mt-1 ${isDark ? 'text-white/50' : 'text-gray-500'}`}>
                جرب البحث بكلمات أخرى أو اختر تصنيفاً مختلفاً
              </p>
            </div>
          ) : (
            filteredAdhkar.map((item) => {
              const currentCount = counts[item.id] || 0;
              const isCompleted = currentCount >= item.repeat;

              return (
                <div
                  key={item.id}
                  onClick={() => handleIncrement(item)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden group select-none ${
                    isCompleted
                      ? 'border-emerald-500/50 bg-emerald-500/10'
                      : isDark
                      ? 'bg-[#1C1B26] border-white/5 hover:border-[#C5A059]/40'
                      : 'bg-[#FAF8F5] border-[#C5A059]/25 hover:border-[#C5A059]/60 shadow-sm'
                  }`}
                >
                  {/* Top Bar: Title & Category Badge */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-bold text-[#C5A059] font-['Cairo',sans-serif]">
                      {item.title}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        isDark ? 'bg-white/5 text-white/60' : 'bg-black/5 text-gray-500'
                      }`}
                    >
                      {item.categoryAr}
                    </span>
                  </div>

                  {/* Main Arabic Text */}
                  <p className="text-base sm:text-lg leading-relaxed font-['Amiri',serif] font-medium text-justify [text-align-last:right] mb-3">
                    {item.arabic}
                  </p>

                  {/* Virtue if present */}
                  {item.virtue && (
                    <div className="mb-2.5 p-2 rounded-xl bg-[#C5A059]/10 border border-[#C5A059]/20 text-xs text-[#C5A059] font-['Cairo',sans-serif]">
                      <span className="font-bold">الفضل: </span>
                      {item.virtue}
                    </div>
                  )}

                  {/* Bottom Action Row: Reference, Actions, and Tap Counter */}
                  <div
                    className={`pt-2.5 border-t flex items-center justify-between text-xs ${
                      isDark ? 'border-white/5 text-white/50' : 'border-black/5 text-gray-500'
                    }`}
                  >
                    <span className="text-[11px] truncate max-w-[180px] sm:max-w-[240px]">
                      {item.reference}
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCopy(item);
                        }}
                        className={`p-1.5 rounded-lg transition-colors ${
                          isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'
                        }`}
                        title="نسخ الذكر"
                      >
                        {copiedId === item.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Copy className="w-3.5 h-3.5 text-[#C5A059]" />
                        )}
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleShare(item);
                        }}
                        className={`p-1.5 rounded-lg transition-colors ${
                          isDark ? 'hover:bg-white/10' : 'hover:bg-black/5'
                        }`}
                        title="مشاركة الذكر"
                      >
                        <Share2 className="w-3.5 h-3.5 text-[#C5A059]" />
                      </button>

                      {/* Repetition Counter Badge */}
                      <div className="flex items-center gap-1">
                        <span
                          className={`px-2.5 py-1 rounded-full font-mono text-xs font-bold flex items-center gap-1 ${
                            isCompleted
                              ? 'bg-emerald-500 text-black'
                              : 'bg-[#C5A059] text-black shadow-sm'
                          }`}
                        >
                          {isCompleted ? (
                            <>
                              <Check className="w-3 h-3 stroke-[3]" />
                              <span>تم ({item.repeat})</span>
                            </>
                          ) : (
                            <span>
                              {currentCount} / {item.repeat}
                            </span>
                          )}
                        </span>

                        {currentCount > 0 && !isCompleted && (
                          <button
                            onClick={(e) => handleResetCount(item.id, e)}
                            className="p-1 rounded-full text-white/40 hover:text-white"
                            title="إعادة ضبط العداد"
                          >
                            <RotateCcw className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
