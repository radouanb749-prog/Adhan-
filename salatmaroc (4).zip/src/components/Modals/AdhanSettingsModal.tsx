import React, { useState, useEffect } from 'react';
import {
  ChevronRight,
  ChevronLeft,
  Volume2,
  Info,
  Check,
  Play,
  Square,
  Smartphone,
  Sliders,
  Sparkles,
  Activity,
} from 'lucide-react';
import { MUEZZINS_LIST, MuezzinItem } from '../../data/muezzinsData';
import { audioAdhanService } from '../../services/audioAdhan';
import { adhanLogService, AdhanLogSummary } from '../../services/adhanLogService';
import { AdhanLogModal } from './AdhanLogModal';
import { SettingsState } from '../../types/prayer';
import { useShakeDetector } from '../../hooks/useShakeDetector';
import { useLanguage } from '../../context/LanguageContext';
import { nativeAlarmBridge } from '../../services/nativeAlarmBridge';

interface AdhanSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  assignedMuezzins: Record<string, string>;
  onUpdateAssignedMuezzin: (prayerId: string, muezzinId: string) => void;
  onOpenMuezzinPickerForPrayer: (prayerId: string, prayerNameAr: string) => void;
  settings?: SettingsState;
  onUpdateSettings?: (newSettings: Partial<SettingsState>) => void;
}

export const AdhanSettingsModal: React.FC<AdhanSettingsModalProps> = ({
  isOpen,
  onClose,
  assignedMuezzins,
  onUpdateAssignedMuezzin,
  onOpenMuezzinPickerForPrayer,
  settings,
  onUpdateSettings,
}) => {
  // State for toggles matching the screenshot
  const isSilentModeEnabled = !!settings?.is_silent_mode_enabled;
  const [silentNotification, setSilentNotification] = useState(false);
  const [fridayAdhan, setFridayAdhan] = useState(false);
  const [showStopShortcuts, setShowStopShortcuts] = useState(false);
  const [showNotificationMethodDialog, setShowNotificationMethodDialog] = useState(false);

  // Live shake tester state
  const [isTestingShake, setIsTestingShake] = useState(false);
  const [testShakeSuccess, setTestShakeSuccess] = useState<string | null>(null);

  // Sensitivity value: lower = more sensitive (light shake), higher = harder shake
  const shakeSensitivity = settings?.shakeSensitivity ?? 5.5;
  const isShakeEnabled = settings?.shakeToStopAdhan !== false;

  // Real-time shake detector inside the modal to test the slider setting
  useShakeDetector({
    enabled: isOpen && isTestingShake,
    threshold: shakeSensitivity,
    onShake: () => {
      audioAdhanService.stopAll();
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([100, 50, 100]);
        } catch {
          // ignore
        }
      }
      setTestShakeSuccess(`✓ تم استشعار الهزة بنجاح وفق الحساسية المحددة (${shakeSensitivity.toFixed(1)} m/s²)! 📳`);
      setIsTestingShake(false);
      setTimeout(() => {
        setTestShakeSuccess(null);
      }, 4000);
    },
  });

  const handleStartShakeTest = () => {
    setTestShakeSuccess(null);
    setIsTestingShake(true);
    audioAdhanService.playAdhanChime('اختبار الهزة', 'قم بهز هاتفك الآن لاختبار الحساسية');
  };

  const handleCancelShakeTest = () => {
    setIsTestingShake(false);
    audioAdhanService.stopAll();
  };

  // Helper description for sensitivity level
  const getSensitivityLabel = (val: number) => {
    if (val <= 4.0) {
      return {
        title: 'حساسية عالية جداً (هزة خفيفة)',
        desc: 'يكفي تحريك أو هز الهاتف حركة خفيفة لإيقاف الأذان فوراً.',
        badgeColor: 'text-amber-300 bg-amber-500/15 border-amber-500/30',
      };
    }
    if (val <= 6.5) {
      return {
        title: 'حساسية متوازنة ومعتدلة (الموصى بها ★)',
        desc: 'مستوى مثالي يتطلب هزة واضحة وطبيعية ويمنع الإيقاف الخاطئ عند المشي.',
        badgeColor: 'text-emerald-300 bg-emerald-500/15 border-emerald-500/30',
      };
    }
    if (val <= 9.0) {
      return {
        title: 'حساسية متوسطة (هزة حازمة)',
        desc: 'يتطلب هزة قوية نسبياً للتأكد من رغبتك بإيقاف الأذان.',
        badgeColor: 'text-cyan-300 bg-cyan-500/15 border-cyan-500/30',
      };
    }
    return {
      title: 'حساسية منخفضة (هزة قوية جداً)',
      desc: 'يتطلب رج الهاتف بقوة لتفادي إيقافه العرضي أثناء النوم أو التقاط الهاتف.',
      badgeColor: 'text-purple-300 bg-purple-500/15 border-purple-500/30',
    };
  };

  // Prayer adhan enabled toggles synchronized with persistent settings
  const prayerEnabled = settings?.prayerAdhanEnabled || {
    fajr: true,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  };

  const [isPlayingTestAdhan, setIsPlayingTestAdhan] = useState(false);
  const [isAdhanLogModalOpen, setIsAdhanLogModalOpen] = useState(false);
  const [adhanSummary, setAdhanSummary] = useState<AdhanLogSummary>(() =>
    adhanLogService.getSummary()
  );

  useEffect(() => {
    return adhanLogService.subscribe(() => {
      setAdhanSummary(adhanLogService.getSummary());
    });
  }, []);

  useEffect(() => {
    return audioAdhanService.subscribe((state) => {
      setIsPlayingTestAdhan(state.isPlaying && state.activeId === 'test_adhan_settings');
    });
  }, []);

  if (!isOpen) return null;

  const togglePrayer = (prayerId: string) => {
    const updated = {
      ...prayerEnabled,
      [prayerId]: !prayerEnabled[prayerId],
    };
    onUpdateSettings?.({ prayerAdhanEnabled: updated });
    audioAdhanService.playClickSound();
  };

  const handleToggleTestAdhan = () => {
    if (isPlayingTestAdhan) {
      audioAdhanService.stopAll();
    } else {
      audioAdhanService.playRealAdhan(
        '/audio/adhan-morocco.mp3',
        'test_adhan_settings',
        'الأذان المغربي الأصيل (تجربة الصوت)',
        'مؤذنو مساجد المملكة المغربية'
      );
    }
  };

  const getMuezzinName = (prayerId: string): string => {
    const id = assignedMuezzins[prayerId];
    if (id) {
      const found = MUEZZINS_LIST.find((m) => m.id === id);
      if (found) return found.muezzinName || found.nameAr;
    }
    if (prayerId === 'fajr') return 'ناصر القطامي (فجر)';
    if (prayerId === 'dhuhr') return 'حمد دغريري';
    if (prayerId === 'asr') return 'الأذان المغربي الأصيل';
    if (prayerId === 'maghrib') return 'الأذان المغربي الأصيل';
    if (prayerId === 'isha') return 'المسجد النبوي الشريف';
    return 'الأذان المعتمد';
  };

  const { language, t } = useLanguage();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md select-none">
      {/* Full screen modal matching mobile screenshot style */}
      <div className="w-full max-w-md h-full sm:h-[92vh] sm:max-h-[850px] bg-[#14131B] sm:border sm:border-white/10 sm:rounded-3xl flex flex-col overflow-hidden text-white shadow-2xl">
        {/* Top Header matching screenshot */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-white/5 bg-[#14131B]">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1 rounded-full text-[#C5A059] hover:bg-white/5 transition-colors cursor-pointer"
              title={t.back}
              aria-label={t.back}
            >
              {language === 'ar' ? (
                <ChevronRight className="w-7 h-7 stroke-[2.5]" />
              ) : (
                <ChevronLeft className="w-7 h-7 stroke-[2.5]" />
              )}
            </button>
            <h2 className="text-xl font-bold font-['Cairo',sans-serif] text-white">
              {t.adhanSettingsTitle}
            </h2>
          </div>

          {/* Quick Adhan Audio Test Button */}
          <button
            onClick={handleToggleTestAdhan}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer ${
              isPlayingTestAdhan
                ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
                : 'bg-[#C5A059]/20 text-[#C5A059] hover:bg-[#C5A059]/30 border border-[#C5A059]/40'
            }`}
            title="تجربة فورية لسماع صوت الأذان"
          >
            {isPlayingTestAdhan ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>{t.stopAdhanBtn}</span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5" />
                <span>{t.audioTest}</span>
              </>
            )}
          </button>
        </div>

        {/* Scrollable Settings Body */}
        <div className="flex-1 overflow-y-auto divide-y divide-white/[0.07] px-4">
          {/* Top Banner: سجل نشاط الأذان (Adhan Log) */}
          <div className="py-3">
            <button
              onClick={() => setIsAdhanLogModalOpen(true)}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-l from-emerald-500/15 via-[#C5A059]/10 to-[#1C1A24] border border-emerald-500/30 hover:border-[#C5A059] transition-all text-right group cursor-pointer shadow-sm active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 group-hover:scale-110 transition-transform">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-[#C5A059] transition-colors font-['Cairo',sans-serif] flex items-center gap-2">
                    <span>{t.adhanLog}</span>
                    <span
                      className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded border ${
                        adhanSummary.error > 0
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      }`}
                    >
                      {adhanSummary.error > 0
                        ? `${adhanSummary.error} ${t.errorsRecorded}`
                        : t.healthyAndActive}
                    </span>
                  </h3>
                  <p className="text-[11px] text-white/50 mt-0.5">
                    {t.adhanLogDesc}
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-5 h-5 text-[#C5A059] group-hover:-translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Top Option 1: التنبيه في الوضع الصامت */}
          <div className="py-4 flex items-center justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-base font-medium text-white font-['Cairo',sans-serif]">
                {t.silentModeAlert}
              </h3>
              <p className="text-xs text-white/50 mt-0.5">
                {t.silentModeAlertDesc}
              </p>
            </div>
            {/* iOS/Android style toggle switch */}
            <button
              onClick={() =>
                onUpdateSettings?.({ is_silent_mode_enabled: !isSilentModeEnabled })
              }
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
                isSilentModeEnabled ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  isSilentModeEnabled ? 'right-6 bg-black' : 'right-0.5'
                }`}
              />
            </button>
          </div>

          {/* Top Option: طريقة التنبيه بموعد الأذان (مطابقة لتطبيق صلاتك - نافذة عند قفل الهاتف، وتنبيه إذا كان مفتوحا) */}
          <div className="py-4">
            <button
              onClick={() => setShowNotificationMethodDialog(true)}
              className="w-full flex items-center justify-between text-right cursor-pointer group"
            >
              <div>
                <h3 className="text-base font-medium text-white group-hover:text-[#C5A059] transition-colors font-['Cairo',sans-serif]">
                  طريقة التنبيه بموعد الأذان
                </h3>
                <p className="text-xs text-[#C5A059] mt-0.5">
                  {(settings?.adhanAlertMethod || nativeAlarmBridge.getAdhanAlertMethod()) === 'window'
                    ? 'نافذة'
                    : (settings?.adhanAlertMethod || nativeAlarmBridge.getAdhanAlertMethod()) === 'notification'
                    ? 'تنبيه'
                    : 'نافذة عند قفل الهاتف، وتنبيه إذا كان مفتوحا'}
                </p>
              </div>
              <ChevronLeft className="w-5 h-5 text-white/40 group-hover:text-[#C5A059] group-hover:-translate-x-1 transition-all" />
            </button>
          </div>

          {/* Top Option 2: اختصارات إيقاف الأذان */}
          <div className="py-4">
            <button
              onClick={() => setShowStopShortcuts((prev) => !prev)}
              className="w-full flex items-center justify-between cursor-pointer group"
            >
              <h3 className="text-base font-medium text-white group-hover:text-[#C5A059] transition-colors font-['Cairo',sans-serif]">
                {t.stopShortcuts}
              </h3>
              <ChevronLeft
                className={`w-5 h-5 text-white/40 transition-transform ${
                  showStopShortcuts ? '-rotate-90 text-[#C5A059]' : ''
                }`}
              />
            </button>

            {showStopShortcuts && (
              <div className="mt-2.5 p-3 rounded-xl bg-white/[0.03] border border-white/5 text-xs text-white/70 space-y-1.5 animate-in fade-in duration-200">
                <p>{language === 'en' ? '• Press volume buttons to immediately silence Adhan.' : '• الضغط على زر خفض الصوت لكتم صوت الأذان فوراً.'}</p>
                <p>{language === 'en' ? '• Tap the floating player at the bottom to stop audio.' : '• النقر على المشغل العائم في أسفل الشاشة لإيقاف الصوت.'}</p>
                <p>{language === 'en' ? '• Place phone screen face-down on table to activate automatic mute.' : '• قلب الهاتف على شاشته لتفعيل الكتم التلقائي.'}</p>
              </div>
            )}
          </div>

          {/* Top Option 3: تنبيه صامت */}
          <div className="py-4 flex items-center justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-base font-medium text-white font-['Cairo',sans-serif]">
                {t.silentNotification}
              </h3>
              <p className="text-xs text-white/50 mt-0.5">
                {t.silentNotificationDesc}
              </p>
            </div>
            <button
              onClick={() => setSilentNotification((prev) => !prev)}
              className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
                silentNotification ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
              }`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                  silentNotification ? 'right-6 bg-black' : 'right-0.5'
                }`}
              />
            </button>
          </div>

          {/* Section: إيقاف الأذان بهز الهاتف ومستوى الحساسية */}
          <div className="py-4 space-y-3">
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-[#C5A059]" />
                  <h3 className="text-base font-medium text-white font-['Cairo',sans-serif]">
                    {t.shakeTitle}
                  </h3>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      isShakeEnabled
                        ? 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30'
                        : 'text-white/40 bg-white/5 border-white/10'
                    }`}
                  >
                    {isShakeEnabled ? t.shakeActive : t.shakeDisabled}
                  </span>
                </div>
                <p className="text-xs text-white/50 mt-1">
                  {t.shakeDesc}
                </p>
              </div>

              {/* Toggle switch */}
              <button
                onClick={() => onUpdateSettings?.({ shakeToStopAdhan: !isShakeEnabled })}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
                  isShakeEnabled ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
                }`}
                title={isShakeEnabled ? t.shakeDisabled : t.shakeActive}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    isShakeEnabled ? 'right-6 bg-black' : 'right-0.5'
                  }`}
                />
              </button>
            </div>

            {/* Slider Controls when Shake is Enabled */}
            {isShakeEnabled && (
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-[#C5A059]/30 space-y-3 animate-in fade-in duration-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white/90 flex items-center gap-1.5 font-['Cairo',sans-serif]">
                    <Sliders className="w-3.5 h-3.5 text-[#C5A059]" />
                    <span>{t.shakeSensitivity}</span>
                  </span>
                  <span className="text-xs font-extrabold text-[#C5A059] bg-[#C5A059]/15 px-2.5 py-0.5 rounded-full border border-[#C5A059]/30 font-mono">
                    {shakeSensitivity.toFixed(1)} m/s²
                  </span>
                </div>

                {/* Range Slider */}
                <div className="space-y-1.5">
                  <input
                    type="range"
                    min="3.0"
                    max="11.0"
                    step="0.5"
                    value={shakeSensitivity}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      onUpdateSettings?.({ shakeSensitivity: val });
                    }}
                    className="w-full h-2 bg-[#2E2C38] rounded-lg appearance-none cursor-pointer accent-[#C5A059]"
                  />
                  <div className="flex justify-between text-[11px] text-white/40 font-bold px-0.5">
                    <span>{t.shakeLight}</span>
                    <span>{t.shakeBalanced}</span>
                    <span>{t.shakeFirm}</span>
                  </div>
                </div>

                {/* Level badge description */}
                {(() => {
                  const info = getSensitivityLabel(shakeSensitivity);
                  return (
                    <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${info.badgeColor}`}>
                          {language === 'en'
                            ? shakeSensitivity <= 4.0
                              ? 'High sensitivity (Light shake)'
                              : shakeSensitivity <= 6.5
                              ? 'Balanced sensitivity (Recommended ★)'
                              : 'Firm sensitivity (Safe)'
                            : info.title}
                        </span>
                      </div>
                      <p className="text-[11px] text-white/70 leading-relaxed">
                        {language === 'en'
                          ? shakeSensitivity <= 4.0
                            ? 'A very gentle motion immediately silences the Adhan.'
                            : shakeSensitivity <= 6.5
                            ? 'Natural moderate shake required, avoids false triggers while walking.'
                            : 'Firm intentional motion required to silence audio.'
                          : info.desc}
                      </p>
                    </div>
                  );
                })()}

                {/* Quick Presets */}
                <div className="grid grid-cols-3 gap-1.5 pt-0.5">
                  <button
                    onClick={() => onUpdateSettings?.({ shakeSensitivity: 3.5 })}
                    className={`py-1.5 px-2 rounded-xl border text-[11px] font-bold transition-all cursor-pointer ${
                      shakeSensitivity === 3.5
                        ? 'bg-[#C5A059] text-black border-[#C5A059]'
                        : 'bg-white/5 text-white/70 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {t.shakeLight} (3.5)
                  </button>
                  <button
                    onClick={() => onUpdateSettings?.({ shakeSensitivity: 5.5 })}
                    className={`py-1.5 px-2 rounded-xl border text-[11px] font-bold transition-all cursor-pointer ${
                      shakeSensitivity === 5.5
                        ? 'bg-[#C5A059] text-black border-[#C5A059]'
                        : 'bg-white/5 text-white/70 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {t.shakeBalanced} (5.5)
                  </button>
                  <button
                    onClick={() => onUpdateSettings?.({ shakeSensitivity: 8.5 })}
                    className={`py-1.5 px-2 rounded-xl border text-[11px] font-bold transition-all cursor-pointer ${
                      shakeSensitivity === 8.5
                        ? 'bg-[#C5A059] text-black border-[#C5A059]'
                        : 'bg-white/5 text-white/70 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {t.shakeFirm} (8.5)
                  </button>
                </div>

                {/* Interactive Shake Test in Modal */}
                <div className="pt-1">
                  {!isTestingShake ? (
                    <button
                      onClick={handleStartShakeTest}
                      className="w-full py-2 px-3 rounded-xl bg-[#C5A059]/20 hover:bg-[#C5A059]/30 border border-[#C5A059]/40 text-[#C5A059] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Smartphone className="w-3.5 h-3.5 animate-pulse" />
                      <span>{t.shakeTestBtn}</span>
                    </button>
                  ) : (
                    <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs text-center space-y-2 animate-pulse">
                      <div className="flex items-center justify-center gap-1.5 font-bold">
                        <Smartphone className="w-4 h-4 animate-bounce" />
                        <span>{t.shakeTestingActive}</span>
                      </div>
                      <button
                        onClick={handleCancelShakeTest}
                        className="text-[11px] text-white/70 hover:text-white underline cursor-pointer"
                      >
                        {t.cancel}
                      </button>
                    </div>
                  )}

                  {testShakeSuccess && (
                    <div className="mt-2 p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center animate-in fade-in duration-200">
                      {testShakeSuccess}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Section: صلاة الفجر */}
          <div className="py-4 space-y-3.5">
            <span className="text-xs font-bold text-[#C5A059] block">
              {language === 'en' ? 'Fajr Prayer' : 'صلاة الفجر'}
            </span>

            {/* تشغيل الأذان */}
            <div className="flex items-center justify-between">
              <span className="text-base text-white/95">
                {language === 'en' ? 'Play Adhan' : 'تشغيل الأذان'}
              </span>
              <button
                onClick={() => togglePrayer('fajr')}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  prayerEnabled.fajr ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full transition-transform ${
                    prayerEnabled.fajr ? 'right-6 bg-black' : 'right-0.5 bg-white'
                  }`}
                />
              </button>
            </div>

            {/* صوت أذان الفجر */}
            <button
              onClick={() => onOpenMuezzinPickerForPrayer('fajr', 'الفجر')}
              className="w-full flex items-center justify-between py-1 group cursor-pointer"
            >
              <div>
                <span className="text-base text-white/95 group-hover:text-[#C5A059] transition-colors block">
                  {language === 'en' ? 'Fajr Adhan Sound' : 'صوت أذان الفجر'}
                </span>
                <span className="text-xs text-[#C5A059] block mt-0.5">
                  {getMuezzinName('fajr')}
                </span>
              </div>
              <ChevronLeft className="w-5 h-5 text-white/30 group-hover:text-[#C5A059] transition-colors" />
            </button>
          </div>

          {/* Section: صلاة الظهر */}
          <div className="py-4 space-y-3.5">
            <span className="text-xs font-bold text-[#C5A059] block">
              {language === 'en' ? 'Dhuhr Prayer' : 'صلاة الظهر'}
            </span>

            {/* تشغيل الأذان */}
            <div className="flex items-center justify-between">
              <span className="text-base text-white/95">
                {language === 'en' ? 'Play Adhan' : 'تشغيل الأذان'}
              </span>
              <button
                onClick={() => togglePrayer('dhuhr')}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  prayerEnabled.dhuhr ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full transition-transform ${
                    prayerEnabled.dhuhr ? 'right-6 bg-black' : 'right-0.5 bg-white'
                  }`}
                />
              </button>
            </div>

            {/* صوت أذان الظهر */}
            <button
              onClick={() => onOpenMuezzinPickerForPrayer('dhuhr', 'الظهر')}
              className="w-full flex items-center justify-between py-1 group cursor-pointer"
            >
              <div>
                <span className="text-base text-white/95 group-hover:text-[#C5A059] transition-colors block">
                  {language === 'en' ? 'Dhuhr Adhan Sound' : 'صوت أذان الظهر'}
                </span>
                <span className="text-xs text-[#C5A059] block mt-0.5">
                  {getMuezzinName('dhuhr')}
                </span>
              </div>
              <ChevronLeft className="w-5 h-5 text-white/30 group-hover:text-[#C5A059] transition-colors" />
            </button>

            {/* أذان لصلاة الجمعة */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-base text-white/95">{t.fridayAdhan}</span>
              <button
                onClick={() => setFridayAdhan((prev) => !prev)}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  fridayAdhan ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full transition-transform ${
                    fridayAdhan ? 'right-6 bg-black' : 'right-0.5 bg-white'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Section: صلاة العصر */}
          <div className="py-4 space-y-3.5">
            <span className="text-xs font-bold text-[#C5A059] block">
              {language === 'en' ? 'Asr Prayer' : 'صلاة العصر'}
            </span>

            {/* تشغيل الأذان */}
            <div className="flex items-center justify-between">
              <span className="text-base text-white/95">
                {language === 'en' ? 'Play Adhan' : 'تشغيل الأذان'}
              </span>
              <button
                onClick={() => togglePrayer('asr')}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  prayerEnabled.asr ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full transition-transform ${
                    prayerEnabled.asr ? 'right-6 bg-black' : 'right-0.5 bg-white'
                  }`}
                />
              </button>
            </div>

            {/* صوت أذان العصر */}
            <button
              onClick={() => onOpenMuezzinPickerForPrayer('asr', 'العصر')}
              className="w-full flex items-center justify-between py-1 group cursor-pointer"
            >
              <div>
                <span className="text-base text-white/95 group-hover:text-[#C5A059] transition-colors block">
                  {language === 'en' ? 'Asr Adhan Sound' : 'صوت أذان العصر'}
                </span>
                <span className="text-xs text-[#C5A059] block mt-0.5">
                  {getMuezzinName('asr')}
                </span>
              </div>
              <ChevronLeft className="w-5 h-5 text-white/30 group-hover:text-[#C5A059] transition-colors" />
            </button>
          </div>

          {/* Section: صلاة المغرب */}
          <div className="py-4 space-y-3.5">
            <span className="text-xs font-bold text-[#C5A059] block">
              {language === 'en' ? 'Maghrib Prayer' : 'صلاة المغرب'}
            </span>

            {/* تشغيل الأذان */}
            <div className="flex items-center justify-between">
              <span className="text-base text-white/95">
                {language === 'en' ? 'Play Adhan' : 'تشغيل الأذان'}
              </span>
              <button
                onClick={() => togglePrayer('maghrib')}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  prayerEnabled.maghrib ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full transition-transform ${
                    prayerEnabled.maghrib ? 'right-6 bg-black' : 'right-0.5 bg-white'
                  }`}
                />
              </button>
            </div>

            {/* صوت أذان المغرب */}
            <button
              onClick={() => onOpenMuezzinPickerForPrayer('maghrib', 'المغرب')}
              className="w-full flex items-center justify-between py-1 group cursor-pointer"
            >
              <div>
                <span className="text-base text-white/95 group-hover:text-[#C5A059] transition-colors block">
                  {language === 'en' ? 'Maghrib Adhan Sound' : 'صوت أذان المغرب'}
                </span>
                <span className="text-xs text-[#C5A059] block mt-0.5">
                  {getMuezzinName('maghrib')}
                </span>
              </div>
              <ChevronLeft className="w-5 h-5 text-white/30 group-hover:text-[#C5A059] transition-colors" />
            </button>
          </div>

          {/* Section: صلاة العشاء */}
          <div className="py-4 space-y-3.5 pb-8">
            <span className="text-xs font-bold text-[#C5A059] block">
              {language === 'en' ? 'Isha Prayer' : 'صلاة العشاء'}
            </span>

            {/* تشغيل الأذان */}
            <div className="flex items-center justify-between">
              <span className="text-base text-white/95">
                {language === 'en' ? 'Play Adhan' : 'تشغيل الأذان'}
              </span>
              <button
                onClick={() => togglePrayer('isha')}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  prayerEnabled.isha ? 'bg-[#C5A059]' : 'bg-[#2E2C38]'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full transition-transform ${
                    prayerEnabled.isha ? 'right-6 bg-black' : 'right-0.5 bg-white'
                  }`}
                />
              </button>
            </div>

            {/* صوت أذان العشاء */}
            <button
              onClick={() => onOpenMuezzinPickerForPrayer('isha', 'العشاء')}
              className="w-full flex items-center justify-between py-1 group cursor-pointer"
            >
              <div>
                <span className="text-base text-white/95 group-hover:text-[#C5A059] transition-colors block">
                  {language === 'en' ? 'Isha Adhan Sound' : 'صوت أذان العشاء'}
                </span>
                <span className="text-xs text-[#C5A059] block mt-0.5">
                  {getMuezzinName('isha')}
                </span>
              </div>
              <ChevronLeft className="w-5 h-5 text-white/30 group-hover:text-[#C5A059] transition-colors" />
            </button>
          </div>
        </div>
      </div>

      {/* Adhan Alert Method Dialog matching screenshot */}
      {showNotificationMethodDialog && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in select-none"
          onClick={() => setShowNotificationMethodDialog(false)}
        >
          <div
            className="w-full max-w-sm bg-[#1E1C27] border border-white/10 rounded-3xl p-6 shadow-2xl text-white space-y-4 animate-in zoom-in-95 text-right font-['Cairo',sans-serif]"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-base font-bold text-white mb-2">
              طريقة التنبيه بموعد الأذان
            </h3>

            <div className="space-y-3 pt-1">
              {[
                { id: 'window', label: 'نافذة' },
                { id: 'notification', label: 'تنبيه' },
                {
                  id: 'lock_window_unlocked_notification',
                  label: 'نافذة عند قفل الهاتف، وتنبيه إذا كان مفتوحا',
                },
              ].map((item) => {
                const isSelected =
                  (settings?.adhanAlertMethod ||
                    nativeAlarmBridge.getAdhanAlertMethod()) === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      nativeAlarmBridge.setAdhanAlertMethod(item.id as any);
                      onUpdateSettings?.({ adhanAlertMethod: item.id as any });
                      setShowNotificationMethodDialog(false);
                    }}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer text-right group active:scale-[0.99]"
                  >
                    <span
                      className={`text-sm font-medium ${
                        isSelected ? 'text-white' : 'text-white/80'
                      }`}
                    >
                      {item.label}
                    </span>
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors shrink-0 ml-3 ${
                        isSelected ? 'border-[#C5A059]' : 'border-white/30'
                      }`}
                    >
                      {isSelected && (
                        <div className="w-2.5 h-2.5 rounded-full bg-[#C5A059]" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="pt-3 border-t border-white/5 flex justify-start">
              <button
                type="button"
                onClick={() => setShowNotificationMethodDialog(false)}
                className="text-sm font-bold text-[#C5A059] hover:underline cursor-pointer px-2 py-1"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Adhan Activity Log Modal */}
      <AdhanLogModal
        isOpen={isAdhanLogModalOpen}
        onClose={() => setIsAdhanLogModalOpen(false)}
      />
    </div>
  );
};
