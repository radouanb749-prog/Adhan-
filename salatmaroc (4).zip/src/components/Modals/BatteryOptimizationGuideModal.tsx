import React, { useState, useEffect, useCallback } from 'react';
import {
  X,
  BatteryCharging,
  ShieldAlert,
  Volume2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Smartphone,
  ChevronLeft,
} from 'lucide-react';
import { nativeAlarmBridge } from '../../services/nativeAlarmBridge';

interface BatteryOptimizationGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BatteryOptimizationGuideModal: React.FC<BatteryOptimizationGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const isNative = nativeAlarmBridge.isAvailable();
  const [dndGranted, setDndGranted] = useState<boolean>(() => nativeAlarmBridge.isDndAccessGranted());
  const [batteryIgnored, setBatteryIgnored] = useState<boolean>(() =>
    nativeAlarmBridge.isIgnoringBatteryOptimizations()
  );
  const [exactAlarmGranted, setExactAlarmGranted] = useState<boolean>(() =>
    nativeAlarmBridge.canScheduleExactAlarms()
  );
  const [fullScreenGranted, setFullScreenGranted] = useState<boolean>(() =>
    nativeAlarmBridge.canUseFullScreenIntent()
  );

  const refreshStatuses = useCallback(() => {
    setDndGranted(nativeAlarmBridge.isDndAccessGranted());
    setBatteryIgnored(nativeAlarmBridge.isIgnoringBatteryOptimizations());
    setExactAlarmGranted(nativeAlarmBridge.canScheduleExactAlarms());
    setFullScreenGranted(nativeAlarmBridge.canUseFullScreenIntent());
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    refreshStatuses();

    const handleReturn = () => refreshStatuses();
    window.addEventListener('focus', handleReturn);
    document.addEventListener('visibilitychange', handleReturn);
    return () => {
      window.removeEventListener('focus', handleReturn);
      document.removeEventListener('visibilitychange', handleReturn);
    };
  }, [isOpen, refreshStatuses]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md select-none font-['Cairo',sans-serif]"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md bg-[#18171F] border border-[#C5A059]/40 rounded-3xl p-5 shadow-2xl max-h-[90vh] flex flex-col overflow-hidden text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
              <BatteryCharging className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                ضمان عمل الأذان في الخلفية والصامت
              </h3>
              <p className="text-[11px] text-[#C5A059]">
                تطبيق المؤذن • إعدادات البطارية وعدم الإزعاج
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto space-y-4 py-4 pr-1">
          {/* Mandatory Explanation Highlight Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/20 via-[#C5A059]/10 to-black/40 border border-[#C5A059]/60 space-y-2">
            <div className="flex items-center gap-2 text-[#C5A059] font-extrabold text-sm">
              <AlertTriangle className="w-5 h-5 shrink-0 text-amber-400" />
              <span>يجب إيقاف تحسين البطارية للتطبيق لكي يعمل الأذان دائما</span>
            </div>
            <p className="text-xs text-white/85 leading-relaxed">
              تقوم أنظمة أندرويد (خاصة Xiaomi / Redmi و Samsung و Huawei) بإيقاف التطبيقات عند إغلاقها أو دخول الهاتف في وضع السكون لتوفير الطاقة، مما يمنع الأذان من العمل في وقته. عند استثناء تطبيق <strong>المؤذن</strong> من تحسين البطارية ومنحه إذن عدم الإزعاج، سيعمل الأذان بدقة عالية حتى لو كان الهاتف مقفلاً أو على الوضع الصامت.
            </p>
          </div>

          {/* 1. Battery Optimization Permission Card */}
          <div className="p-3.5 rounded-2xl bg-[#22202C] border border-white/10 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <BatteryCharging className="w-4 h-4 text-emerald-400 shrink-0" />
                <h4 className="text-sm font-bold text-white">
                  1. إذن تجاهل تحسين البطارية
                </h4>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  !isNative || batteryIgnored
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/40'
                }`}
              >
                {!isNative ? 'عند التثبيت كـ APK' : batteryIgnored ? 'مفعل ✓' : 'مطلوب التفعيل'}
              </span>
            </div>
            <p className="text-xs text-white/70 leading-relaxed">
              اختر <strong>"السماح / تجاهل تحسين البطارية"</strong> أو <strong>"بلا قيود (Unrestricted)"</strong> ليعمل منبه الأذان والخدمة الخلفية دائماً بدون توقف.
            </p>
            <button
              type="button"
              onClick={() => nativeAlarmBridge.requestBatteryExemption()}
              disabled={!isNative}
              className="w-full py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:bg-white/10 disabled:text-white/40 text-black font-bold text-xs flex items-center justify-between transition-all active:scale-95 cursor-pointer"
            >
              <span>منح إذن تجاهل تحسين البطارية الآن</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* 2. Do Not Disturb (DND) Bypass Permission Card */}
          <div className="p-3.5 rounded-2xl bg-[#22202C] border border-white/10 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-[#C5A059] shrink-0" />
                <h4 className="text-sm font-bold text-white">
                  2. إذن تجاوز وضع عدم الإزعاج (DND) والصامت
                </h4>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  !isNative || dndGranted
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/40'
                }`}
              >
                {!isNative ? 'عند التثبيت كـ APK' : dndGranted ? 'مفعل ✓' : 'مطلوب التفعيل'}
              </span>
            </div>
            <p className="text-xs text-white/70 leading-relaxed">
              يتيح هذا الإذن لتطبيق <strong>المؤذن</strong> رفع صوت الأذان عبر قناة المنبه الرسمية (STREAM_ALARM) حتى عند تفعيل الصامت أو عدم الإزعاج، ثم يعيد مستوى الصوت كما كان بعد انتهاء الأذان.
            </p>
            <button
              type="button"
              onClick={() => nativeAlarmBridge.requestDndAccess()}
              disabled={!isNative}
              className="w-full py-2.5 px-3 rounded-xl bg-[#C5A059] hover:bg-[#d8b56f] disabled:bg-white/10 disabled:text-white/40 text-black font-bold text-xs flex items-center justify-between transition-all active:scale-95 cursor-pointer"
            >
              <span>فتح إعدادات إذن "عدم الإزعاج"</span>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* 3. Exact Alarm Status */}
          <div className="p-3.5 rounded-2xl bg-[#22202C] border border-white/10 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-400 shrink-0" />
                <h4 className="text-sm font-bold text-white">
                  3. صلاحية المنبه الدقيق (أندرويد 12+)
                </h4>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  !isNative || exactAlarmGranted
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/40'
                }`}
              >
                {!isNative ? 'تلقائي' : exactAlarmGranted ? 'مفعل ✓' : 'مطلوب التفعيل'}
              </span>
            </div>
            {isNative && !exactAlarmGranted && (
              <button
                type="button"
                onClick={() => nativeAlarmBridge.requestExactAlarmPermission()}
                className="w-full py-2 px-3 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/40 font-bold text-xs flex items-center justify-between cursor-pointer"
              >
                <span>تفعيل صلاحية المنبه الدقيق</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* 4. Full-Screen Intent Lock Screen Display (Android 14+) */}
          <div className="p-3.5 rounded-2xl bg-[#22202C] border border-white/10 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#C5A059] shrink-0" />
                <h4 className="text-sm font-bold text-white">
                  4. إذن الظهور الفوري فوق شاشة القفل
                </h4>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                  !isNative || fullScreenGranted
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/40'
                }`}
              >
                {!isNative ? 'تلقائي' : fullScreenGranted ? 'مفعل ✓' : 'مطلوب التفعيل'}
              </span>
            </div>
            <p className="text-xs text-white/70 leading-relaxed">
              يتيح ظهور شاشة الأذان الكاملة وإيقاظ الشاشة تلقائياً عند دخول وقت الصلاة حتى عندما يكون الهاتف مقفلاً (أندرويد 14+).
            </p>
            {isNative && !fullScreenGranted && (
              <button
                type="button"
                onClick={() => nativeAlarmBridge.requestFullScreenIntentPermission()}
                className="w-full py-2 px-3 rounded-xl bg-[#C5A059] hover:bg-[#d8b56f] text-black font-bold text-xs flex items-center justify-between cursor-pointer"
              >
                <span>تفعيل الظهور فوق شاشة القفل الآن</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Phone-specific instructions */}
          <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2 text-xs text-white/75">
            <div className="flex items-center gap-1.5 text-white font-bold">
              <Smartphone className="w-4 h-4 text-[#C5A059]" />
              <span>خطوات إضافية لهواتف Redmi / Xiaomi / Samsung:</span>
            </div>
            <ul className="space-y-1.5 pr-4 list-disc leading-relaxed text-[11px]">
              <li>
                <strong>Xiaomi / Redmi:</strong> افتح معلومات التطبيق ← موفر البطارية ← اختر <strong>"لا توجد قيود"</strong>، وفعّل <strong>"التشغيل التلقائي (Autostart)"</strong>.
              </li>
              <li>
                <strong>Samsung:</strong> معلومات التطبيق ← البطارية ← اختر <strong>"غير مقيد (Unrestricted)"</strong>.
              </li>
              <li>
                <strong>تأكد من ظهور الإشعار الدائم</strong> ("المؤذن • مواقيت الصلاة") لضمان بقاء الخدمة نشطة في الخلفية.
              </li>
            </ul>
          </div>

          {!isNative && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2 text-[11px] text-amber-200">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
              <span>
                ملاحظة: أزرار النظام التلقائية تعمل مباشرة داخل تطبيق الأندرويد (APK) المثبت على الهاتف، لأن المتصفح لا يملك صلاحيات تجاوز الوضع الصامت أو تحسين البطارية.
              </span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-[#C5A059] hover:bg-[#d8b56f] text-black font-bold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>فهمت، حفظ وإغلاق</span>
          </button>
        </div>
      </div>
    </div>
  );
};
