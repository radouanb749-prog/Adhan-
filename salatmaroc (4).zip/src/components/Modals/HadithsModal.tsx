import React, { useState } from 'react';
import { X, Search, BookOpen, Copy, Check, Share2 } from 'lucide-react';
import { AUTHENTIC_HADITHS } from '../../data/hadithsData';
import { HadithItem } from '../../types/prayer';

interface HadithsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HadithsModal: React.FC<HadithsModalProps> = ({ isOpen, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filtered = AUTHENTIC_HADITHS.filter(
    (h) =>
      h.text.includes(searchTerm) ||
      h.narrator.includes(searchTerm) ||
      (h.chapter && h.chapter.includes(searchTerm))
  );

  const handleCopy = (h: HadithItem) => {
    navigator.clipboard.writeText(`${h.text}\n[${h.source}]`);
    setCopiedId(h.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = async (h: HadithItem) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'حديث نبوي شريف',
          text: `${h.text}\n[${h.source}]`,
        });
      } catch {
        // cancelled
      }
    } else {
      handleCopy(h);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-lg bg-[#1E1E1E] border border-white/10 rounded-2xl p-5 shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#C5A059]" />
            <h3 className="text-xl font-bold text-white font-['Cairo',sans-serif]">
              أحاديث نبوية شريفة
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="relative my-3">
          <Search className="w-4 h-4 absolute right-3 top-3 text-white/40" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ابحث في الأحاديث..."
            className="w-full bg-[#161616] border border-white/10 rounded-xl pr-9 pl-4 py-2 text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#C5A059]"
          />
        </div>

        {/* Hadith list */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {filtered.map((hadith) => (
            <div
              key={hadith.id}
              className="p-4 rounded-xl bg-[#252525] border border-white/5 hover:border-[#C5A059]/30 transition-all"
            >
              {hadith.chapter && (
                <span className="text-[11px] text-[#C5A059] bg-[#C5A059]/10 px-2 py-0.5 rounded-full font-medium mb-2 inline-block">
                  {hadith.chapter}
                </span>
              )}
              <p className="text-base text-white/95 leading-relaxed font-['Amiri',serif]">
                {hadith.text}
              </p>
              <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between text-xs text-white/50">
                <span>{hadith.source}</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(hadith)}
                    className="p-1 rounded hover:bg-white/10 text-white/70 hover:text-[#C5A059]"
                    title="نسخ"
                  >
                    {copiedId === hadith.id ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    onClick={() => handleShare(hadith)}
                    className="p-1 rounded hover:bg-white/10 text-white/70 hover:text-[#C5A059]"
                    title="مشاركة"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
