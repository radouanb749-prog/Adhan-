import React from 'react';
import { ChevronRight, ChevronLeft, RotateCcw } from 'lucide-react';
import { SettingsState, PrayerTimeItem } from '../../types/prayer';
import { audioAdhanService } from '../../services/audioAdhan';
import { useLanguage } from '../../context/LanguageContext';

interface PrayerTimesAdjustModalProps {
  isOpen: boolean;
  onClose: () => void;
  prayers: PrayerTimeItem[];
  settings: SettingsState;
  onUpdateSettings: (newSettings: Partial<SettingsState>) => void;
}

export const PrayerTimesAdjustModal: React.FC<PrayerTimesAdjustModalProps> = ({
  isOpen,
  onClose,
  prayers,
  settings,
  onUpdateSettings,
}) => {
  const { language, t } = useLanguage();

  if (!isOpen) return null;

  const prayerItems: {
    key: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
    nameAr: string;
    nameEn: string;
    offsetKey: keyof SettingsState;
  }[] = [
    { key: 'fajr', nameAr: 'الفجر', nameEn: 'Fajr', offsetKey: 'fajrOffset' },
    { key: 'sunrise', nameAr: 'الشروق', nameEn: 'Sunrise', offsetKey: 'sunriseOffset' },
    { key: 'dhuhr', nameAr: 'الظهر', nameEn: 'Dhuhr', offsetKey: 'dhuhrOffset' },
    { key: 'asr', nameAr: 'العصر', nameEn: 'Asr', offsetKey: 'asrOffset' },
    { key: 'maghrib', nameAr: 'المغرب', nameEn: 'Maghrib', offsetKey: 'maghribOffset' },
    { key: 'isha', nameAr: 'العشاء', nameEn: 'Isha', offsetKey: 'ishaOffset' },
  ];

  const handleAdjust = (offsetKey: keyof SettingsState, delta: number) => {
    const currentVal = (settings[offsetKey] as number) || 0;
    const newVal = currentVal + delta;
    onUpdateSettings({ [offsetKey]: newVal });
    audioAdhanService.playClickSound();
  };

  const handleResetAll = () => {
    onUpdateSettings({
      fajrOffset: 0,
      sunriseOffset: 0,
      dhuhrOffset: 0,
      asrOffset: 0,
      maghribOffset: 0,
      ishaOffset: 0,
    });
    audioAdhanService.playClickSound();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/85 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-md h-full sm:h-auto sm:max-h-[92vh] bg-[#161616] sm:border sm:border-white/10 sm:rounded-2xl p-4 sm:p-6 shadow-2xl flex flex-col overflow-y-auto">
        {/* Top Header Bar matching screenshot */}
        <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-4">
          <div className="w-8" />
          <h2 className="text-xl font-bold text-white font-['Cairo',sans-serif]">
            {t.prayerTimesAdjustTitle}
          </h2>
          {/* Back button (Golden Chevron) */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/5 text-[#C5A059] hover:text-[#d8b56f] transition-all active:scale-90"
            title={t.back}
            aria-label={t.back}
          >
            {language === 'ar' ? (
              <ChevronRight className="w-7 h-7 stroke-[2.5]" />
            ) : (
              <ChevronLeft className="w-7 h-7 stroke-[2.5]" />
            )}
          </button>
        </div>

        {/* Section 1: Automatic Settings (الإعدادات التلقائية) */}
        <div className="flex items-center justify-between py-3.5 px-2 border-b border-white/5">
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.autoSettings ?? true}
              onChange={(e) => onUpdateSettings({ autoSettings: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-[#2a2a2a] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#C5A059]"></div>
          </label>

          <div>
            <h4 className="text-base font-bold text-white font-['Cairo',sans-serif]">
              {t.autoSettings}
            </h4>
            <p className="text-xs text-white/50">
              {t.autoSettingsDesc}
            </p>
          </div>
        </div>

        {/* Section 2: Calculation Method (طريقة الحساب) */}
        <div className="py-3 px-2 border-b border-white/5">
          <h4 className="text-sm font-semibold text-white/90">
            {language === 'en' ? 'Calculation Method' : 'طريقة الحساب'}
          </h4>
          <p className="text-xs text-white/50 mt-0.5">
            {language === 'en'
              ? 'Ministry of Endowments & Islamic Affairs (Morocco)'
              : 'وزارة الأوقاف والشؤون الإسلامية (المملكة المغربية)'}
          </p>
        </div>

        {/* Section 3: Asr Method (مذهب حساب صلاة العصر) */}
        <div className="py-3 px-2 border-b border-white/5">
          <h4 className="text-sm font-semibold text-white/90">
            {language === 'en' ? 'Asr Juristic Method' : 'مذهب حساب صلاة العصر'}
          </h4>
          <p className="text-xs text-white/50 mt-0.5">
            {language === 'en' ? 'Standard / Majority (Maliki)' : 'مذهب الجمهور (المالكي)'}
          </p>
        </div>

        {/* Section 4: Adjust Prayer Times Header (تعديل أوقات الصلاة) */}
        <div className="flex items-center justify-between pt-5 pb-2 px-2">
          <button
            onClick={handleResetAll}
            className="flex items-center gap-1 text-[11px] text-[#C5A059] bg-[#C5A059]/10 px-2.5 py-1 rounded-full hover:bg-[#C5A059]/20 transition-all cursor-pointer"
            title={t.resetAll}
          >
            <RotateCcw className="w-3 h-3" />
            <span>{t.resetAll}</span>
          </button>
          <h3 className="text-sm font-bold text-[#C5A059] font-['Cairo',sans-serif]">
            {t.adjustPrayerTimes}
          </h3>
        </div>

        {/* List of 6 prayers adjustment rows */}
        <div className="divide-y divide-white/5 mt-1">
          {prayerItems.map((item) => {
            const prayer = prayers.find((p) => p.id === item.key);
            const offset = (settings[item.offsetKey] as number) || 0;

            return (
              <div
                key={item.key}
                className="flex items-center justify-between py-3 px-2 transition-colors hover:bg-white/[0.02]"
              >
                {/* Plus / Offset / Minus */}
                <div className="flex items-center gap-4">
                  {/* Plus Button */}
                  <button
                    onClick={() => handleAdjust(item.offsetKey, 1)}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-xl font-bold text-[#C5A059] hover:bg-[#C5A059]/15 active:scale-90 transition-all cursor-pointer"
                    title={language === 'en' ? 'Add 1 min' : 'زيادة دقيقة'}
                  >
                    +
                  </button>

                  {/* Offset display (0, +1, -1, ...) */}
                  <span className="w-7 text-center font-mono text-base font-bold text-white">
                    {offset > 0 ? `+${offset}` : offset}
                  </span>

                  {/* Minus Button */}
                  <button
                    onClick={() => handleAdjust(item.offsetKey, -1)}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-xl font-bold text-[#C5A059] hover:bg-[#C5A059]/15 active:scale-90 transition-all cursor-pointer"
                    title={language === 'en' ? 'Subtract 1 min' : 'إنقاص دقيقة'}
                  >
                    -
                  </button>
                </div>

                {/* Prayer Name and Time */}
                <div className="text-right">
                  <h4 className="text-base font-bold text-white font-['Cairo',sans-serif]">
                    {language === 'en' ? item.nameEn : item.nameAr}
                  </h4>
                  <span className="text-xs text-white/50 font-mono tracking-wider">
                    {prayer?.time || '--:--'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom confirmation */}
        <div className="mt-6 pt-3 border-t border-white/5">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-[#C5A059] hover:bg-[#b5924b] text-black font-bold text-sm transition-all active:scale-[0.98] cursor-pointer"
          >
            {language === 'en' ? 'Save & Close' : 'حفظ وإغلاق'}
          </button>
        </div>
      </div>
    </div>
  );
};
