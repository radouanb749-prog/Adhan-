import React, { useState, useEffect } from 'react';
import {
  X,
  Settings,
  Volume2,
  Bell,
  Calendar,
  Info,
  VolumeX,
  Clock,
  SlidersHorizontal,
  ChevronLeft,
  Play,
  Square,
  Check,
  CheckCircle2,
  Sparkles,
  MapPin,
  Sun,
  Moon,
  Download,
  Navigation,
  Loader2,
  Smartphone,
  Activity,
  Languages,
  Zap,
  BellRing,
  Timer,
  ShieldAlert,
  BatteryCharging,
} from 'lucide-react';
import { SettingsState } from '../../types/prayer';
import { audioAdhanService, AdhanPlaybackState } from '../../services/audioAdhan';
import { notificationService } from '../../services/notificationService';
import { adhanLogService, AdhanLogSummary } from '../../services/adhanLogService';
import { wakeLockService } from '../../services/wakeLockService';
import { nativeAlarmBridge } from '../../services/nativeAlarmBridge';
import { AdhanLogModal } from './AdhanLogModal';
import { BatteryOptimizationGuideModal } from './BatteryOptimizationGuideModal';
import { MUEZZINS_LIST, MuezzinItem } from '../../data/muezzinsData';
import { requestMotionPermission, useShakeDetector } from '../../hooks/useShakeDetector';
import { useLanguage } from '../../context/LanguageContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SettingsState;
  onUpdateSettings: (newSettings: Partial<SettingsState>) => void;
  onOpenPrayerAdjust: () => void;
  onOpenAdhanSettings?: () => void;
  onOpenMuezzinSelector?: () => void;
  onOpenCityPicker?: () => void;
  onAutoLocate?: () => void;
  isLocating?: boolean;
  gpsStatusMessage?: string | null;
  onDownloadZip?: () => void;
  currentCityName?: string;
  currentCityRegion?: string;
  sunriseTime?: string;
  sunsetTime?: string;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onOpenPrayerAdjust,
  onOpenAdhanSettings,
  onOpenMuezzinSelector,
  onOpenCityPicker,
  onAutoLocate,
  isLocating = false,
  gpsStatusMessage,
  onDownloadZip,
  currentCityName = 'المحمدية',
  currentCityRegion = 'جهة الدار البيضاء - سطات',
  sunriseTime = '06:20',
  sunsetTime = '18:15',
}) => {
  const [playbackState, setPlaybackState] = useState<AdhanPlaybackState>(() =>
    audioAdhanService.getPlaybackState()
  );
  const [shakeTestMessage, setShakeTestMessage] = useState<string | null>(null);
  const [isAdhanLogModalOpen, setIsAdhanLogModalOpen] = useState(false);
  const [adhanSummary, setAdhanSummary] = useState<AdhanLogSummary>(() =>
    adhanLogService.getSummary()
  );
  const [isWakeLockActive, setIsWakeLockActive] = useState<boolean>(() =>
    wakeLockService.isActive()
  );
  const isWakeLockSupported = wakeLockService.isSupported();
  const [testAlarmCountdown, setTestAlarmCountdown] = useState<number | null>(null);
  const [testAlarmStatus, setTestAlarmStatus] = useState<string | null>(null);
  const [isBatteryGuideOpen, setIsBatteryGuideOpen] = useState(false);

  useEffect(() => {
    return wakeLockService.subscribe((active) => {
      setIsWakeLockActive(active);
    });
  }, []);

  useEffect(() => {
    return adhanLogService.subscribe(() => {
      setAdhanSummary(adhanLogService.getSummary());
    });
  }, []);

  // 15-second test alarm countdown
  useEffect(() => {
    if (testAlarmCountdown === null) return;
    if (testAlarmCountdown <= 0) {
      setTestAlarmCountdown(null);
      return;
    }
    const timer = setTimeout(() => {
      setTestAlarmCountdown((prev) => (prev !== null && prev > 0 ? prev - 1 : null));
    }, 1000);
    return () => clearTimeout(timer);
  }, [testAlarmCountdown]);

  const handleStart15sTest = () => {
    // 1. Native Android setAlarmClock bridge (AdhanForegroundService + USE_FULL_SCREEN_INTENT)
    nativeAlarmBridge.scheduleTestAlarm(15000);

    // 2. Browser-only fallback when testing outside native Android shell
    if (!nativeAlarmBridge.isAvailable()) {
      setTimeout(() => {
        audioAdhanService.playRealAdhan('/audio/adhan-morocco.mp3', 'test_15s_adhan', 'أذان الاختبار', 'المؤذن المغربي');
      }, 15000);
    }

    setTestAlarmCountdown(15);
    setTestAlarmStatus(
      language === 'en'
        ? '✓ Alarm scheduled for 15s via setAlarmClock! Exit the app now, lock your screen, and put your phone on SILENT. The Adhan will ring aloud!'
        : '✓ تم ضبط منبه الأذان بعد 15 ثانية بـ setAlarmClock! اخرج الآن من التطبيق، أقفل شاشة هاتفك، واجعله على الوضع الصامت؛ سيصدح الأذان تلقائياً فوق شاشة القفل.'
    );
  };

  // Test shake detector while in settings
  useShakeDetector({
    enabled: !!shakeTestMessage && playbackState.isPlaying,
    threshold: 5.5,
    onShake: () => {
      audioAdhanService.stopAll();
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([100, 50, 100]);
        } catch {
          // ignore
        }
      }
      setShakeTestMessage('✓ تم استشعار اهتزاز هاتفك بنجاح وتم إيقاف الأذان! 📳');
      setTimeout(() => {
        setShakeTestMessage(null);
      }, 4000);
    },
  });

  useEffect(() => {
    const unsubscribe = audioAdhanService.subscribe((state) => {
      setPlaybackState(state);
    });
    return unsubscribe;
  }, []);

  if (!isOpen) return null;

  // Selected Adhan ID (default: moroccan_traditional if old key 'moroccan' or 'subtle' was stored)
  const currentSelectedAdhanId =
    settings.adhanSound === 'moroccan'
      ? 'moroccan_traditional'
      : settings.adhanSound === 'makkah'
      ? 'makkah_mulla'
      : settings.adhanSound === 'madinah'
      ? 'madinah_bukhari'
      : settings.adhanSound === 'subtle'
      ? 'moroccan_traditional'
      : settings.adhanSound || 'moroccan_traditional';

  const selectedMuezzin =
    MUEZZINS_LIST.find((m) => m.id === currentSelectedAdhanId) || MUEZZINS_LIST[0];

  const handleTogglePlay = (muezzin: MuezzinItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (playbackState.isPlaying && playbackState.activeId === muezzin.id) {
      audioAdhanService.stopRealAdhan();
    } else {
      audioAdhanService.playRealAdhan(
        muezzin.audioUrl,
        muezzin.id,
        muezzin.nameAr,
        muezzin.muezzinName
      );
    }
  };

  const handleSelectAdhan = (muezzin: MuezzinItem) => {
    onUpdateSettings({ adhanSound: muezzin.id });
    audioAdhanService.playClickSound();
  };

  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-lg bg-[#1A1A1A] border border-white/10 rounded-3xl p-4 sm:p-5 shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#C5A059]" />
            <h3 className="text-xl font-bold text-white font-['Cairo',sans-serif]">
              {t.settings}
            </h3>
          </div>
          <button
            onClick={() => {
              audioAdhanService.stopRealAdhan();
              onClose();
            }}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="flex-1 overflow-y-auto space-y-4 py-4 pr-1">
          {/* 1. Language Selection (العربية / English) */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-[#24222D] to-[#1C1A24] border border-[#C5A059]/40 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
                  <Languages className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white font-['Cairo',sans-serif]">
                    {t.appLanguage}
                  </h4>
                  <p className="text-xs text-white/60 mt-0.5">
                    {language === 'ar' ? 'اختر لغة واجهة التطبيق' : 'Choose application language'}
                  </p>
                </div>
              </div>
            </div>

            {/* Language Selection Buttons */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => {
                  audioAdhanService.playClickSound();
                  setLanguage('ar');
                }}
                className={`py-2.5 px-3 rounded-xl border text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 ${
                  language === 'ar'
                    ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-md'
                    : 'bg-black/40 text-white/80 border-white/10 hover:border-white/20'
                }`}
              >
                <span>العربية</span>
                {language === 'ar' && <Check className="w-4 h-4 text-black stroke-[3]" />}
              </button>

              <button
                type="button"
                onClick={() => {
                  audioAdhanService.playClickSound();
                  setLanguage('en');
                }}
                className={`py-2.5 px-3 rounded-xl border text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 ${
                  language === 'en'
                    ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-md'
                    : 'bg-black/40 text-white/80 border-white/10 hover:border-white/20'
                }`}
              >
                <span>English</span>
                {language === 'en' && <Check className="w-4 h-4 text-black stroke-[3]" />}
              </button>
            </div>
          </div>

          {/* Location & City Settings (تعديل وتحديد الموقع عبر GPS) */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-[#24222D] to-[#1C1A24] border border-[#C5A059]/40 space-y-3.5 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
                  <Navigation className="w-5 h-5 fill-[#C5A059]" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white font-['Cairo',sans-serif] flex items-center gap-1.5">
                    <span>{t.citySettings}</span>
                  </h4>
                  <p className="text-xs text-[#C5A059] font-medium mt-0.5">
                    {currentCityName} • {currentCityRegion}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>{settings.gpsLiveTracking !== false ? t.gpsActive : t.gpsManual}</span>
              </div>
            </div>

            {/* Live GPS Automatic Tracking Toggle when traveling across Morocco */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/10 hover:border-[#C5A059]/30 transition-all">
              <div className="flex items-start gap-2.5">
                <div className="p-1.5 rounded-lg bg-[#C5A059]/15 text-[#C5A059] mt-0.5">
                  <Navigation className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="text-xs sm:text-sm font-bold text-white font-['Cairo',sans-serif]">
                    {t.autoGpsTravel}
                  </h5>
                  <p className="text-[11px] text-white/60 leading-relaxed mt-0.5">
                    {t.autoGpsTravelDesc}
                  </p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.gpsLiveTracking ?? true}
                onChange={(e) => onUpdateSettings({ gpsLiveTracking: e.target.checked })}
                className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer shrink-0 ml-2"
              />
            </div>

            {/* GPS Feedback & Status Alert */}
            {gpsStatusMessage && (
              <div className="p-2.5 rounded-xl bg-[#C5A059]/15 border border-[#C5A059]/30 text-white text-xs flex items-center gap-2">
                <Info className="w-4 h-4 text-[#C5A059] shrink-0" />
                <span className="leading-snug">{gpsStatusMessage}</span>
              </div>
            )}

            {/* Action buttons: manual picker & GPS fetch */}
            <div className="grid grid-cols-2 gap-2 pt-0.5">
              {onAutoLocate && (
                <button
                  onClick={onAutoLocate}
                  disabled={isLocating}
                  className="py-2.5 px-3 rounded-xl bg-[#C5A059] hover:bg-[#d8b56f] text-black text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md active:scale-95 cursor-pointer disabled:opacity-50"
                >
                  {isLocating ? (
                    <Loader2 className="w-4 h-4 animate-spin text-black" />
                  ) : (
                    <Navigation className="w-4 h-4 text-black fill-black" />
                  )}
                  <span>{isLocating ? t.locatingGps : t.locateGpsNow}</span>
                </button>
              )}

              {onOpenCityPicker && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenCityPicker();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold border border-white/10 transition-all flex items-center justify-center gap-1.5 shadow-md active:scale-95 cursor-pointer"
                >
                  <MapPin className="w-4 h-4 text-[#C5A059]" />
                  <span>{t.changeCityManual}</span>
                </button>
              )}
            </div>
          </div>

          {/* Prominent Adjust Prayer Times Button with Sliders Icon */}
          <button
            onClick={() => {
              onClose();
              onOpenPrayerAdjust();
            }}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-l from-[#C5A059]/25 via-[#C5A059]/10 to-[#252525] border border-[#C5A059]/50 hover:border-[#C5A059] transition-all text-right group active:scale-[0.99] cursor-pointer shadow-md"
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-[#C5A059]/20 text-[#C5A059] group-hover:scale-110 transition-transform">
                <SlidersHorizontal className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white group-hover:text-[#C5A059] transition-colors font-['Cairo',sans-serif] flex items-center gap-2">
                  <span>{t.adjustPrayerTimes}</span>
                  <span className="text-[10px] bg-[#C5A059] text-black font-extrabold px-1.5 py-0.5 rounded">
                    {t.adjustNewBadge}
                  </span>
                </h4>
                <p className="text-xs text-white/60 mt-0.5">
                  {t.adjustPrayerTimesDesc}
                </p>
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 text-[#C5A059] group-hover:-translate-x-1 transition-transform" />
          </button>

          {/* Prominent Adhan Settings & Choosing Muezzin for Each Prayer Button */}
          {onOpenAdhanSettings && (
            <button
              onClick={() => {
                onClose();
                onOpenAdhanSettings();
              }}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-l from-[#C5A059]/25 via-[#C5A059]/10 to-[#252525] border border-[#C5A059]/50 hover:border-[#C5A059] transition-all text-right group active:scale-[0.99] cursor-pointer shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-[#C5A059]/20 text-[#C5A059] group-hover:scale-110 transition-transform">
                  <Volume2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white group-hover:text-[#C5A059] transition-colors font-['Cairo',sans-serif] flex items-center gap-2">
                    <span>{t.adhanSettings}</span>
                    <span className="text-[10px] bg-[#C5A059] text-black font-extrabold px-1.5 py-0.5 rounded">
                      {t.adhanCustomBadge}
                    </span>
                  </h4>
                  <p className="text-xs text-white/60 mt-0.5">
                    {t.adhanSettingsDesc}
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-5 h-5 text-[#C5A059] group-hover:-translate-x-1 transition-transform" />
            </button>
          )}

          {/* Section: سجل نشاط الأذان (Adhan Log) */}
          <button
            onClick={() => setIsAdhanLogModalOpen(true)}
            className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-l from-emerald-500/20 via-[#C5A059]/10 to-[#22202C] border border-emerald-500/30 hover:border-[#C5A059] transition-all text-right group active:scale-[0.99] cursor-pointer shadow-md"
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 group-hover:scale-110 transition-transform">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white group-hover:text-[#C5A059] transition-colors font-['Cairo',sans-serif] flex items-center gap-2">
                  <span>{t.adhanLog}</span>
                  <span
                    className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded border ${
                      adhanSummary.error > 0
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    {adhanSummary.error > 0
                      ? `${adhanSummary.error} ${language === 'en' ? 'errors' : 'أخطاء مسجلة'}`
                      : `${language === 'en' ? 'Active 🟢' : 'سليم ويعمل 🟢'}`}
                  </span>
                </h4>
                <p className="text-xs text-white/60 mt-0.5">
                  {t.adhanLogDesc}
                </p>
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 text-[#C5A059] group-hover:-translate-x-1 transition-transform" />
          </button>

          {/* Section: Daily Prayer Tracker Log (سجل تتبع الصلوات اليومية) */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-2">
                  <span>{t.dailyTracker}</span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.5 rounded">
                    {t.dailyTrackerBadge}
                  </span>
                </h4>
                <p className="text-xs text-white/50">
                  {t.dailyTrackerDesc}
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.dailyPrayerTrackerEnabled ?? true}
              onChange={(e) =>
                onUpdateSettings({ dailyPrayerTrackerEnabled: e.target.checked })
              }
              className="w-5 h-5 accent-emerald-500 rounded cursor-pointer"
            />
          </div>

          {/* Section: 5-Minute Pre-Prayer Browser Push Notifications */}
          <div className="p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
                  <Bell className="w-4 h-4 fill-[#C5A059]" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-2">
                    <span>{t.prePrayerAlert}</span>
                    <span className="text-[10px] bg-[#C5A059]/20 text-[#C5A059] px-2 py-0.2 rounded-full font-bold">
                      {settings.prePrayerAlertMinutes || 5} {t.minutesShort}
                    </span>
                  </h4>
                  <p className="text-xs text-white/50">
                    {t.prePrayerAlertDesc}
                  </p>
                </div>
              </div>

              <input
                type="checkbox"
                checked={settings.prePrayerAlertEnabled ?? true}
                onChange={(e) =>
                  onUpdateSettings({ prePrayerAlertEnabled: e.target.checked })
                }
                className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer"
              />
            </div>

            {/* Minutes selector */}
            <div className="flex items-center justify-between pt-1 text-xs">
              <span className="text-white/60">{t.prePrayerMinutes}</span>
              <div className="flex items-center gap-1.5">
                {[3, 5, 10, 15].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => onUpdateSettings({ prePrayerAlertMinutes: mins })}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
                      (settings.prePrayerAlertMinutes || 5) === mins
                        ? 'bg-[#C5A059] text-black shadow'
                        : 'bg-[#181818] text-white/60 hover:text-white'
                    }`}
                  >
                    {mins} {t.minutesShort}
                  </button>
                ))}
              </div>
            </div>

            {/* Test button & Browser permission button */}
            <div className="pt-2 border-t border-white/5 flex items-center justify-between gap-2">
              <button
                onClick={async () => {
                  if (typeof window !== 'undefined' && 'Notification' in window) {
                    await Notification.requestPermission();
                  }
                  audioAdhanService.playClickSound();
                }}
                className="text-[11px] text-white/70 hover:text-[#C5A059] underline cursor-pointer"
              >
                {typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted'
                  ? t.browserPermissionAllowed
                  : t.browserPermissionRequest}
              </button>

              <button
                onClick={() => {
                  notificationService.triggerTestNotification(currentCityName);
                }}
                className="px-2.5 py-1 rounded-lg bg-[#C5A059]/15 hover:bg-[#C5A059]/25 text-[#C5A059] border border-[#C5A059]/30 text-xs font-bold transition-all active:scale-95 cursor-pointer"
              >
                {t.prePrayerTest}
              </button>
            </div>
          </div>

          {/* Section: Daily Morning & Evening Dhikr Reminder (تنبيه الأذكار) */}
          <div className="p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30 space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
                  <Sparkles className="w-4 h-4 fill-[#C5A059]" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-2">
                    <span>{t.dhikrReminder}</span>
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                      📿
                    </span>
                  </h4>
                  <p className="text-xs text-white/50">
                    {t.dhikrReminderDesc}
                  </p>
                </div>
              </div>

              <input
                type="checkbox"
                checked={settings.dhikrReminderEnabled ?? true}
                onChange={(e) =>
                  onUpdateSettings({ dhikrReminderEnabled: e.target.checked })
                }
                className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer"
              />
            </div>

            {(settings.dhikrReminderEnabled ?? true) && (
              <div className="space-y-3 pt-1 border-t border-white/5 animate-in fade-in">
                {/* Morning & Evening Times Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Morning Dhikr Time */}
                  <div className="p-2.5 rounded-xl bg-[#1A1A1A] border border-white/5 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 font-bold text-amber-300">
                        <Sun className="w-3.5 h-3.5" />
                        <span>{t.dhikrMorning}</span>
                      </div>
                      <input
                        type="time"
                        value={settings.morningDhikrTime || '07:30'}
                        onChange={(e) =>
                          onUpdateSettings({ morningDhikrTime: e.target.value })
                        }
                        className="bg-black/60 border border-[#C5A059]/40 text-[#C5A059] rounded-lg px-2 py-1 text-xs font-mono font-bold focus:outline-none focus:border-[#C5A059]"
                      />
                    </div>
                    {/* Quick Presets for Morning */}
                    <div className="flex items-center gap-1 text-[10px]">
                      <span className="text-white/40">{language === 'en' ? 'Presets:' : 'اقتراحات:'}</span>
                      {['06:30', '07:30', '08:30'].map((timeVal) => (
                        <button
                          key={timeVal}
                          type="button"
                          onClick={() => onUpdateSettings({ morningDhikrTime: timeVal })}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors cursor-pointer ${
                            (settings.morningDhikrTime || '07:30') === timeVal
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                              : 'bg-white/5 text-white/50 hover:text-white'
                          }`}
                        >
                          {timeVal}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Evening Dhikr Time */}
                  <div className="p-2.5 rounded-xl bg-[#1A1A1A] border border-white/5 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 font-bold text-indigo-300">
                        <Moon className="w-3.5 h-3.5" />
                        <span>{t.dhikrEvening}</span>
                      </div>
                      <input
                        type="time"
                        value={settings.eveningDhikrTime || '17:30'}
                        onChange={(e) =>
                          onUpdateSettings({ eveningDhikrTime: e.target.value })
                        }
                        className="bg-black/60 border border-[#C5A059]/40 text-[#C5A059] rounded-lg px-2 py-1 text-xs font-mono font-bold focus:outline-none focus:border-[#C5A059]"
                      />
                    </div>
                    {/* Quick Presets for Evening */}
                    <div className="flex items-center gap-1 text-[10px]">
                      <span className="text-white/40">{language === 'en' ? 'Presets:' : 'اقتراحات:'}</span>
                      {['16:30', '17:30', '18:30'].map((timeVal) => (
                        <button
                          key={timeVal}
                          type="button"
                          onClick={() => onUpdateSettings({ eveningDhikrTime: timeVal })}
                          className={`px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors cursor-pointer ${
                            (settings.eveningDhikrTime || '17:30') === timeVal
                              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold'
                              : 'bg-white/5 text-white/50 hover:text-white'
                          }`}
                        >
                          {timeVal}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Sound toggle & test buttons */}
                <div className="pt-2 border-t border-white/5 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer text-white/70 hover:text-white">
                    <input
                      type="checkbox"
                      checked={settings.dhikrReminderSound ?? true}
                      onChange={(e) =>
                        onUpdateSettings({ dhikrReminderSound: e.target.checked })
                      }
                      className="w-4 h-4 accent-[#C5A059] rounded cursor-pointer"
                    />
                    <span>{t.dhikrSound}</span>
                  </label>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => notificationService.triggerTestDhikrReminder('morning')}
                      className="px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-[11px] font-bold transition-all active:scale-95 cursor-pointer flex items-center gap-1"
                    >
                      <Sun className="w-3 h-3" />
                      <span>{t.dhikrTestMorning}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => notificationService.triggerTestDhikrReminder('evening')}
                      className="px-2.5 py-1 rounded-lg bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-300 border border-indigo-500/30 text-[11px] font-bold transition-all active:scale-95 cursor-pointer flex items-center gap-1"
                    >
                      <Moon className="w-3 h-3" />
                      <span>{t.dhikrTestEvening}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Section: Timezone Mode */}
          <div className="space-y-2 p-3.5 rounded-2xl bg-[#222222] border border-white/5">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#C5A059]" />
                <span>{t.timezoneSettings}</span>
              </label>
              <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                {settings.timezoneMode === 'gmt' ? `${t.gmt} 🇲🇦` : t.gmtSummer}
              </span>
            </div>
            <p className="text-xs text-white/50">
              {t.timezoneDesc}
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => onUpdateSettings({ timezoneMode: 'gmt' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                  settings.timezoneMode === 'gmt'
                    ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-md'
                    : 'bg-[#181818] text-white/70 border-white/10 hover:text-white'
                }`}
              >
                {t.gmt}
              </button>
              <button
                onClick={() => onUpdateSettings({ timezoneMode: 'gmt+1' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer ${
                  settings.timezoneMode === 'gmt+1'
                    ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-md'
                    : 'bg-[#181818] text-white/70 border-white/10 hover:text-white'
                }`}
              >
                {t.gmtSummer}
              </button>
            </div>
          </div>

          {/* Section: Automatic Day/Night Theme based on Sunrise and Sunset */}
          <div className="space-y-2.5 p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white flex items-center gap-2">
                <Sun className="w-4 h-4 text-[#C5A059]" />
                <span>{t.themeTitle}</span>
              </label>
              <span className="text-[11px] font-bold text-[#C5A059] bg-[#C5A059]/15 px-2 py-0.5 rounded-full border border-[#C5A059]/30">
                {settings.themeMode === 'auto'
                  ? t.themeCurrentAuto
                  : settings.themeMode === 'light'
                  ? t.themeCurrentLight
                  : t.themeCurrentDark}
              </span>
            </div>

            <p className="text-xs text-white/50 leading-relaxed">
              {language === 'en'
                ? `Automatic mode activates light theme at sunrise (${sunriseTime}) and dark theme at sunset (${sunsetTime}) for your location.`
                : `التبديل التلقائي يضبط الوضع النهاري المريح للعين عند الشروق (${sunriseTime}) والوضع الليلي عند الغروب (${sunsetTime}) حسب مدينتك.`}
            </p>

            <div className="grid grid-cols-3 gap-2 pt-1">
              <button
                onClick={() => onUpdateSettings({ themeMode: 'auto' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  settings.themeMode === 'auto'
                    ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-md'
                    : 'bg-[#181818] text-white/70 border-white/10 hover:text-white'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>{t.themeAuto}</span>
                <span className="text-[10px] font-normal opacity-80">{t.themeAutoDesc}</span>
              </button>

              <button
                onClick={() => onUpdateSettings({ themeMode: 'light' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  settings.themeMode === 'light'
                    ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-md'
                    : 'bg-[#181818] text-white/70 border-white/10 hover:text-white'
                }`}
              >
                <Sun className="w-4 h-4 text-amber-400" />
                <span>{t.themeLight}</span>
                <span className="text-[10px] font-normal opacity-80">{t.themeLightDesc}</span>
              </button>

              <button
                onClick={() => onUpdateSettings({ themeMode: 'dark' })}
                className={`p-2.5 rounded-xl border text-center text-xs font-bold transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                  settings.themeMode === 'dark'
                    ? 'bg-[#C5A059] text-black border-[#C5A059] shadow-md'
                    : 'bg-[#181818] text-white/70 border-white/10 hover:text-white'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>{t.themeDark}</span>
                <span className="text-[10px] font-normal opacity-80">{t.themeDarkDesc}</span>
              </button>
            </div>
          </div>

          {/* Section: Calm Islamic Animated Background & Battery Saver Option */}
          <div className="space-y-3 p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
                  <Sparkles className="w-4 h-4 fill-[#C5A059]" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-1.5">
                    <span>{t.animatedBgTitle}</span>
                    <span className="text-[10px] bg-[#C5A059] text-black font-extrabold px-1.5 py-0.5 rounded">
                      {t.adjustNewBadge}
                    </span>
                  </h4>
                  <p className="text-xs text-white/50 mt-0.5">
                    {t.animatedBgDesc}
                  </p>
                </div>
              </div>

              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                  settings.animatedBackgroundEnabled !== false
                    ? 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30'
                    : 'text-amber-400 bg-amber-500/15 border-amber-500/30'
                }`}
              >
                {settings.animatedBackgroundEnabled !== false ? t.animatedBgActive : t.animatedBgBattery}
              </span>
            </div>

            {/* Toggle Switch */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/10 hover:border-[#C5A059]/40 transition-all">
              <div className="pr-1">
                <h5 className="text-xs sm:text-sm font-bold text-white font-['Cairo',sans-serif]">
                  {t.animatedBgToggle}
                </h5>
                <p className="text-[11px] text-white/60 mt-0.5 leading-relaxed">
                  {t.animatedBgToggleDesc}
                </p>
              </div>

              <input
                type="checkbox"
                checked={settings.animatedBackgroundEnabled !== false}
                onChange={(e) =>
                  onUpdateSettings({ animatedBackgroundEnabled: e.target.checked })
                }
                className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer shrink-0 ml-2"
              />
            </div>
          </div>

          {/* Section: Shake Phone to Stop / Silence Adhan (ميزة إيقاف الأذان بهز الهاتف) */}
          <div className="space-y-3 p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
                  <Smartphone className="w-4 h-4 text-[#C5A059]" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-1.5">
                    <span>{t.shakeTitle}</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.5 rounded border border-emerald-500/30">
                      {t.shakeActive}
                    </span>
                  </h4>
                  <p className="text-xs text-white/50 mt-0.5">
                    {t.shakeDesc}
                  </p>
                </div>
              </div>

              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                  settings.shakeToStopAdhan !== false
                    ? 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30'
                    : 'text-white/40 bg-white/5 border-white/10'
                }`}
              >
                {settings.shakeToStopAdhan !== false ? t.shakeActive : t.shakeDisabled}
              </span>
            </div>

            {/* Toggle Switch */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/10 hover:border-[#C5A059]/40 transition-all">
              <div className="pr-1">
                <h5 className="text-xs sm:text-sm font-bold text-white font-['Cairo',sans-serif]">
                  {t.shakeToggle}
                </h5>
                <p className="text-[11px] text-white/60 mt-0.5 leading-relaxed">
                  {t.shakeToggleDesc}
                </p>
              </div>

              <input
                type="checkbox"
                checked={settings.shakeToStopAdhan !== false}
                onChange={(e) =>
                  onUpdateSettings({ shakeToStopAdhan: e.target.checked })
                }
                className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer shrink-0 ml-2"
              />
            </div>

            {/* Slider Controls when Shake is Enabled */}
            {settings.shakeToStopAdhan !== false && (
              <div className="p-3 rounded-xl bg-black/30 border border-white/5 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white/90">
                    {t.shakeSensitivity}
                  </span>
                  <span className="text-xs font-extrabold text-[#C5A059] bg-[#C5A059]/15 px-2 py-0.5 rounded-full border border-[#C5A059]/30 font-mono">
                    {(settings.shakeSensitivity ?? 5.5).toFixed(1)} m/s²
                  </span>
                </div>

                <input
                  type="range"
                  min="3.0"
                  max="11.0"
                  step="0.5"
                  value={settings.shakeSensitivity ?? 5.5}
                  onChange={(e) =>
                    onUpdateSettings({ shakeSensitivity: parseFloat(e.target.value) })
                  }
                  className="w-full h-2 bg-[#2E2C38] rounded-lg appearance-none cursor-pointer accent-[#C5A059]"
                />
                <div className="flex justify-between text-[10px] text-white/40 font-bold px-0.5">
                  <span>{t.shakeLight}</span>
                  <span>{t.shakeBalanced}</span>
                  <span>{t.shakeFirm}</span>
                </div>
              </div>
            )}

            {/* Interactive Shake Test Button */}
            {settings.shakeToStopAdhan !== false && (
              <div className="pt-1 border-t border-white/5 space-y-2">
                <button
                  type="button"
                  onClick={async () => {
                    await requestMotionPermission();
                    audioAdhanService.playAdhanChime('تجربة إيقاف الأذان بهز الهاتف', 'هز هاتفك الآن لإيقافه');
                    setShakeTestMessage(t.shakeTestingActive);
                  }}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#C5A059]/20 to-[#8C6D32]/20 hover:from-[#C5A059]/30 hover:to-[#8C6D32]/30 border border-[#C5A059]/40 text-[#C5A059] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 shadow-sm"
                >
                  <Smartphone className="w-4 h-4 text-[#C5A059] animate-bounce" />
                  <span>{t.shakeTestBtn}</span>
                </button>

                {shakeTestMessage && (
                  <div className="p-2 rounded-xl bg-black/50 border border-[#C5A059]/30 text-center">
                    <p className="text-xs text-[#C5A059] font-bold animate-pulse">
                      {shakeTestMessage}
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section: Keep Device Awake (Screen Wake Lock API) */}
          <div className="space-y-3 p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <Zap className="w-4 h-4 fill-amber-400 text-amber-400" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-1.5">
                    <span>{t.wakeLockTitle}</span>
                    {isWakeLockSupported && (
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.5 rounded border border-emerald-500/30">
                        {language === 'en' ? 'Supported' : 'مدعوم'}
                      </span>
                    )}
                  </h4>
                  <p className="text-xs text-white/50 mt-0.5 leading-relaxed">
                    {t.wakeLockDesc}
                  </p>
                </div>
              </div>

              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                  settings.keepDeviceAwake !== false && isWakeLockActive
                    ? 'text-amber-400 bg-amber-500/15 border-amber-500/30'
                    : settings.keepDeviceAwake !== false
                    ? 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30'
                    : 'text-white/40 bg-white/5 border-white/10'
                }`}
              >
                {settings.keepDeviceAwake !== false ? t.wakeLockActive : t.wakeLockDisabled}
              </span>
            </div>

            {/* Toggle Switch */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/10 hover:border-[#C5A059]/40 transition-all">
              <div className="pr-1">
                <h5 className="text-xs sm:text-sm font-bold text-white font-['Cairo',sans-serif]">
                  {t.wakeLockToggle}
                </h5>
                <p className="text-[11px] text-white/60 mt-0.5 leading-relaxed">
                  {t.wakeLockToggleDesc}
                </p>
              </div>

              <input
                type="checkbox"
                checked={settings.keepDeviceAwake !== false}
                onChange={async (e) => {
                  const enabled = e.target.checked;
                  onUpdateSettings({ keepDeviceAwake: enabled });
                  await wakeLockService.setEnabled(enabled);
                }}
                className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer shrink-0 ml-2"
              />
            </div>

            {/* Status note */}
            {!isWakeLockSupported ? (
              <p className="text-[11px] text-amber-400/90 bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
                {t.wakeLockNotSupported}
              </p>
            ) : settings.keepDeviceAwake !== false ? (
              <div className="flex items-center gap-2 text-[11px] text-emerald-400 bg-emerald-500/10 px-3 py-2 rounded-xl border border-emerald-500/20">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>
                  {language === 'en'
                    ? 'Wake Lock is active: Your browser will prevent this tab from entering deep sleep, protecting Adhan timers.'
                    : 'ميزة منع السكون نشطة: لن يقوم المتصفح بإدخال التطبيق في السكون العميق، مما يضمن رفع الأذان والتنبيهات الصوتية في موعدها.'}
                </span>
              </div>
            ) : null}
          </div>

          {/* Section: تشغيل الأذان حتى في الوضع الصامت وعدم الإزعاج + تحسين البطارية */}
          <div className="space-y-3 p-3.5 rounded-2xl bg-gradient-to-br from-[#231F18] to-[#1C1A24] border border-[#C5A059]/50 shadow-md">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#C5A059]/20 border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
                  <Volume2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif]">
                    تشغيل الأذان حتى في الوضع الصامت
                  </h4>
                  <p className="text-xs text-white/60 mt-0.5 leading-relaxed">
                    يتجاوز الوضع الصامت وعدم الإزعاج (DND) ويرفع صوت المنبه مؤقتاً أثناء الأذان ثم يعيده كما كان
                  </p>
                </div>
              </div>

              <input
                type="checkbox"
                checked={settings.allowInSilentMode !== false}
                onChange={(e) => {
                  const enabled = e.target.checked;
                  onUpdateSettings({ allowInSilentMode: enabled });
                  nativeAlarmBridge.setAllowInSilentMode(enabled);
                  audioAdhanService.playClickSound();

                  if (enabled) {
                    if (nativeAlarmBridge.isAvailable()) {
                      if (!nativeAlarmBridge.isDndAccessGranted()) {
                        nativeAlarmBridge.requestDndAccess();
                      }
                      if (!nativeAlarmBridge.isIgnoringBatteryOptimizations()) {
                        nativeAlarmBridge.requestBatteryExemption();
                      }
                      if (!nativeAlarmBridge.canUseFullScreenIntent()) {
                        nativeAlarmBridge.requestFullScreenIntentPermission();
                      }
                    }
                    setIsBatteryGuideOpen(true);
                  }
                }}
                className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer shrink-0 ml-1"
              />
            </div>

            {/* Battery optimization explanation & DND / Battery quick-access button */}
            <button
              type="button"
              onClick={() => setIsBatteryGuideOpen(true)}
              className="w-full p-2.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/35 text-amber-200 text-xs font-bold flex items-center justify-between gap-2 transition-all active:scale-[0.99] cursor-pointer text-right"
            >
              <div className="flex items-center gap-2">
                <BatteryCharging className="w-4 h-4 text-amber-400 shrink-0" />
                <span>يجب إيقاف تحسين البطارية للتطبيق لكي يعمل الأذان دائما</span>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#C5A059] shrink-0" />
            </button>
          </div>

          {/* Section: 15-Second Background & Silent Mode Adhan Test */}
          <div className="space-y-3 p-3.5 rounded-2xl bg-gradient-to-br from-[#1c1a17] to-[#25221d] border border-[#C5A059]/40 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#C5A059]/20 border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
                  <BellRing className="w-4 h-4 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-1.5">
                    <span>{t.bgAlarmTestTitle}</span>
                    <span className="text-[10px] bg-[#C5A059]/20 text-[#C5A059] font-bold px-1.5 py-0.5 rounded border border-[#C5A059]/30">
                      setAlarmClock
                    </span>
                  </h4>
                  <p className="text-xs text-white/50 mt-0.5 leading-relaxed">
                    {t.bgAlarmTestDesc}
                  </p>
                </div>
              </div>
            </div>

            {/* Test Trigger Button */}
            <button
              type="button"
              onClick={handleStart15sTest}
              className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md active:scale-95 ${
                testAlarmCountdown !== null
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 animate-pulse'
                  : 'bg-gradient-to-r from-[#C5A059] to-[#8C6D32] hover:brightness-110 text-black border border-[#C5A059]'
              }`}
            >
              <Timer className="w-4 h-4" />
              <span>
                {testAlarmCountdown !== null
                  ? `${language === 'en' ? 'Alarm triggers in' : 'سيصدح الأذان بعد'}: ${testAlarmCountdown} ثانية...`
                  : t.bgAlarmTestBtn}
              </span>
            </button>

            {/* Active Test Instruction Note */}
            {testAlarmStatus && (
              <div className="p-3 rounded-xl bg-black/60 border border-[#C5A059]/40 space-y-1.5">
                <p className="text-xs text-[#C5A059] font-bold leading-relaxed">
                  {testAlarmStatus}
                </p>
                <div className="flex items-center gap-1.5 text-[11px] text-white/70">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>
                    {language === 'en'
                      ? 'Audio Channel: STREAM_ALARM (Rings in silent mode provided phone alarm volume is not set to 0. In web browser, physical mute switch takes precedence).'
                      : 'قناة الصوت: STREAM_ALARM (يصدح عبر مكبر الصوت في وضع الصامت ما دام صوت المنبه في الهاتف مفعلاً. في المتصفح يسري زر الكتم العام للجهاز).'}
                  </span>
                </div>
              </div>
            )}

            {/* Native Permission Quick Action Buttons */}
            {nativeAlarmBridge.isAvailable() && (
              <div className="pt-2 border-t border-white/5 flex flex-wrap gap-2 text-[11px]">
                <button
                  type="button"
                  onClick={() => nativeAlarmBridge.requestDndAccess()}
                  className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/10 flex items-center gap-1 cursor-pointer"
                >
                  <ShieldAlert className="w-3 h-3 text-amber-400" />
                  <span>{language === 'en' ? 'DND Access' : 'إذن تجاوز عدم الإزعاج (DND)'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => nativeAlarmBridge.requestBatteryExemption()}
                  className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/10 flex items-center gap-1 cursor-pointer"
                >
                  <Zap className="w-3 h-3 text-emerald-400" />
                  <span>{language === 'en' ? 'Battery Optimization' : 'إلغاء تحسين البطارية'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => nativeAlarmBridge.requestExactAlarmPermission()}
                  className={`px-2.5 py-1 rounded-lg border flex items-center gap-1 cursor-pointer transition-colors ${
                    nativeAlarmBridge.canScheduleExactAlarms()
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/40 animate-pulse'
                  }`}
                >
                  <Clock className="w-3 h-3 text-[#C5A059]" />
                  <span>
                    {language === 'en'
                      ? nativeAlarmBridge.canScheduleExactAlarms()
                        ? 'Exact Alarm: Granted'
                        : 'Exact Alarm: Request'
                      : nativeAlarmBridge.canScheduleExactAlarms()
                      ? 'المنبه الدقيق: مفعل'
                      : 'إذن المنبه الدقيق (مطلوب)'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => nativeAlarmBridge.requestFullScreenIntentPermission()}
                  className={`px-2.5 py-1 rounded-lg border flex items-center gap-1 cursor-pointer transition-colors ${
                    nativeAlarmBridge.canUseFullScreenIntent()
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/40 animate-pulse'
                  }`}
                >
                  <Smartphone className="w-3 h-3 text-[#C5A059]" />
                  <span>
                    {language === 'en'
                      ? nativeAlarmBridge.canUseFullScreenIntent()
                        ? 'Lock Screen Display: Granted'
                        : 'Lock Screen Display: Request'
                      : nativeAlarmBridge.canUseFullScreenIntent()
                      ? 'الظهور فوق القفل: مفعل'
                      : 'إذن شاشة القفل (مطلوب)'}
                  </span>
                </button>
              </div>
            )}
          </div>

          {/* Section: Rich Islamic Adhan Sound Selector */}
          <div className="space-y-2.5 p-3.5 rounded-2xl bg-[#222222] border border-[#C5A059]/30">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-white flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-[#C5A059]" />
                <span>{t.chooseAdhanSound}</span>
              </label>
              <span className="text-[11px] text-[#C5A059] font-medium">
                {t.customSelection}
              </span>
            </div>
            <p className="text-xs text-white/50">
              {t.chooseAdhanSoundDesc}
            </p>

            {/* Grid of Famous Islamic World Adhans */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              {MUEZZINS_LIST.map((muezzin) => {
                const isSelected = currentSelectedAdhanId === muezzin.id;
                const isPlayingThis =
                  playbackState.isPlaying && playbackState.activeId === muezzin.id;

                return (
                  <div
                    key={muezzin.id}
                    onClick={() => handleSelectAdhan(muezzin)}
                    className={`relative flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#C5A059]/20 border-[#C5A059] shadow-[0_0_15px_rgba(197,160,89,0.15)] ring-1 ring-[#C5A059]'
                        : 'bg-[#181818] border-white/5 hover:border-white/20'
                    }`}
                  >
                    {/* Info */}
                    <div className="flex items-center gap-2 flex-1 min-w-0 pr-1">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h4
                            className={`text-xs sm:text-sm font-bold truncate ${
                              isSelected ? 'text-[#C5A059]' : 'text-white'
                            }`}
                          >
                            {muezzin.nameAr}
                          </h4>
                          {isSelected && (
                            <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                          )}
                        </div>
                        <p className="text-[10px] text-white/50 truncate mt-0.5">
                          {muezzin.muezzinName} • {muezzin.locationAr}
                        </p>
                      </div>
                    </div>

                    {/* Left side Play/Stop Preview Button */}
                    <button
                      onClick={(e) => handleTogglePlay(muezzin, e)}
                      className={`p-2 rounded-lg transition-all shrink-0 active:scale-90 ${
                        isPlayingThis
                          ? 'bg-[#C5A059] text-black shadow animate-pulse'
                          : 'bg-white/10 hover:bg-[#C5A059]/30 text-[#C5A059]'
                      }`}
                      title={isPlayingThis ? t.stopPreview : t.playPreview}
                    >
                      {isPlayingThis ? (
                        <Square className="w-3.5 h-3.5 fill-black" />
                      ) : (
                        <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                      )}
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Currently Active Adhan Summary Badge */}
            <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-xs">
              <span className="text-white/60">{t.currentAdhanSelected}</span>
              <span className="font-bold text-[#C5A059] flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>{selectedMuezzin?.nameAr}</span>
              </span>
            </div>
          </div>

          {/* Section: Notifications Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#222222] border border-white/5">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-[#181818] text-[#C5A059]">
                {settings.notificationsEnabled ? (
                  <Bell className="w-4 h-4" />
                ) : (
                  <VolumeX className="w-4 h-4" />
                )}
              </div>
              <div>
                <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif]">
                  {t.prayerNotifications}
                </h4>
                <p className="text-xs text-white/50">{t.prayerNotificationsDesc}</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.notificationsEnabled}
              onChange={(e) =>
                onUpdateSettings({ notificationsEnabled: e.target.checked })
              }
              className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer"
            />
          </div>

          {/* Section: Hijri Adjustment */}
          <div className="p-3.5 rounded-2xl bg-[#222222] border border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#C5A059]" />
                <span className="text-sm font-bold text-white font-['Cairo',sans-serif]">
                  {t.hijriAdjustment}
                </span>
              </div>
              <span className="text-xs font-mono text-[#C5A059] font-bold">
                {settings.hijriAdjustment > 0
                  ? `+${settings.hijriAdjustment} ${t.day}`
                  : settings.hijriAdjustment < 0
                  ? `${settings.hijriAdjustment} ${t.day}`
                  : t.hijriOfficial}
              </span>
            </div>
            <p className="text-xs text-white/50">
              {t.hijriAdjustmentDesc}
            </p>
            <div className="flex gap-2 pt-1">
              {[-1, 0, 1].map((adj) => (
                <button
                  key={adj}
                  onClick={() => onUpdateSettings({ hijriAdjustment: adj })}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    settings.hijriAdjustment === adj
                      ? 'bg-[#C5A059] text-black shadow'
                      : 'bg-[#181818] text-white/60 hover:text-white'
                  }`}
                >
                  {adj === 0 ? t.hijriOfficial : adj > 0 ? `+${adj} ${t.day}` : `${adj} ${t.day}`}
                </button>
              ))}
            </div>
          </div>

          {/* Section: Information about Morocco calculation */}
          <div className="p-3.5 rounded-2xl bg-[#181818] border border-white/5 text-xs text-white/50 space-y-1.5">
            <div className="flex items-center gap-1.5 text-[#C5A059] font-semibold">
              <Info className="w-3.5 h-3.5" />
              <span>{t.moroccoCalcInfo}</span>
            </div>
            <p className="leading-relaxed">
              {t.moroccoCalcDesc}
            </p>
          </div>

          {/* Download App ZIP Button */}
          {onDownloadZip && (
            <div className="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-white font-['Cairo',sans-serif] flex items-center gap-2">
                    <span>{t.downloadZipTitle}</span>
                    <span className="text-[10px] bg-[#C5A059] text-black font-extrabold px-1.5 py-0.2 rounded-full">
                      {t.supervisorBadge}
                    </span>
                  </h4>
                  <p className="text-[11px] text-white/50">
                    {t.downloadZipDesc}
                  </p>
                </div>
              </div>
              <button
                onClick={onDownloadZip}
                className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold transition-all active:scale-95 cursor-pointer shrink-0"
              >
                {t.supervisorLogin}
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={() => {
              audioAdhanService.stopRealAdhan();
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-[#C5A059] text-black font-bold text-sm hover:bg-[#d8b56f] transition-all cursor-pointer"
          >
            {t.saveDone}
          </button>
        </div>
      </div>

      {/* Adhan Activity Log Modal */}
      <AdhanLogModal
        isOpen={isAdhanLogModalOpen}
        onClose={() => setIsAdhanLogModalOpen(false)}
      />

      {/* Battery Optimization & DND Guide Modal */}
      <BatteryOptimizationGuideModal
        isOpen={isBatteryGuideOpen}
        onClose={() => setIsBatteryGuideOpen(false)}
      />
    </div>
  );
};
