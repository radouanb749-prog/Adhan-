import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  ExternalLink,
  MessageCircle,
  Calendar,
  Sparkles,
  Link2,
} from 'lucide-react';
import { CityData, PrayerTimeItem } from '../../types/prayer';
import { useLanguage } from '../../context/LanguageContext';
import {
  formatPrayerScheduleText,
  getAppShareUrl,
  isWebShareSupported,
  shareViaWebShare,
  copyToClipboard,
} from '../../services/shareService';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCity: CityData;
  dateString: string;
  prayers: PrayerTimeItem[];
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  currentCity,
  dateString,
  prayers,
}) => {
  const { language, t } = useLanguage();
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const appUrl = getAppShareUrl();
  const formattedSchedule = formatPrayerScheduleText({
    city: currentCity,
    dateString,
    prayers,
    language,
  });

  const showToast = (message: string) => {
    setCopyFeedback(message);
    setTimeout(() => {
      setCopyFeedback(null);
    }, 3000);
  };

  const handleWebShare = async () => {
    const title =
      language === 'en'
        ? `Prayer Times for ${currentCity.nameFr || currentCity.nameAr}`
        : `مواقيت الصلاة لمدينة ${currentCity.nameAr}`;

    const success = await shareViaWebShare({
      title,
      text: formattedSchedule,
      url: appUrl,
    });

    if (success) {
      showToast(t.success);
    }
  };

  const handleCopyLink = async () => {
    const ok = await copyToClipboard(appUrl);
    if (ok) {
      showToast(t.linkCopied);
    }
  };

  const handleCopySchedule = async () => {
    const ok = await copyToClipboard(formattedSchedule);
    if (ok) {
      showToast(t.scheduleCopied);
    }
  };

  const handleWhatsAppShare = () => {
    const encodedText = encodeURIComponent(formattedSchedule);
    const waUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  const canShare = isWebShareSupported();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm select-none animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#191919] border border-white/10 rounded-3xl p-4 sm:p-5 shadow-2xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-['Cairo',sans-serif]">
                {t.shareTitle}
              </h3>
              <p className="text-xs text-white/50">
                {currentCity.nameAr} • {dateString}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors cursor-pointer"
            title={t.close}
            aria-label={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast Feedback */}
        {copyFeedback && (
          <div className="mt-3 p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center animate-in fade-in slide-in-from-top-1 duration-200 flex items-center justify-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 stroke-[3]" />
            <span>{copyFeedback}</span>
          </div>
        )}

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto space-y-3.5 py-4 pr-1">
          {/* Primary Action 1: Web Share API Button if available */}
          {canShare && (
            <button
              onClick={handleWebShare}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#C5A059] to-[#d8b56f] text-black font-bold text-sm transition-all shadow-lg hover:shadow-[0_0_20px_rgba(197,160,89,0.3)] active:scale-95 cursor-pointer flex items-center justify-center gap-2.5"
            >
              <Share2 className="w-5 h-5 text-black" />
              <span>{t.shareViaApps}</span>
            </button>
          )}

          {/* Quick Direct Link Box */}
          <div className="p-3 rounded-2xl bg-[#222222] border border-[#C5A059]/30 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Link2 className="w-4 h-4 text-[#C5A059]" />
                <span>{language === 'en' ? 'Direct App Link' : 'رابط التطبيق المباشر'}</span>
              </span>
              <span className="text-[10px] text-white/40">URL</span>
            </div>

            <div className="flex items-center gap-2 bg-black/50 p-2 rounded-xl border border-white/5">
              <input
                type="text"
                readOnly
                value={appUrl}
                className="bg-transparent text-xs text-white/80 font-mono flex-1 outline-none select-all truncate"
              />
              <button
                onClick={handleCopyLink}
                className="px-3 py-1.5 rounded-lg bg-[#C5A059]/20 hover:bg-[#C5A059]/30 text-[#C5A059] text-xs font-bold transition-all flex items-center gap-1.5 shrink-0 active:scale-90 cursor-pointer"
                title={t.copyAppLink}
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{language === 'en' ? 'Copy Link' : 'نسخ الرابط'}</span>
              </button>
            </div>
          </div>

          {/* Action 2: Copy Prayer Schedule formatted box */}
          <div className="p-3 rounded-2xl bg-[#222222] border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-[#C5A059]" />
                <span>{language === 'en' ? "Today's Schedule Text" : 'نص مواقيت الصلاة لليوم'}</span>
              </span>
              <button
                onClick={handleCopySchedule}
                className="text-xs text-[#C5A059] hover:underline flex items-center gap-1 font-bold cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{language === 'en' ? 'Copy Text' : 'نسخ النص'}</span>
              </button>
            </div>

            <div className="bg-black/50 p-3 rounded-xl border border-white/5 text-[11px] text-white/70 font-mono whitespace-pre-line leading-relaxed max-h-36 overflow-y-auto">
              {formattedSchedule}
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={handleCopySchedule}
                className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer border border-white/5"
              >
                <Copy className="w-4 h-4 text-[#C5A059]" />
                <span>{t.copySchedule}</span>
              </button>

              <button
                onClick={handleWhatsAppShare}
                className="py-2.5 px-3 rounded-xl bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] text-xs font-bold transition-all flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer border border-[#25D366]/30"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t.shareWhatsApp}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
