import React, { useState, useEffect } from 'react';
import {
  X,
  Activity,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  VolumeX,
  Volume2,
  Trash2,
  RotateCcw,
  Play,
  Square,
  HelpCircle,
  Clock,
  Sparkles,
  Check,
  FileText,
  Smartphone,
  ExternalLink,
  Download,
} from 'lucide-react';
import {
  adhanLogService,
  AdhanLogEntry,
  AdhanLogStatus,
  AdhanLogSummary,
} from '../../services/adhanLogService';
import { audioAdhanService, AdhanPlaybackState } from '../../services/audioAdhan';
import { useLanguage } from '../../context/LanguageContext';

interface AdhanLogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdhanLogModal: React.FC<AdhanLogModalProps> = ({ isOpen, onClose }) => {
  const { language, t } = useLanguage();
  const [logs, setLogs] = useState<AdhanLogEntry[]>(() => adhanLogService.getLogs());
  const [summary, setSummary] = useState<AdhanLogSummary>(() => adhanLogService.getSummary());
  const [filter, setFilter] = useState<'all' | 'success' | 'error' | 'muted'>('all');
  const [isTesting, setIsTesting] = useState(false);
  const [testResultFeedback, setTestResultFeedback] = useState<string | null>(null);
  const [playbackState, setPlaybackState] = useState<AdhanPlaybackState>(() =>
    audioAdhanService.getPlaybackState()
  );

  useEffect(() => {
    const unsubLogs = adhanLogService.subscribe((updated) => {
      setLogs([...updated]);
      setSummary(adhanLogService.getSummary());
    });
    const unsubAudio = audioAdhanService.subscribe((state) => {
      setPlaybackState(state);
    });
    return () => {
      unsubLogs();
      unsubAudio();
    };
  }, []);

  if (!isOpen) return null;

  // Run immediate real diagnostic audio check and log the results
  const handleRunDiagnosticTest = async () => {
    setIsTesting(true);
    setTestResultFeedback(null);
    audioAdhanService.stopAll();

    const startTime = performance.now();
    const testAudioUrl = '/audio/adhan-morocco.mp3';
    const testTitle = 'فحص تجريبي لملف الأذان';
    const testMuezzin = 'الأذان المغربي الأصيل';

    try {
      // 1. Check Web Audio unlock state
      audioAdhanService.unlockAudio();

      // 2. Play real adhan audio
      await audioAdhanService.playRealAdhan(
        testAudioUrl,
        `test_diag_${Date.now()}`,
        testTitle,
        testMuezzin,
        {
          prayerId: 'diagnostic_test',
          prayerNameAr: 'فحص تجريبي لملف الأذان',
          cityNameAr: 'فحص النظام',
          triggerType: 'manual_test',
        }
      );

      const elapsed = Math.round(performance.now() - startTime);
      setTestResultFeedback(`✓ نجح تشغيل الملف الصوتي في غضون ${elapsed} ملي ثانية!`);
    } catch (err: any) {
      setTestResultFeedback(`⚠️ تعذر التشغيل: ${err?.message || 'خطأ غير متوقع'}`);
    } finally {
      setIsTesting(false);
    }
  };

  const handleClearLogs = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في مسح سجل نشاط الأذان؟')) {
      adhanLogService.clearLogs();
    }
  };

  const handlePlayAudioFromLog = (entry: AdhanLogEntry) => {
    if (playbackState.isPlaying && playbackState.activeId === entry.id) {
      audioAdhanService.stopAll();
    } else {
      audioAdhanService.playRealAdhan(
        entry.audioUrl || '/audio/adhan-morocco.mp3',
        entry.id,
        entry.prayerNameAr,
        entry.muezzinName
      );
    }
  };

  // Filter logs
  const filteredLogs = logs.filter((item) => {
    if (filter === 'success') return item.status === 'success';
    if (filter === 'error') return item.status === 'error' || item.status === 'warning';
    if (filter === 'muted') return item.status === 'muted';
    return true;
  });

  const getStatusBadge = (status: AdhanLogStatus) => {
    switch (status) {
      case 'success':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>{language === 'en' ? 'Played Successfully' : 'تم التشغيل بنجاح'}</span>
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            <span>{language === 'en' ? 'Fallback Sound Used' : 'تم استخدام صوت بديل'}</span>
          </span>
        );
      case 'error':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span>{language === 'en' ? 'Playback Error' : 'خطأ في تشغيل الصوت'}</span>
          </span>
        );
      case 'muted':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-500/15 text-slate-300 border border-slate-500/30">
            <VolumeX className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>{language === 'en' ? 'Muted in Settings' : 'مكتوم في الإعدادات'}</span>
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-xl bg-[#16151E] border border-white/10 rounded-3xl p-4 sm:p-5 shadow-2xl max-h-[92vh] flex flex-col overflow-hidden text-white font-['Cairo',sans-serif]">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#C5A059]/20 text-[#C5A059]">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                <span>{t.adhanLogTitle}</span>
              </h3>
              <p className="text-xs text-white/50">
                {t.adhanLogSubtitle}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              audioAdhanService.stopAll();
              onClose();
            }}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors cursor-pointer"
            title={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Health Status Cards */}
        <div className="grid grid-cols-3 gap-2 py-3 shrink-0">
          {/* Card 1: Success Rate */}
          <div className="p-2.5 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] text-white/60">{t.successfulPlays}</span>
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-lg font-black text-emerald-400">{summary.success}</span>
              <span className="text-[10px] text-white/40">
                {language === 'en' ? `of ${summary.total}` : `من أصل ${summary.total}`}
              </span>
            </div>
          </div>

          {/* Card 2: Errors/Warnings */}
          <div className="p-2.5 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] text-white/60">
              {language === 'en' ? 'Playback Errors' : 'أخطاء التشغيل'}
            </span>
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className={`text-lg font-black ${summary.error > 0 ? 'text-rose-400' : 'text-white/80'}`}>
                {summary.error}
              </span>
              <span className="text-[10px] text-white/40">
                {summary.error === 0 ? (language === 'en' ? 'Zero errors' : 'لا توجد أخطاء') : (language === 'en' ? 'Check required' : 'تتطلب فحص')}
              </span>
            </div>
          </div>

          {/* Card 3: Audio Engine Status */}
          <div className="p-2.5 rounded-2xl bg-[#C5A059]/10 border border-[#C5A059]/30 flex flex-col justify-between">
            <span className="text-[11px] text-[#C5A059]">
              {language === 'en' ? 'Browser Audio Engine' : 'نظام الصوت بالمتصفح'}
            </span>
            <div className="flex items-center gap-1 mt-1 text-emerald-400 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{language === 'en' ? 'Active & Ready' : 'مفعل وجاهز'}</span>
            </div>
          </div>
        </div>

        {/* Action Bar: Test Button & Filter Tabs */}
        <div className="space-y-2.5 pb-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={handleRunDiagnosticTest}
              disabled={isTesting}
              className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#C5A059] to-[#d8b56f] text-black text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-md active:scale-95 cursor-pointer disabled:opacity-60"
            >
              <Volume2 className="w-4 h-4 fill-black" />
              <span>
                {isTesting
                  ? (language === 'en' ? 'Testing audio playback...' : 'جاري فحص وتشغيل الملف الصوتي...')
                  : (language === 'en' ? 'Run Audio Diagnostic & Record' : 'فحص تجريبي للملف الصوتي وتدوين النتيجة')}
              </span>
            </button>

            {logs.length > 0 && (
              <button
                onClick={handleClearLogs}
                className="py-2.5 px-3 rounded-xl bg-white/5 hover:bg-rose-500/20 text-white/60 hover:text-rose-300 border border-white/10 transition-colors text-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                title={t.clearLog}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t.clearLog}</span>
              </button>
            )}
          </div>

          {testResultFeedback && (
            <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
              <div className="flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{testResultFeedback}</span>
              </div>
              <button
                onClick={() => setTestResultFeedback(null)}
                className="text-white/40 hover:text-white text-[11px]"
              >
                {t.close}
              </button>
            </div>
          )}

          {/* Filters Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 text-xs">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer font-bold ${
                filter === 'all'
                  ? 'bg-white text-black'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              {language === 'en' ? 'All' : 'الكل'} ({logs.length})
            </button>
            <button
              onClick={() => setFilter('success')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer font-bold ${
                filter === 'success'
                  ? 'bg-emerald-500 text-black'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              {language === 'en' ? 'Successful' : 'ناجح'} ({summary.success})
            </button>
            <button
              onClick={() => setFilter('error')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer font-bold ${
                filter === 'error'
                  ? 'bg-rose-500 text-white'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              {language === 'en' ? 'Errors' : 'أخطاء'} ({summary.error + summary.warning})
            </button>
            <button
              onClick={() => setFilter('muted')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer font-bold ${
                filter === 'muted'
                  ? 'bg-slate-300 text-black'
                  : 'bg-white/5 text-white/60 hover:bg-white/10'
              }`}
            >
              {language === 'en' ? 'Muted' : 'مكتومة'} ({summary.muted})
            </button>
          </div>
        </div>

        {/* Log Entries List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-white/40">
                <FileText className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white/80">{t.emptyLog}</h4>
              <p className="text-xs text-white/50 max-w-sm mx-auto leading-relaxed">
                {language === 'en'
                  ? 'Each Adhan trigger is automatically monitored and logged with audio file details and playback latency.'
                  : 'يتم تسجيل كل عملية رفع للأذان في موعدها المحدد تلقائياً مع تفاصيل الملف الصوتي ووقت التشغيل.'}
              </p>
              <button
                onClick={handleRunDiagnosticTest}
                className="py-2 px-4 rounded-xl bg-[#C5A059]/20 hover:bg-[#C5A059]/30 text-[#C5A059] border border-[#C5A059]/40 text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-4 h-4" />
                <span>{language === 'en' ? 'Run Audio Test Now' : 'إجراء فحص تجريبي الآن'}</span>
              </button>
            </div>
          ) : (
            filteredLogs.map((entry) => {
              const isPlayingThis = playbackState.isPlaying && playbackState.activeId === entry.id;

              return (
                <div
                  key={entry.id}
                  className={`p-3.5 rounded-2xl border transition-all text-right ${
                    entry.status === 'error'
                      ? 'bg-rose-950/20 border-rose-500/30'
                      : entry.status === 'warning'
                      ? 'bg-amber-950/20 border-amber-500/30'
                      : entry.status === 'muted'
                      ? 'bg-white/[0.02] border-white/5'
                      : 'bg-white/[0.03] border-white/10 hover:border-[#C5A059]/40'
                  }`}
                >
                  {/* Top Bar: Prayer Name & Status Badge */}
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-[#C5A059]" />
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                        <span>{entry.prayerNameAr}</span>
                        {entry.scheduledTime && (
                          <span className="text-xs font-normal text-white/60">
                            (الموعد: {entry.scheduledTime})
                          </span>
                        )}
                      </h4>
                    </div>
                    {getStatusBadge(entry.status)}
                  </div>

                  {/* Message / Explanation */}
                  <p className="text-xs text-white/80 leading-relaxed mb-2">
                    {entry.message}
                  </p>

                  {/* Error details if any */}
                  {entry.errorDetails && (
                    <div className="mb-2 p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-[11px] leading-relaxed">
                      <div className="font-bold flex items-center gap-1 mb-0.5">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>تفاصيل الخطأ:</span>
                      </div>
                      <p className="font-mono text-[10px] text-rose-200/90 break-all">
                        {entry.errorDetails}
                      </p>
                      {entry.errorDetails.toLowerCase().includes('autoplay') && (
                        <p className="mt-1 text-white/80 text-[10px]">
                          💡 حل المشكلة: يتطلب المتصفح لمس أو النقر على شاشة التطبيق مرة واحدة بعد فتحه لإعطاء تصريح تشغيل الصوت التلقائي في المواعيد القادمة.
                        </p>
                      )}
                    </div>
                  )}

                  {/* Meta details (Time, Audio URL, Muezzin, City) */}
                  <div className="pt-2 border-t border-white/5 flex flex-wrap items-center justify-between gap-y-1.5 text-[11px] text-white/50">
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-[#C5A059]" />
                        <span>الوقت الفعلي: {entry.timeFormatted} (غرينتش GMT)</span>
                      </span>
                      {entry.muezzinName && (
                        <span>المؤذن: {entry.muezzinName}</span>
                      )}
                      {entry.cityNameAr && (
                        <span>المدينة: {entry.cityNameAr}</span>
                      )}
                    </div>

                    {/* Audio Preview Button */}
                    {entry.audioUrl && (
                      <button
                        onClick={() => handlePlayAudioFromLog(entry)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 cursor-pointer ${
                          isPlayingThis
                            ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                            : 'bg-white/5 hover:bg-white/10 text-white/70 border border-white/10'
                        }`}
                        title="تجربة الاستماع لهذا الملف الصوتي"
                      >
                        {isPlayingThis ? (
                          <>
                            <Square className="w-3 h-3 fill-current" />
                            <span>إيقاف</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3 h-3 fill-current" />
                            <span>سماع الصوت</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Diagnostic Tips */}
        <div className="pt-3 border-t border-white/10 text-right shrink-0 space-y-2">
          <div className="p-2.5 rounded-2xl bg-[#C5A059]/10 border border-[#C5A059]/20 text-[11px] text-white/70 flex items-start gap-2">
            <Smartphone className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong className="text-[#C5A059]">نظام حماية الأذان في الخلفية والوضع الصامت:</strong> التطبيق لا يعتمد على PWA؛ تم تفعيل حارس الصوت المستمر (Audio Keep-Alive) لمنع إيقاف المتصفح عند قفل الشاشة ولضمان تشغيل الأذان والاهتزاز حتى في الوضع الصامت.
            </p>
          </div>
          <a
            href="/salatmaroc.zip"
            download="salatmaroc.zip"
            className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#C5A059] to-[#8C6D32] hover:brightness-110 text-black font-bold text-xs flex items-center justify-center gap-1.5 transition-all text-center shadow-md active:scale-98"
          >
            <Download className="w-4 h-4 text-black shrink-0" />
            <span>تحميل تطبيق الأندرويد الأصلي (APK / AlarmManager) لتجاوز سكون شاومي نهائياً</span>
          </a>
        </div>
      </div>
    </div>
  );
};
