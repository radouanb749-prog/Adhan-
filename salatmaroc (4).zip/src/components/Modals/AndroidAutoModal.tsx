import React, { useState, useMemo } from 'react';
import {
  X,
  Car,
  Compass,
  Clock,
  Volume2,
  CheckCircle2,
  Navigation,
  Sparkles,
  Cable,
  Wifi,
  Radio,
  Sliders,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { PrayerTimeItem, CityData } from '../../types/prayer';
import { audioAdhanService } from '../../services/audioAdhan';
import { KaabaIcon } from '../BottomNav';

interface AndroidAutoModalProps {
  isOpen: boolean;
  onClose: () => void;
  prayers: PrayerTimeItem[];
  currentCity: CityData;
  nextPrayer?: PrayerTimeItem | null;
  countdownStr?: string | null;
  dateString?: string;
}

export const AndroidAutoModal: React.FC<AndroidAutoModalProps> = ({
  isOpen,
  onClose,
  prayers,
  currentCity,
  nextPrayer,
  countdownStr,
  dateString,
}) => {
  const [activeCarTab, setActiveCarTab] = useState<'prayers' | 'qibla' | 'audio'>('prayers');
  const [isTestingAudio, setIsTestingAudio] = useState(false);

  // Exact Great Circle Qibla Bearing calculation from current city to Makkah (21.4225° N, 39.8262° E)
  const { qiblaBearing, distanceKm, cardinalDirection } = useMemo(() => {
    const lat1 = (currentCity.lat * Math.PI) / 180.0;
    const lat2 = (21.4225 * Math.PI) / 180.0;
    const dLng = ((39.8262 - currentCity.lng) * Math.PI) / 180.0;

    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    const bearing = ((Math.atan2(y, x) * 180.0) / Math.PI + 360.0) % 360.0;
    const bearingInt = Math.round(bearing);

    // Distance calculation
    const dLat = lat2 - lat1;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const dist = Math.round(6371.0 * c);

    let cardinal = 'شرقاً (E)';
    if (bearing >= 70 && bearing <= 110) cardinal = 'شرقاً - جنوب شرق (ESE)';
    else if (bearing > 110 && bearing <= 160) cardinal = 'جنوب شرق (SE)';

    return {
      qiblaBearing: bearingInt,
      distanceKm: dist,
      cardinalDirection: cardinal,
    };
  }, [currentCity]);

  if (!isOpen) return null;

  const handleTestCarAudio = () => {
    setIsTestingAudio(true);
    audioAdhanService.playAdhanChime('اختبار صوت السيارة', 'سماعات السيارة (Android Auto)');
    setTimeout(() => setIsTestingAudio(false), 5000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300 font-['Cairo',sans-serif]">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-[#181720] via-[#121118] to-[#0D0C12] border border-[#C5A059]/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-black/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-[#C5A059]/30 to-[#C5A059]/10 border border-[#C5A059]/50 text-[#C5A059] shadow-inner">
              <Car className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white">
                  شاشة السيارة (Android Auto)
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  متوافق 100%
                </span>
              </div>
              <p className="text-xs text-white/60">
                عرض مواقيت الصلاة والقبلة تلقائياً على شاشة لوحة قيادة سيارتك
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white/50 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-6 flex-1 text-right">
          {/* 1. Realistic Android Auto Head-Unit Screen Simulator */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-white/60 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>معاينة حية لما يظهر على شاشة سيارتك:</span>
              </span>
              <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10 text-xs">
                <button
                  onClick={() => setActiveCarTab('prayers')}
                  className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                    activeCarTab === 'prayers'
                      ? 'bg-[#C5A059] text-black font-bold shadow-md'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  المواقيت
                </button>
                <button
                  onClick={() => setActiveCarTab('qibla')}
                  className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                    activeCarTab === 'qibla'
                      ? 'bg-[#C5A059] text-black font-bold shadow-md'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  القبلة
                </button>
                <button
                  onClick={() => setActiveCarTab('audio')}
                  className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                    activeCarTab === 'audio'
                      ? 'bg-[#C5A059] text-black font-bold shadow-md'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  صوت السيارة
                </button>
              </div>
            </div>

            {/* Car Bezel Frame */}
            <div className="relative rounded-3xl p-3 bg-gradient-to-b from-[#2A2A32] via-[#1E1E24] to-[#141418] border-4 border-[#33333E] shadow-[0_20px_50px_rgba(0,0,0,0.9)]">
              {/* Automotive Touchscreen Display */}
              <div className="relative bg-[#0F0E14] border border-white/10 rounded-2xl p-4 overflow-hidden min-h-[260px] flex flex-col justify-between">
                {/* Car Screen Top Bar (Android Auto Header) */}
                <div className="flex items-center justify-between pb-3 border-b border-white/10 text-xs text-white/80">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                    <span className="font-bold text-emerald-400">Android Auto • متصل</span>
                  </div>
                  <div className="flex items-center gap-3 text-white/60">
                    <span>{currentCity.nameAr} 🇲🇦</span>
                    <span>12:45</span>
                    <Wifi className="w-3.5 h-3.5 text-white/60" />
                  </div>
                </div>

                {/* Simulated Content Based on Tab */}
                {activeCarTab === 'prayers' && (
                  <div className="py-3 space-y-3">
                    {/* Next prayer highlight box in car screen */}
                    <div className="flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-[#C5A059]/20 via-[#C5A059]/10 to-transparent border border-[#C5A059]/40">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-lg bg-[#C5A059] text-black font-bold">
                          <Clock className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs text-[#C5A059] font-bold">
                            الصلاة القادمة: {nextPrayer?.nameAr || 'الظهر'}
                          </p>
                          <p className="text-[11px] text-white/70">
                            الوقت المتبقي: {countdownStr || '01:23:45'}
                          </p>
                        </div>
                      </div>
                      <span className="text-base font-extrabold text-[#C5A059]">
                        {nextPrayer?.time || '13:20'}
                      </span>
                    </div>

                    {/* 5 Prayers Grid on Car Screen */}
                    <div className="grid grid-cols-5 gap-1.5 text-center">
                      {prayers
                        .filter((p) => p.id !== 'sunrise')
                        .map((p) => {
                          const isNext = nextPrayer?.id === p.id;
                          return (
                            <div
                              key={p.id}
                              className={`p-2 rounded-xl border transition-all ${
                                isNext
                                  ? 'bg-[#C5A059]/20 border-[#C5A059] text-white font-bold scale-105 shadow-lg'
                                  : 'bg-white/5 border-white/5 text-white/70'
                              }`}
                            >
                              <p className="text-[11px] font-semibold">{p.nameAr}</p>
                              <p className="text-xs font-mono font-bold mt-1 text-[#C5A059]">
                                {p.time}
                              </p>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                )}

                {activeCarTab === 'qibla' && (
                  <div className="py-3 flex items-center justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                        <Navigation className="w-3.5 h-3.5 rotate-45 text-emerald-400" />
                        <span>زاوية القبلة: {qiblaBearing}°</span>
                      </div>
                      <h4 className="text-sm font-bold text-white">
                        الاتجاه: {cardinalDirection}
                      </h4>
                      <p className="text-xs text-white/70 leading-relaxed">
                        المسافة إلى الكعبة المشرفة بمكة المكرمة: <strong>{distanceKm.toLocaleString()} كم</strong>.
                      </p>
                      <div className="p-2 rounded-lg bg-black/40 border border-white/10 text-[11px] text-[#C5A059]">
                        🚗 عند ركن السيارة، اجعل مقدمتها متجهة بزاوية {qiblaBearing}° شرقاً لأداء الصلاة.
                      </div>
                    </div>

                    {/* Compass Gauge Graphic */}
                    <div className="w-28 h-28 rounded-full border-2 border-dashed border-[#C5A059]/50 flex items-center justify-center relative shrink-0 bg-black/50 shadow-inner">
                      <span className="absolute top-1 text-[9px] font-bold text-white/50">N</span>
                      <span className="absolute right-1 text-[9px] font-bold text-white/50">E</span>
                      <span className="absolute bottom-1 text-[9px] font-bold text-white/50">S</span>
                      <span className="absolute left-1 text-[9px] font-bold text-white/50">W</span>
                      <div
                        className="transition-transform duration-700 flex flex-col items-center justify-center"
                        style={{ transform: `rotate(${qiblaBearing}deg)` }}
                      >
                        <KaabaIcon className="w-7 h-7 text-[#C5A059] filter drop-shadow-[0_0_8px_rgba(197,160,89,0.8)]" />
                        <div className="w-1.5 h-6 bg-gradient-to-b from-[#C5A059] to-transparent rounded-full" />
                      </div>
                    </div>
                  </div>
                )}

                {activeCarTab === 'audio' && (
                  <div className="py-4 text-center space-y-3">
                    <div className="w-12 h-12 rounded-full bg-[#C5A059]/20 border border-[#C5A059]/40 flex items-center justify-center mx-auto text-[#C5A059]">
                      <Volume2 className="w-6 h-6 animate-bounce" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        بث الأذان عبر نظام الصوت وسماعات السيارة
                      </h4>
                      <p className="text-xs text-white/70 max-w-sm mx-auto mt-1">
                        يرتفع صوت الأذان تلقائياً عبر نظام صوت السيارة المحيطي عند حلول وقت الصلاة، مع إيقاف صوت الراديو أو الوسائط مؤقتاً.
                      </p>
                    </div>
                    <button
                      onClick={handleTestCarAudio}
                      className="px-4 py-2 rounded-xl bg-[#C5A059] hover:bg-[#d4b065] text-black font-bold text-xs shadow-lg transition-transform active:scale-95 cursor-pointer"
                    >
                      {isTestingAudio ? 'جاري الاختبار في السماعات...' : '🔊 تجربة صوت الأذان في السيارة'}
                    </button>
                  </div>
                )}

                {/* Car Screen Bottom Bar */}
                <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-white/50">
                  <span>تطبيق صلاتك للمغرب • مدمج رسمياً مع Android Auto</span>
                  <span className="text-[#C5A059]">الخدمة نشطة دائماً</span>
                </div>
              </div>
            </div>
          </div>

          {/* 2. Step-by-Step Connection Guide */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-[#C5A059] flex items-center gap-2">
              <Cable className="w-4 h-4" />
              <span>كيفية تشغيل وعرض التطبيق في سيارتك:</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs">
                  1
                </div>
                <h5 className="text-xs font-bold text-white">التوصيل بالسيارة</h5>
                <p className="text-[11px] text-white/70 leading-relaxed">
                  قم بتوصيل هاتفك بمنفذ USB في السيارة، أو اتصل لاسلكياً عبر بلوتوث وشبكة Wi-Fi للسيارة.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs">
                  2
                </div>
                <h5 className="text-xs font-bold text-white">فتح شاشة Android Auto</h5>
                <p className="text-[11px] text-white/70 leading-relaxed">
                  ستظهر شاشة Android Auto على لوحة قيادة السيارة. ستجد أيقونة تطبيق <strong>صلاتك</strong> في قائمة التطبيقات.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs">
                  3
                </div>
                <h5 className="text-xs font-bold text-white">المواقيت والقبلة المباشرة</h5>
                <p className="text-[11px] text-white/70 leading-relaxed">
                  تظهر مواقيت الصلاة والعد التنازلي واتجاه القبلة أثناء القيادة، ويرتفع الأذان عبر مكبرات صوت السيارة.
                </p>
              </div>
            </div>
          </div>

          {/* 3. Native Technical Integration Details */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-emerald-900/20 to-transparent border border-emerald-500/30 text-xs text-white/80 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <CheckCircle2 className="w-4 h-4" />
              <span>جاهزية الخدمة الأصلية في ملف APK (Android Auto App Service)</span>
            </div>
            <p className="text-[11px] text-white/70 leading-relaxed">
              تم تضمين خدمة <code>SalatCarAppService</code> و <code>PrayerTimesCarScreen</code> و <code>QiblaCarScreen</code> و <code>automotive_app_desc.xml</code> ومكتبة <code>androidx.car.app:app:1.4.0</code> داخل كود الأندرويد الأصلي لتطبيقك، مما يضمن التعرف التلقائي على التطبيق عند وصله بأي سيارة تدعم Android Auto.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-white/10 bg-black/40 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl bg-gradient-to-r from-[#C5A059] to-[#9E7B35] text-black font-bold text-xs hover:brightness-110 active:scale-95 transition-all shadow-md cursor-pointer"
          >
            إغلاق
          </button>
          <span className="text-xs text-white/50">
            صلاتك • رفيق المسلم أثناء القيادة والأسفار
          </span>
        </div>
      </div>
    </div>
  );
};
