import React, { useState, useEffect } from 'react';
import { X, Play, Square, Check, Volume2, Sparkles, MapPin } from 'lucide-react';
import { MUEZZINS_LIST, MuezzinItem } from '../../data/muezzinsData';
import { audioAdhanService, AdhanPlaybackState } from '../../services/audioAdhan';
import { useLanguage } from '../../context/LanguageContext';

interface MuezzinSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedMuezzinId: string;
  onSelectMuezzin: (muezzinId: string) => void;
  targetPrayerName?: string;
}

export const MuezzinSelectorModal: React.FC<MuezzinSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedMuezzinId,
  onSelectMuezzin,
  targetPrayerName,
}) => {
  const { language, t } = useLanguage();
  const [playbackState, setPlaybackState] = useState<AdhanPlaybackState>(() =>
    audioAdhanService.getPlaybackState()
  );
  const [filter, setFilter] = useState<'all' | 'morocco' | 'haramein' | 'fajr' | 'world'>('all');
  const [justSelectedName, setJustSelectedName] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = audioAdhanService.subscribe((state) => {
      setPlaybackState(state);
    });
    return unsubscribe;
  }, []);

  if (!isOpen) return null;

  const handleTogglePlay = (muezzin: MuezzinItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (playbackState.isPlaying && playbackState.activeId === muezzin.id) {
      audioAdhanService.stopRealAdhan();
    } else {
      audioAdhanService.playRealAdhan(
        muezzin.audioUrl,
        muezzin.id,
        muezzin.nameAr,
        muezzin.muezzinName
      );
    }
  };

  const handleSelect = (muezzin: MuezzinItem) => {
    onSelectMuezzin(muezzin.id);
    audioAdhanService.playClickSound();
    setJustSelectedName(muezzin.nameAr);
    setTimeout(() => {
      setJustSelectedName(null);
    }, 2500);
  };

  const filteredMuezzins = MUEZZINS_LIST.filter((item) => {
    if (filter === 'morocco') return item.id.includes('moroccan');
    if (filter === 'haramein') return item.id.includes('makkah') || item.id.includes('madinah') || item.id.includes('deghreri');
    if (filter === 'fajr') return item.isFajr;
    if (filter === 'world') return !item.id.includes('moroccan') && !item.id.includes('makkah') && !item.id.includes('madinah');
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-lg bg-[#181818] border border-white/10 rounded-3xl p-5 shadow-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-[#C5A059]" />
            <div>
              <h3 className="text-xl font-bold text-white font-['Cairo',sans-serif]">
                {language === 'en' ? 'Muezzins of the Islamic World' : 'أصوات ومؤذنو العالم الإسلامي'}
              </h3>
              {targetPrayerName ? (
                <span className="text-xs text-[#C5A059]">
                  {language === 'en' ? `Dedicated Adhan for: ${targetPrayerName}` : `تخصيص أذان: صلاة ${targetPrayerName}`}
                </span>
              ) : (
                <span className="text-xs text-white/50">
                  {language === 'en' ? 'Choose your preferred Adhan sound for prayers' : 'اختر الأذان المفضل لديك ليعمل لجميع الصلوات'}
                </span>
              )}
            </div>
          </div>
          <button
            onClick={() => {
              audioAdhanService.stopRealAdhan();
              onClose();
            }}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors cursor-pointer"
            title={t.close}
            aria-label={t.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success toast notification */}
        {justSelectedName && (
          <div className="my-2 p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center animate-in fade-in slide-in-from-top-2 duration-200 flex items-center justify-center gap-1.5">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>
              {language === 'en' ? `Activated ${justSelectedName} successfully! 🔊` : `تم تفعيل ${justSelectedName} بنجاح! 🔊`}
            </span>
          </div>
        )}

        {/* Filter Pills */}
        <div className="flex gap-1.5 my-3 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', label: language === 'en' ? 'All (12)' : 'كافة المؤذنين (12)' },
            { id: 'morocco', label: language === 'en' ? 'Morocco 🇲🇦' : 'المغرب الأقصى 🇲🇦' },
            { id: 'haramein', label: language === 'en' ? 'Two Holy Mosques 🕋' : 'الحرمين الشريفين 🕋' },
            { id: 'world', label: language === 'en' ? 'Islamic World 🌍' : 'العالم الإسلامي 🌍' },
            { id: 'fajr', label: language === 'en' ? 'Fajr (Tatweeb) 🌅' : 'أذان الفجر (التثويب) 🌅' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as typeof filter)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                filter === tab.id
                  ? 'bg-[#C5A059] text-black shadow'
                  : 'bg-white/5 text-white/60 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Muezzins List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {filteredMuezzins.map((muezzin) => {
            const isPlayingThis =
              playbackState.isPlaying && playbackState.activeId === muezzin.id;
            const isSelected = selectedMuezzinId === muezzin.id;

            return (
              <div
                key={muezzin.id}
                onClick={() => handleSelect(muezzin)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer group ${
                  isPlayingThis
                    ? 'bg-[#C5A059]/15 border-[#C5A059] shadow-[0_0_20px_rgba(197,160,89,0.15)]'
                    : isSelected
                    ? 'bg-gradient-to-r from-[#C5A059]/20 via-[#232323] to-[#1c1c1c] border-[#C5A059]'
                    : 'bg-[#202020] border-white/5 hover:border-[#C5A059]/40 hover:bg-[#252525]'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  {/* Play / Stop Button */}
                  <button
                    onClick={(e) => handleTogglePlay(muezzin, e)}
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 transition-all active:scale-95 cursor-pointer ${
                      isPlayingThis
                        ? 'bg-[#C5A059] text-black shadow-lg animate-pulse'
                        : 'bg-white/10 hover:bg-[#C5A059]/30 text-[#C5A059]'
                    }`}
                    title={isPlayingThis ? t.stopPreview : t.playPreview}
                    aria-label={isPlayingThis ? t.stopPreview : t.playPreview}
                  >
                    {isPlayingThis ? (
                      <Square className="w-5 h-5 fill-black" />
                    ) : (
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    )}
                  </button>

                  {/* Info */}
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h4 className="text-sm font-bold text-white font-['Cairo',sans-serif] group-hover:text-[#C5A059] transition-colors">
                        {muezzin.nameAr}
                      </h4>
                      {muezzin.isFajr && (
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.2 rounded">
                          {language === 'en' ? 'Fajr Only' : 'خاص بالفجر'}
                        </span>
                      )}
                      {isSelected && (
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-1.5 py-0.2 rounded flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-400" />
                          {language === 'en' ? 'Active' : 'المعتمد'}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-xs text-[#C5A059] mt-0.5">
                      <MapPin className="w-3 h-3" />
                      <span>{muezzin.locationAr}</span>
                      <span className="text-white/30">•</span>
                      <span className="text-white/60">{muezzin.muezzinName}</span>
                    </div>

                    <p className="text-[11px] text-white/50 mt-1 leading-relaxed">
                      {muezzin.descriptionAr}
                    </p>
                  </div>
                </div>

                {/* Footer Selection Button */}
                <div className="mt-2.5 pt-2 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[11px] text-white/40">
                    {isPlayingThis
                      ? (language === 'en' ? '🔊 Playing preview now...' : '🔊 جاري الاستماع الآن...')
                      : (language === 'en' ? '⚡ Available offline' : '⚡ متاح للاستخدام دون إنترنت')}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelect(muezzin);
                    }}
                    className={`flex items-center gap-1 px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-sm'
                        : 'bg-white/5 text-white/70 hover:bg-[#C5A059] hover:text-black'
                    }`}
                  >
                    {isSelected ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{language === 'en' ? 'Active Adhan ✓' : 'الأذان المعتمد ✓'}</span>
                      </>
                    ) : (
                      <span>{language === 'en' ? 'Select & Activate' : 'اختيار وتفعيل هذا الأذان'}</span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom confirmation */}
        <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={() => {
              audioAdhanService.stopRealAdhan();
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-[#C5A059] text-black font-bold text-sm hover:bg-[#d8b56f] transition-all cursor-pointer shadow-md"
          >
            {language === 'en' ? 'Confirm & Close' : 'تأكيد وإغلاق'}
          </button>
        </div>
      </div>
    </div>
  );
};
