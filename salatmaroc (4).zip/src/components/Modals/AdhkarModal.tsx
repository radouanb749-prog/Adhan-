import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  RotateCcw,
  Sparkles,
  Sun,
  Moon,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Share2,
  Copy,
  Check,
  ListFilter,
  Layers,
} from 'lucide-react';
import { MORNING_ADHKAR, EVENING_ADHKAR, AFTER_PRAYER_ADHKAR } from '../../data/adhkarData';
import { DhikrItem } from '../../types/prayer';
import { audioAdhanService } from '../../services/audioAdhan';

export type AdhkarCategory = 'morning' | 'evening' | 'after_prayer';

interface AdhkarModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCategory?: AdhkarCategory;
}

export const AdhkarModal: React.FC<AdhkarModalProps> = ({ isOpen, onClose, initialCategory = 'morning' }) => {
  // Main view modes: 'carousel' (تمرير بين الأذكار مع عداد) or 'tasbih' (السبحة الذكية)
  const [activeTab, setActiveTab] = useState<'adhkar' | 'tasbih'>('adhkar');
  const [selectedCategory, setSelectedCategory] = useState<AdhkarCategory>(initialCategory);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [viewStyle, setViewStyle] = useState<'card' | 'list'>('card');

  // Sync category when initialCategory prop changes
  useEffect(() => {
    if (initialCategory) {
      setSelectedCategory(initialCategory);
      setActiveTab('adhkar');
    }
  }, [initialCategory, isOpen]);

  // Adhkar counter tracker: { [dhikrId]: count }
  const [dhikrProgress, setDhikrProgress] = useState<Record<string, number>>({});

  // Digital Tasbih state
  const [tasbihCount, setTasbihCount] = useState<number>(0);
  const [selectedPhrase, setSelectedPhrase] = useState<string>('سُبْحَانَ اللَّهِ');

  // Copied indicator
  const [copied, setCopied] = useState<boolean>(false);

  // Touch swipe support
  const touchStartXRef = useRef<number | null>(null);
  const touchEndXRef = useRef<number | null>(null);

  // Active items based on category
  const activeAdhkarList: DhikrItem[] =
    selectedCategory === 'morning'
      ? MORNING_ADHKAR
      : selectedCategory === 'evening'
      ? EVENING_ADHKAR
      : AFTER_PRAYER_ADHKAR;

  // Reset index when category changes
  useEffect(() => {
    setCurrentIndex(0);
  }, [selectedCategory]);

  const currentDhikr = activeAdhkarList[currentIndex] || activeAdhkarList[0];
  const currentCount = dhikrProgress[currentDhikr?.id] || 0;
  const isCurrentCompleted = currentCount >= (currentDhikr?.count || 1);

  // Next & Prev handlers
  const handleNext = useCallback(() => {
    if (currentIndex < activeAdhkarList.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Loop or stay
      setCurrentIndex(0);
    }
  }, [currentIndex, activeAdhkarList.length]);

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    } else {
      setCurrentIndex(activeAdhkarList.length - 1);
    }
  }, [currentIndex, activeAdhkarList.length]);

  // Handle counter click for current dhikr
  const handleCounterClick = useCallback(() => {
    if (!currentDhikr) return;
    const req = currentDhikr.count;
    const nowCount = dhikrProgress[currentDhikr.id] || 0;

    if (nowCount < req) {
      const nextCount = nowCount + 1;
      setDhikrProgress((prev) => ({
        ...prev,
        [currentDhikr.id]: nextCount,
      }));

      audioAdhanService.playClickSound();
      if (navigator.vibrate) {
        navigator.vibrate(35);
      }

      // Check if just reached goal
      if (nextCount === req) {
        if (navigator.vibrate) {
          navigator.vibrate([100, 50, 150]);
        }
        audioAdhanService.playQiblaAlignedTone();

        // Auto advance to next after 800ms if not on last item
        if (currentIndex < activeAdhkarList.length - 1) {
          setTimeout(() => {
            handleNext();
          }, 850);
        }
      }
    }
  }, [currentDhikr, dhikrProgress, currentIndex, activeAdhkarList.length, handleNext]);

  // Reset current dhikr counter
  const handleResetCurrent = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentDhikr) return;
    setDhikrProgress((prev) => ({
      ...prev,
      [currentDhikr.id]: 0,
    }));
    audioAdhanService.playClickSound();
  };

  // Touch swipe events
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndXRef.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartXRef.current === null || touchEndXRef.current === null) return;
    const diff = touchStartXRef.current - touchEndXRef.current;
    // In RTL: swipe left goes to next (diff > 50), swipe right goes to prev (diff < -50)
    if (diff > 50) {
      handleNext();
    } else if (diff < -50) {
      handlePrev();
    }
    touchStartXRef.current = null;
    touchEndXRef.current = null;
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareText = async (text: string, title: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text,
        });
      } catch {
        // cancelled
      }
    } else {
      handleCopyText(text);
    }
  };

  // Keyboard navigation (Arrow keys)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen || activeTab !== 'adhkar') return;
      if (e.key === 'ArrowLeft') {
        handleNext();
      } else if (e.key === 'ArrowRight') {
        handlePrev();
      } else if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        handleCounterClick();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, activeTab, handleNext, handlePrev, handleCounterClick]);

  if (!isOpen) return null;

  const tasbihPhrases = [
    'سُبْحَانَ اللَّهِ',
    'الْحَمْدُ لِلَّهِ',
    'لاَ إِلَهَ إِلاَّ اللَّهُ',
    'اللَّهُ أَكْبَرُ',
    'أَسْتَغْفِرُ اللَّهَ',
    'لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ',
    'اللَّهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّدٍ',
  ];

  const handleTasbihClick = () => {
    setTasbihCount((prev) => prev + 1);
    audioAdhanService.playClickSound();
    if (navigator.vibrate) {
      navigator.vibrate(30);
    }
  };

  // Progress percentage for circular ring
  const progressPercent = currentDhikr ? Math.min(100, Math.round((currentCount / currentDhikr.count) * 100)) : 0;
  const strokeDashoffset = 100 - progressPercent;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-sm select-none">
      <div className="relative w-full max-w-lg bg-[#181818] border border-white/10 rounded-3xl p-4 sm:p-5 shadow-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#C5A059]" />
            <h3 className="text-xl font-bold text-white font-['Cairo',sans-serif]">
              أذكار الصباح والمساء
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main Tab Switch: أذكار الصباح والمساء vs السبحة الذكية */}
        <div className="flex gap-2 my-2.5 bg-[#121212] p-1 rounded-xl border border-white/5">
          <button
            onClick={() => setActiveTab('adhkar')}
            className={`flex-1 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'adhkar'
                ? 'bg-[#C5A059] text-black shadow-md'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>الأذكار اليومية</span>
          </button>
          <button
            onClick={() => setActiveTab('tasbih')}
            className={`flex-1 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'tasbih'
                ? 'bg-[#C5A059] text-black shadow-md'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <span>السبحة الذكية</span>
          </button>
        </div>

        {/* Adhkar Content */}
        {activeTab === 'adhkar' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Category Selector Pills */}
            <div className="flex items-center justify-between gap-1.5 pb-2">
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1 flex-1">
                <button
                  onClick={() => setSelectedCategory('morning')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                    selectedCategory === 'morning'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow'
                      : 'bg-white/5 text-white/60 hover:text-white border border-transparent'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>أذكار الصباح</span>
                </button>

                <button
                  onClick={() => setSelectedCategory('evening')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                    selectedCategory === 'evening'
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow'
                      : 'bg-white/5 text-white/60 hover:text-white border border-transparent'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5 text-indigo-400" />
                  <span>أذكار المساء</span>
                </button>

                <button
                  onClick={() => setSelectedCategory('after_prayer')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                    selectedCategory === 'after_prayer'
                      ? 'bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/40 shadow'
                      : 'bg-white/5 text-white/60 hover:text-white border border-transparent'
                  }`}
                >
                  <span>بعد الصلاة</span>
                </button>
              </div>

              {/* View mode toggle (Card Swipe vs Full List) */}
              <button
                onClick={() => setViewStyle((prev) => (prev === 'card' ? 'list' : 'card'))}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 hover:text-[#C5A059] transition-colors"
                title={viewStyle === 'card' ? 'عرض القائمة الكاملة' : 'وضع البطاقات والتمرير'}
              >
                {viewStyle === 'card' ? (
                  <ListFilter className="w-4 h-4" />
                ) : (
                  <Layers className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Mode 1: Swipeable Card Carousel with Counter */}
            {viewStyle === 'card' && currentDhikr && (
              <div
                className="flex-1 flex flex-col justify-between overflow-hidden pt-1"
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
              >
                {/* Progress bar and index tracker */}
                <div className="flex items-center justify-between text-xs text-white/50 mb-2 px-1">
                  <span>
                    الذكر <strong className="text-[#C5A059]">{currentIndex + 1}</strong> من{' '}
                    {activeAdhkarList.length}
                  </span>

                  {/* Visual Progress Dots */}
                  <div className="flex items-center gap-1">
                    {activeAdhkarList.slice(0, 10).map((_, i) => {
                      const isDone = (dhikrProgress[activeAdhkarList[i]?.id] || 0) >= activeAdhkarList[i]?.count;
                      return (
                        <span
                          key={i}
                          className={`h-1.5 rounded-full transition-all ${
                            i === currentIndex
                              ? 'w-5 bg-[#C5A059]'
                              : isDone
                              ? 'w-2 bg-emerald-400'
                              : 'w-1.5 bg-white/20'
                          }`}
                        />
                      );
                    })}
                    {activeAdhkarList.length > 10 && (
                      <span className="text-[10px] text-white/40">...</span>
                    )}
                  </div>
                </div>

                {/* Main Dhikr Card with subtle Islamic border */}
                <div
                  onClick={handleCounterClick}
                  className={`relative flex-1 flex flex-col justify-between p-4 sm:p-5 rounded-2xl bg-[#222222] border transition-all cursor-pointer shadow-lg overflow-y-auto ${
                    isCurrentCompleted
                      ? 'border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.15)] bg-gradient-to-b from-[#222222] to-emerald-950/20'
                      : 'border-white/10 hover:border-[#C5A059]/40'
                  }`}
                >
                  {/* Virtue tag */}
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-semibold text-[#C5A059] bg-[#C5A059]/10 px-2.5 py-0.5 rounded-full">
                      تكرار مطلوب: {currentDhikr.count} {currentDhikr.count === 1 ? 'مرة' : 'مرات'}
                    </span>

                    {isCurrentCompleted && (
                      <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>اكتمل التكرار</span>
                      </span>
                    )}
                  </div>

                  {/* Dhikr Arabic Text */}
                  <div className="my-auto py-2">
                    <p className="text-base sm:text-lg text-white/95 leading-relaxed font-['Amiri',serif] font-medium text-justify [text-align-last:center]">
                      {currentDhikr.arabic}
                    </p>
                  </div>

                  {/* Virtue & Reference */}
                  <div className="mt-3 pt-2 border-t border-white/5 space-y-1">
                    {currentDhikr.virtue && (
                      <p className="text-xs text-amber-200/70 font-['Cairo',sans-serif]">
                        ★ {currentDhikr.virtue}
                      </p>
                    )}
                    {currentDhikr.reference && (
                      <p className="text-[11px] text-white/40 font-['Cairo',sans-serif]">
                        {currentDhikr.reference}
                      </p>
                    )}
                  </div>
                </div>

                {/* Big Interactive Encouraging Counter & Navigation Bar */}
                <div className="mt-3 flex items-center justify-between gap-3 pt-1">
                  {/* Next Arrow Button */}
                  <button
                    onClick={handleNext}
                    className="p-3 rounded-2xl bg-white/5 hover:bg-[#C5A059]/20 text-[#C5A059] transition-all active:scale-90"
                    title="الذكر التالي (أو اسحب للشمال)"
                  >
                    <ChevronLeft className="w-6 h-6 stroke-[2.5]" />
                  </button>

                  {/* Interactive Circular Counter Button */}
                  <button
                    onClick={handleCounterClick}
                    className={`flex-1 relative flex items-center justify-center gap-3 py-3 px-5 rounded-2xl border transition-all active:scale-95 shadow-md ${
                      isCurrentCompleted
                        ? 'bg-emerald-950/40 border-emerald-500/60 text-emerald-300'
                        : 'bg-[#C5A059] hover:bg-[#d8b56f] text-black border-[#C5A059]'
                    }`}
                  >
                    {/* Ring indicator */}
                    <div className="relative w-8 h-8 flex items-center justify-center">
                      <svg className="w-8 h-8 -rotate-90" viewBox="0 0 36 36">
                        <path
                          className={isCurrentCompleted ? 'text-emerald-800' : 'text-black/20'}
                          strokeWidth="4"
                          stroke="currentColor"
                          fill="none"
                          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        />
                        <path
                          className={isCurrentCompleted ? 'text-emerald-400' : 'text-black'}
                          strokeDasharray="100, 100"
                          strokeDashoffset={strokeDashoffset}
                          strokeWidth="4"
                          strokeLinecap="round"
                          stroke="currentColor"
                          fill="none"
                          d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        />
                      </svg>
                      <span className="absolute text-xs font-mono font-bold">
                        {currentCount}
                      </span>
                    </div>

                    <div className="flex flex-col items-start text-right">
                      <span className="text-sm font-bold font-['Cairo',sans-serif] leading-tight">
                        {isCurrentCompleted
                          ? 'مكتمل (انقر للتالي)'
                          : `انقر للعد (${currentCount} / ${currentDhikr.count})`}
                      </span>
                      <span className="text-[10px] opacity-80">
                        {isCurrentCompleted ? 'تقبل الله طاعتكم' : 'تكرار الذكر بالضغط'}
                      </span>
                    </div>
                  </button>

                  {/* Previous Arrow Button */}
                  <button
                    onClick={handlePrev}
                    className="p-3 rounded-2xl bg-white/5 hover:bg-[#C5A059]/20 text-[#C5A059] transition-all active:scale-90"
                    title="الذكر السابق (أو اسحب لليمين)"
                  >
                    <ChevronRight className="w-6 h-6 stroke-[2.5]" />
                  </button>
                </div>

                {/* Footer action bar */}
                <div className="flex items-center justify-between text-xs text-white/50 pt-2 px-1">
                  <button
                    onClick={handleResetCurrent}
                    className="flex items-center gap-1 hover:text-[#C5A059] transition-colors"
                  >
                    <RotateCcw className="w-3 h-3 text-[#C5A059]" />
                    <span>تصفير هذا الذكر</span>
                  </button>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleCopyText(currentDhikr.arabic)}
                      className="flex items-center gap-1 hover:text-[#C5A059] transition-colors"
                    >
                      {copied ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>نسخ</span>
                    </button>
                    <button
                      onClick={() => handleShareText(currentDhikr.arabic, currentDhikr.categoryAr)}
                      className="flex items-center gap-1 hover:text-[#C5A059] transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>مشاركة</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Mode 2: Full List of Adhkar */}
            {viewStyle === 'list' && (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 pt-1">
                {activeAdhkarList.map((dhikr, idx) => {
                  const count = dhikrProgress[dhikr.id] || 0;
                  const isDone = count >= dhikr.count;

                  return (
                    <div
                      key={dhikr.id}
                      onClick={() => {
                        setCurrentIndex(idx);
                        setViewStyle('card');
                      }}
                      className={`p-4 rounded-xl border transition-all cursor-pointer ${
                        isDone
                          ? 'bg-emerald-950/20 border-emerald-500/30'
                          : 'bg-[#222222] border-white/5 hover:border-[#C5A059]/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-[#C5A059] font-bold">
                          الذكر {idx + 1}
                        </span>
                        <span
                          className={`text-xs px-2.5 py-0.5 rounded-full font-mono font-bold ${
                            isDone
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-[#C5A059]/20 text-[#C5A059]'
                          }`}
                        >
                          {count} / {dhikr.count}
                        </span>
                      </div>
                      <p className="text-sm text-white/95 leading-relaxed font-['Amiri',serif]">
                        {dhikr.arabic}
                      </p>
                      {dhikr.virtue && (
                        <p className="text-[11px] text-white/50 mt-1.5 font-['Cairo',sans-serif]">
                          ★ {dhikr.virtue}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Digital Smart Tasbih */}
        {activeTab === 'tasbih' && (
          <div className="flex-1 flex flex-col items-center justify-center py-4">
            {/* Phrase Selector */}
            <div className="w-full flex gap-1.5 overflow-x-auto pb-2 mb-4 scrollbar-none">
              {tasbihPhrases.map((phrase) => (
                <button
                  key={phrase}
                  onClick={() => setSelectedPhrase(phrase)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    selectedPhrase === phrase
                      ? 'bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]'
                      : 'bg-white/5 text-white/60 hover:text-white border border-transparent'
                  }`}
                >
                  {phrase}
                </button>
              ))}
            </div>

            {/* Selected Phrase Display */}
            <div className="text-center mb-6">
              <h4 className="text-2xl font-bold text-white font-['Amiri',serif]">
                {selectedPhrase}
              </h4>
            </div>

            {/* Giant Circular Clicker Bead */}
            <button
              onClick={handleTasbihClick}
              className="relative w-48 h-48 rounded-full bg-gradient-to-b from-[#2A2A2A] to-[#141414] border-4 border-[#C5A059]/40 hover:border-[#C5A059] shadow-[0_0_35px_rgba(197,160,89,0.2)] flex flex-col items-center justify-center transition-all active:scale-95 group cursor-pointer"
            >
              <span className="text-5xl font-mono font-black text-white group-hover:text-[#C5A059] transition-colors">
                {tasbihCount}
              </span>
              <span className="text-xs text-white/40 mt-1">انقر للتسبيح</span>
            </button>

            {/* Reset Button */}
            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={() => setTasbihCount(0)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/60 hover:text-white text-xs font-medium transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>إعادة ضبط العداد</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
