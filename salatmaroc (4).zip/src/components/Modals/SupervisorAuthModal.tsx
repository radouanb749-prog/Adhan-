import React, { useState } from 'react';
import {
  Lock,
  KeyRound,
  Download,
  Eye,
  EyeOff,
  X,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  RotateCcw,
  Copy,
  ExternalLink,
  Check,
} from 'lucide-react';
import { adminAuthService } from '../../services/adminAuthService';
import { downloadAppZip, getZipDirectUrl } from '../../services/zipExportService';

interface SupervisorAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupervisorAuthModal: React.FC<SupervisorAuthModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Password change sub-mode
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [showNewPwd, setShowNewPwd] = useState(false);

  if (!isOpen) return null;

  const handleVerifyAndDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!password.trim()) {
      setErrorMsg('يرجى كتابة كلمة المرور للمتابعة');
      return;
    }

    const isValid = adminAuthService.verifyPassword(password);
    if (!isValid) {
      setErrorMsg('كلمة المرور غير صحيحة! الوصول لملف ZIP مخصص لمشرف المشروع فقط.');
      return;
    }

    // Success
    setIsVerified(true);
    setIsDownloading(true);
    setSuccessMsg('تم التحقق بنجاح من هوية المشرف! تم تجهيز ملف ZIP للتحميل المباشر.');

    try {
      await downloadAppZip();
    } catch {
      // Ignored
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyDirectUrl = () => {
    const url = getZipDirectUrl();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 3000);
      });
    }
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!adminAuthService.verifyPassword(currentPwd)) {
      setErrorMsg('كلمة المرور الحالية غير صحيحة!');
      return;
    }

    if (!newPwd || newPwd.trim().length < 3) {
      setErrorMsg('يجب أن تتكون كلمة المرور الجديدة من 3 أحرف أو أرقام على الأقل.');
      return;
    }

    if (newPwd !== confirmPwd) {
      setErrorMsg('كلمة المرور الجديدة وتأكيدها غير متطابقين!');
      return;
    }

    const updated = adminAuthService.setSupervisorPassword(newPwd);
    if (updated) {
      setSuccessMsg('تم حفظ وتحديث كلمة مرور المشرف بنجاح! يمكنك الآن استخدامها.');
      setCurrentPwd('');
      setNewPwd('');
      setConfirmPwd('');
      setTimeout(() => {
        setIsChangingPassword(false);
        setSuccessMsg(null);
      }, 2000);
    } else {
      setErrorMsg('تعذر حفظ كلمة المرور الجديدة، يرجى التحقق وإعادة المحاولة.');
    }
  };

  const handleResetToDefault = () => {
    adminAuthService.resetToDefault();
    setSuccessMsg('تمت استعادة كلمة المرور الافتراضية للمشرف (2026).');
    setErrorMsg(null);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const isCustomSet = adminAuthService.isCustomPasswordSet();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md select-none animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#16151E] border border-[#C5A059]/40 rounded-3xl p-6 shadow-2xl text-white relative animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon */}
        <div className="flex flex-col items-center text-center mb-5">
          <img
            src="/pwa-192x192.png"
            alt="شعار مواقيت الصلاة"
            className="w-16 h-16 rounded-2xl object-cover shadow-xl border-2 border-[#C5A059]/60 mb-2.5"
          />
          <h3 className="text-xl font-bold font-['Cairo',sans-serif] text-white flex items-center gap-2">
            <span>منطقة المشرف على المشروع</span>
            <Lock className="w-4 h-4 text-[#C5A059]" />
          </h3>
          <p className="text-xs text-white/60 mt-1">
            {isChangingPassword
              ? 'تعيين كلمة مرور خاصة من اختيارك لحماية كود المشروع'
              : 'تنزيل الكود المصدري الكامل للتطبيق كملف ZIP محمي بكلمة مرور'}
          </p>
        </div>

        {/* Feedback alerts */}
        {errorMsg && (
          <div className="flex items-center gap-2 p-3 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs mb-4 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span className="leading-relaxed">{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="flex items-center gap-2 p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs mb-4 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span className="leading-relaxed">{successMsg}</span>
          </div>
        )}

        {/* Main Mode: Verify & Download */}
        {!isChangingPassword ? (
          <form onSubmit={handleVerifyAndDownload} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-white/80 mb-2 font-['Cairo',sans-serif]">
                أدخل كلمة المرور الخاصة بالمشرف:
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="كلمة المرور..."
                  autoFocus
                  className="w-full bg-[#1F1E2A] border border-white/15 focus:border-[#C5A059] rounded-2xl px-4 py-3 text-sm text-white placeholder-white/30 outline-none transition-all pl-11 text-right font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-white/40 hover:text-white transition-colors cursor-pointer"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Default Password Hint if not changed */}
            {!isCustomSet && (
              <div className="p-3 rounded-2xl bg-[#C5A059]/10 border border-[#C5A059]/20 text-xs text-[#C5A059] flex items-center justify-between">
                <span>كلمة المرور الافتراضية لأول مرة هي: <strong>2026</strong></span>
                <span className="text-[10px] bg-[#C5A059]/20 px-2 py-0.5 rounded-full text-amber-200">
                  تلقائية
                </span>
              </div>
            )}

            {isVerified ? (
              <div className="space-y-3 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-right animate-in fade-in">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>تم تجهيز ملف المشروع الكامل (salatmaroc.zip)!</span>
                </div>
                <p className="text-xs text-white/70 leading-relaxed">
                  إذا منعت المعاينة التنزيل التلقائي بسبب قيود المتصفح، يمكنك التحميل مباشرة عبر الأزرار أدناه:
                </p>

                {/* Direct Link Tag Button */}
                <a
                  href="/salatmaroc.zip"
                  download="salatmaroc.zip"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:brightness-110 text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer block text-center active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل مباشر لملف ZIP (رابط مباشر)</span>
                </a>

                {/* Copy Direct Link Button */}
                <button
                  type="button"
                  onClick={handleCopyDirectUrl}
                  className="w-full py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white/90 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-white/10 active:scale-95"
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400">تم نسخ الرابط المباشر إلى الحافظة!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#C5A059]" />
                      <span>نسخ الرابط المباشر لفتحه في متصفح خارجي</span>
                    </>
                  )}
                </button>

                <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 text-[10px] text-white/50 font-mono break-all text-center select-all">
                  {getZipDirectUrl()}
                </div>
              </div>
            ) : (
              <button
                type="submit"
                disabled={isDownloading}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#C5A059] to-[#D4AF37] hover:from-[#d6b063] hover:to-[#e0bd49] text-black font-bold text-sm transition-all shadow-lg active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2"
              >
                {isDownloading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>جاري تجهيز وتنزيل ملف ZIP...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>تأكيد وتحميل ملف ZIP</span>
                  </>
                )}
              </button>
            )}

            {/* Switch to change password */}
            <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs text-white/60">
              <button
                type="button"
                onClick={() => {
                  setIsChangingPassword(true);
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }}
                className="hover:text-[#C5A059] transition-colors flex items-center gap-1.5 cursor-pointer py-1"
              >
                <KeyRound className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>تعيين أو تغيير كلمة المرور من اختيارك</span>
              </button>

              {isCustomSet && (
                <button
                  type="button"
                  onClick={handleResetToDefault}
                  title="استعادة كلمة المرور الافتراضية (2026)"
                  className="hover:text-amber-300 transition-colors flex items-center gap-1 cursor-pointer py-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span className="text-[10px]">استعادة الافتراضية</span>
                </button>
              )}
            </div>
          </form>
        ) : (
          /* Sub-mode: Change Password to supervisor's choice */
          <form onSubmit={handleChangePassword} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5">
                كلمة المرور الحالية:
              </label>
              <input
                type="password"
                value={currentPwd}
                onChange={(e) => setCurrentPwd(e.target.value)}
                placeholder="أدخل كلمة المرور الحالية (أو 2026 إذا لم تغيرها)..."
                autoFocus
                className="w-full bg-[#1F1E2A] border border-white/15 focus:border-[#C5A059] rounded-2xl px-4 py-2.5 text-sm text-white placeholder-white/30 outline-none transition-all text-right font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5">
                كلمة المرور الجديدة من اختيارك:
              </label>
              <div className="relative">
                <input
                  type={showNewPwd ? 'text' : 'password'}
                  value={newPwd}
                  onChange={(e) => setNewPwd(e.target.value)}
                  placeholder="اكتب كلمة المرور الجديدة التي تختارها..."
                  className="w-full bg-[#1F1E2A] border border-white/15 focus:border-[#C5A059] rounded-2xl px-4 py-2.5 text-sm text-white placeholder-white/30 outline-none transition-all pl-11 text-right font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPwd(!showNewPwd)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-1 text-white/40 hover:text-white transition-colors cursor-pointer"
                >
                  {showNewPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5">
                تأكيد كلمة المرور الجديدة:
              </label>
              <input
                type="password"
                value={confirmPwd}
                onChange={(e) => setConfirmPwd(e.target.value)}
                placeholder="أعد كتابة كلمة المرور الجديدة..."
                className="w-full bg-[#1F1E2A] border border-white/15 focus:border-[#C5A059] rounded-2xl px-4 py-2.5 text-sm text-white placeholder-white/30 outline-none transition-all text-right font-mono"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-[#C5A059] hover:bg-[#d6b063] text-black font-bold text-sm transition-all shadow-lg active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 mt-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>حفظ كلمة المرور الجديدة للمشرف</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsChangingPassword(false);
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className="w-full py-2 rounded-2xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white text-xs transition-colors cursor-pointer"
            >
              الرجوع لنافذة التحميل
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
