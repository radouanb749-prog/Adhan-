import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Volume2,
  VolumeX,
  Compass,
  Settings,
  Sun,
  Cloud,
  CloudSun,
  CloudRain,
  Wind,
  Droplets,
  X,
  Sparkles,
  Navigation,
  Loader2,
  Clock,
  SlidersHorizontal,
  RotateCcw,
  Check,
  Edit3,
  Languages,
  Share2,
} from 'lucide-react';
import mosqueBg from '../assets/images/hassan_ii_mosque.jpg';
import { CityData, PrayerTimeItem } from '../types/prayer';
import { audioAdhanService } from '../services/audioAdhan';
import { notificationService } from '../services/notificationService';
import { MUEZZINS_LIST } from '../data/muezzinsData';
import { ThemeToggleBtn } from './ThemeToggleBtn';
import { fetchLocalWeather, WeatherConditionInfo } from '../services/weatherService';
import { useLanguage } from '../context/LanguageContext';

interface HeaderHeroProps {
  nextPrayer?: PrayerTimeItem;
  countdownStr?: string;
  currentCity: CityData;
  timezoneMode: 'gmt' | 'gmt+1';
  animatedBackgroundEnabled?: boolean;
  onToggleTimezone: () => void;
  onOpenQibla: () => void;
  onOpenSettings?: () => void;
  onOpenShare?: () => void;
  muezzinId?: string;
  assignedMuezzins?: Record<string, string>;
  onAutoLocate?: () => void;
  isLocating?: boolean;
  prayers?: PrayerTimeItem[];
  manualNextPrayerId?: string | null;
  onSelectManualNextPrayer?: (prayerId: string | null) => void;
  currentPrayerOffset?: number;
  onAdjustRemainingOffset?: (delta: number) => void;
  onResetRemainingOffset?: () => void;
  isSilentModeEnabled?: boolean;
  onToggleSilentMode?: () => void;
}

export const HeaderHero: React.FC<HeaderHeroProps> = ({
  nextPrayer,
  countdownStr,
  currentCity,
  timezoneMode,
  animatedBackgroundEnabled = true,
  onToggleTimezone,
  onOpenQibla,
  onOpenSettings,
  onOpenShare,
  muezzinId,
  assignedMuezzins,
  onAutoLocate,
  isLocating = false,
  prayers,
  manualNextPrayerId,
  onSelectManualNextPrayer,
  currentPrayerOffset = 0,
  onAdjustRemainingOffset,
  onResetRemainingOffset,
  isSilentModeEnabled = false,
  onToggleSilentMode,
}) => {
  const [isPlayingAdhan, setIsPlayingAdhan] = useState(false);
  const [weather, setWeather] = useState<WeatherConditionInfo | null>(null);
  const [showWeatherDetails, setShowWeatherDetails] = useState(false);
  const [showPrayerSelector, setShowPrayerSelector] = useState(false);
  const [showTimeAdjust, setShowTimeAdjust] = useState(false);

  const { language, toggleLanguage, t } = useLanguage();

  useEffect(() => {
    return audioAdhanService.subscribe((state) => {
      setIsPlayingAdhan(state.isPlaying);
    });
  }, []);

  // Fetch local weather for the current city
  useEffect(() => {
    let isMounted = true;
    if (currentCity?.lat && currentCity?.lng) {
      fetchLocalWeather(currentCity.lat, currentCity.lng)
        .then((info) => {
          if (isMounted) setWeather(info);
        })
        .catch(() => {});
    }
    return () => {
      isMounted = false;
    };
  }, [currentCity?.lat, currentCity?.lng]);

  const getWeatherIcon = (code: number, isDay: boolean) => {
    if (code === 0) {
      return isDay ? (
        <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
      ) : (
        <Sparkles className="w-3.5 h-3.5 text-indigo-300 shrink-0" />
      );
    }
    if ([1, 2, 3].includes(code)) {
      return <CloudSun className="w-3.5 h-3.5 text-amber-300 shrink-0" />;
    }
    if ([61, 63, 65, 80, 81, 82, 95, 96, 99].includes(code)) {
      return <CloudRain className="w-3.5 h-3.5 text-sky-400 shrink-0" />;
    }
    return <Cloud className="w-3.5 h-3.5 text-sky-300 shrink-0" />;
  };

  const handlePlayAdhanPreview = () => {
    const assignedId =
      (nextPrayer && assignedMuezzins && assignedMuezzins[nextPrayer.id]) ||
      muezzinId ||
      'moroccan_traditional';
    const muezzin =
      MUEZZINS_LIST.find((m) => m.id === assignedId) || MUEZZINS_LIST[0];

    audioAdhanService.playRealAdhan(
      muezzin.audioUrl,
      'hero_adhan',
      nextPrayer ? `أذان صلاة ${nextPrayer.nameAr}` : muezzin.nameAr,
      muezzin.muezzinName
    );
  };

  return (
    <header className="relative w-full h-[375px] sm:h-[415px] overflow-hidden select-none">
      {/* Background Image: Hassan II Mosque Casablanca at blue hour night */}
      <img
        src={mosqueBg}
        alt="مسجد الحسن الثاني بالدار البيضاء"
        className="absolute inset-0 w-full h-full object-cover object-center scale-105 transition-transform duration-700 hover:scale-100"
      />

      {/* Atmospheric overlays for high contrast and luxury Islamic feel */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-[#121212]" />
      <div className="absolute inset-0 bg-radial from-transparent via-black/20 to-black/60" />

      {/* Calm Animated Clouds & Light Rays in Hero when enabled */}
      {animatedBackgroundEnabled !== false && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-[1]">
          <div className="absolute top-0 left-0 w-[200%] h-44 opacity-20 animate-cloud-drift-slow">
            <svg className="w-full h-full" viewBox="0 0 1440 320" preserveAspectRatio="none" fill="none">
              <path
                fill="rgba(255, 255, 255, 0.45)"
                d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,128C672,128,768,160,864,165.3C960,171,1056,149,1152,133.3C1248,117,1344,107,1392,101.3L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"
              />
            </svg>
          </div>
          <div className="absolute -top-16 left-1/3 w-36 h-[300px] bg-gradient-to-b from-[#C5A059]/15 via-[#C5A059]/5 to-transparent rotate-[25deg] blur-2xl animate-light-beam pointer-events-none" />
        </div>
      )}

      {/* Top action row */}
      <div className="relative z-10 flex items-center justify-between px-3 sm:px-4 pt-3.5 text-white/80 gap-1.5 flex-wrap">
        <div className="flex items-center gap-1.5">
          {isPlayingAdhan ? (
            <button
              onClick={() => {
                notificationService.stopAdhan();
                audioAdhanService.stopAll();
              }}
              title={language === 'en' ? 'Stop Adhan now' : 'إيقاف الأذان الآن'}
              className="px-3 py-1.5 rounded-full bg-red-600/90 hover:bg-red-700 backdrop-blur-md border border-red-400 text-white font-bold transition-all active:scale-95 flex items-center gap-1.5 text-xs cursor-pointer animate-pulse shadow-[0_0_18px_rgba(239,68,68,0.7)]"
            >
              <VolumeX className="w-4 h-4 text-white" />
              <span>{language === 'en' ? 'Stop Adhan ⏹' : 'إيقاف الأذان ⏹'}</span>
            </button>
          ) : (
            <>
              <button
                onClick={handlePlayAdhanPreview}
                title={language === 'en' ? 'Listen to Adhan' : 'استماع للأذان'}
                className="p-2 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:border-[#C5A059] text-white/90 hover:text-[#C5A059] transition-all active:scale-95 flex items-center gap-1.5 text-xs cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-[#C5A059]" />
                <span className="hidden sm:inline">{language === 'en' ? 'Adhan' : 'الأذان'}</span>
              </button>

              {/* Persistent Silent Mode Toggle & Permanent Icon */}
              <button
                onClick={onToggleSilentMode}
                title={
                  isSilentModeEnabled
                    ? (language === 'en' ? 'Silent Mode Active (Adhan muted) - Click to restore sound' : 'الوضع الصامت مفعل (الأذان مكتوم) - اضغط لإعادة تشغيل الصوت')
                    : (language === 'en' ? 'Click to activate Silent Mode (Mute Adhan)' : 'اضغط لتفعيل الوضع الصامت (كتم الأذان)')
                }
                className={`p-2 rounded-full backdrop-blur-md border transition-all active:scale-95 flex items-center gap-1 text-xs cursor-pointer ${
                  isSilentModeEnabled
                    ? 'bg-amber-500/25 border-amber-500/60 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                    : 'bg-black/40 border-white/10 text-white/60 hover:text-[#C5A059] hover:border-[#C5A059]/40'
                }`}
              >
                {isSilentModeEnabled ? (
                  <>
                    <VolumeX className="w-4 h-4 text-amber-400" />
                    <span className="text-[10px] font-bold text-amber-300 hidden sm:inline">
                      {language === 'en' ? 'Silent' : 'صامت'}
                    </span>
                  </>
                ) : (
                  <Volume2 className="w-4 h-4 text-white/60" />
                )}
              </button>
            </>
          )}

          {/* Automatic Day / Night Theme Switcher */}
          <ThemeToggleBtn />
        </div>

        <div className="flex items-center gap-1.5">
          {/* Language Switcher Icon Button (العربية / English) */}
          <button
            onClick={toggleLanguage}
            title={language === 'ar' ? 'Switch to English' : 'التحويل إلى العربية'}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:border-[#C5A059] text-white/90 hover:text-[#C5A059] transition-all active:scale-95 flex items-center gap-1.5 text-xs cursor-pointer font-bold"
          >
            <Languages className="w-4 h-4 text-[#C5A059]" />
            <span className="text-[11px] font-sans tracking-wide">
              {language === 'ar' ? 'EN' : 'عربي'}
            </span>
          </button>

          <button
            onClick={onOpenQibla}
            title={language === 'ar' ? 'اتجاه القبلة' : 'Qibla Direction'}
            className="p-2 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:border-[#C5A059] text-white/90 hover:text-[#C5A059] transition-all active:scale-95 flex items-center gap-1.5 text-xs cursor-pointer"
          >
            <Compass className="w-4 h-4 text-[#C5A059]" />
            <span className="hidden sm:inline">{t.qibla}</span>
          </button>

          {/* Share Button (Web Share API & Copy Link / Schedule) */}
          {onOpenShare && (
            <button
              onClick={onOpenShare}
              title={language === 'ar' ? 'مشاركة التطبيق ومواقيت الصلاة' : 'Share App & Schedule'}
              className="p-2 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:border-[#C5A059] text-white/90 hover:text-[#C5A059] transition-all active:scale-95 flex items-center gap-1.5 text-xs cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-[#C5A059]" />
            </button>
          )}

          {/* Settings Button */}
          {onOpenSettings && (
            <button
              onClick={onOpenSettings}
              title={language === 'ar' ? 'الإعدادات والموقع' : 'Settings'}
              className="p-2 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:border-[#C5A059] text-white/90 hover:text-[#C5A059] transition-all active:scale-95 flex items-center gap-1.5 text-xs cursor-pointer"
            >
              <Settings className="w-4 h-4 text-[#C5A059]" />
            </button>
          )}
        </div>
      </div>

      {/* Main Overlay Content: Quranic Verse & City Selector */}
      <div className="relative z-10 flex flex-col items-center justify-center h-[calc(100%-60px)] px-4 text-center my-auto -mt-1">
        <div className="max-w-md mx-auto flex flex-col items-center justify-center">
          {/* Holy Quran Verse in authentic Uthmani script: ﴿ إِنَّ الصَّلَاةَ كَانَتْ عَلَى الْمُؤْمِنِينَ كِتَابًا مَوْقُوتًا ﴾ */}
          <div className="flex flex-col items-center justify-center mb-3 animate-in fade-in duration-300">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-normal text-white font-quran-uthmani leading-[1.85] sm:leading-[1.95] drop-shadow-[0_4px_24px_rgba(0,0,0,0.95)] px-2 text-center tracking-wide">
              <span className="text-[#C5A059] opacity-90 select-none px-0.5">﴿</span>
              {' '}إِنَّ الصَّلَاةَ كَانَتْ عَلَى الْمُؤْمِنِينَ كِتَابًا مَوْقُوتًا{' '}
              <span className="text-[#C5A059] opacity-90 select-none px-0.5">﴾</span>
            </h1>
            <div className="text-[11px] sm:text-xs text-[#C5A059] font-medium tracking-wider drop-shadow-md mt-1 font-['Cairo',sans-serif]">
              سورة النساء • الآية ١٠٣
            </div>

            {/* City Name with Pin matching screenshot: المحمدية 📍 */}
            <button
              type="button"
              onClick={onAutoLocate}
              disabled={isLocating}
              className="flex items-center gap-1.5 text-base sm:text-lg font-semibold text-white/95 hover:text-[#C5A059] transition-all drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] cursor-pointer group mt-2 active:scale-95"
              title={language === 'en' ? 'Detect location and update prayer times' : 'تحديد الموقع الجغرافي وتحديث مواقيت الصلاة'}
            >
              <span>{language === 'en' ? (currentCity?.nameFr || currentCity?.nameAr || 'Mohammedia') : (currentCity?.nameAr || 'المحمدية')}</span>
              {isLocating ? (
                <Loader2 className="w-4 h-4 text-[#C5A059] animate-spin inline-block" />
              ) : (
                <MapPin className="w-4 h-4 text-[#C5A059] fill-[#C5A059] inline-block group-hover:scale-110 transition-transform" />
              )}
            </button>
          </div>

          {/* Next Prayer Badge & Remaining Time Countdown Pill */}
          {nextPrayer && (
            <div className="flex items-center justify-between gap-2 px-3.5 py-1.5 rounded-2xl bg-black/60 backdrop-blur-md border border-[#C5A059]/40 shadow-xl mb-2.5 max-w-sm sm:max-w-md w-full animate-in fade-in duration-200">
              {/* Next Prayer Name & Prayer Time */}
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
                <span className="text-xs sm:text-sm font-bold text-white/95">
                  {language === 'en'
                    ? nextPrayer.id === 'maghrib'
                      ? t.adhanMaghribIftar
                      : nextPrayer.id === 'fajr'
                      ? t.adhanFajrImsak
                      : `${nextPrayer.nameEn} Prayer`
                    : nextPrayer.id === 'maghrib'
                    ? 'أذان المغرب (الإفطار)'
                    : nextPrayer.id === 'fajr'
                    ? 'أذان الفجر (الإمساك)'
                    : `صلاة ${nextPrayer.nameAr}`}
                </span>
                <span className="text-xs sm:text-sm font-mono font-bold text-[#C5A059] bg-[#C5A059]/15 px-2 py-0.5 rounded-md">
                  {nextPrayer.time}
                </span>
              </div>

              {/* Left side: Remaining Time Countdown */}
              {countdownStr && (
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded-lg border border-amber-500/30 shadow-inner">
                  <span className="text-[10px] font-sans text-amber-200/80 font-normal">{t.remaining}</span>
                  <span className="dir-ltr tracking-wider font-bold">
                    {countdownStr.replace('-', '')}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Auxiliary Controls: Weather & Timezone Mode Badges */}
          <div className="flex items-center gap-2 flex-wrap justify-center relative mt-1.5">
            {/* Local Weather & Mosque Suitability Badge */}
            {weather && (
              <button
                type="button"
                onClick={() => setShowWeatherDetails(true)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/45 backdrop-blur-md border border-white/10 hover:border-[#C5A059]/60 text-white/95 text-xs sm:text-sm font-semibold transition-all cursor-pointer group active:scale-95 shadow-sm"
                title="انقر لعرض تفاصيل الطقس وتنبيه صلاة المسجد"
              >
                {getWeatherIcon(weather.weatherCode, weather.isDay)}
                <span className="font-mono">{weather.temp}°C</span>
                <span className="hidden xs:inline text-white/60 text-[11px]">
                  {weather.conditionText}
                </span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold border transition-colors ${
                    weather.mosqueSuitability.status === 'optimal'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      : weather.mosqueSuitability.status === 'difficult'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  }`}
                >
                  {weather.mosqueSuitability.badge}
                </span>
              </button>
            )}

            {/* Timezone Badge */}
            <button
              type="button"
              onClick={onToggleTimezone}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/45 backdrop-blur-md border border-[#C5A059]/30 hover:border-[#C5A059] text-xs text-[#C5A059] font-bold transition-all cursor-pointer active:scale-95"
              title="انقر للتبديل بين توقيت غرينتش الرسمي (GMT+0) والتوقيت الصيفي (GMT+1)"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>{timezoneMode === 'gmt' ? 'توقيت غرينتش (GMT)' : 'التوقيت الصيفي (GMT+1)'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Weather & Mosque Suitability Alert Detail Modal */}
      {showWeatherDetails && weather && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md"
          onClick={() => setShowWeatherDetails(false)}
        >
          <div
            className="w-full max-w-sm rounded-3xl p-5 border border-[#C5A059]/40 shadow-2xl bg-gradient-to-b from-[#1C1A27] via-[#161420] to-[#12111A] text-white relative animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setShowWeatherDetails(false)}
              className="absolute top-4 left-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30">
                {getWeatherIcon(weather.weatherCode, weather.isDay)}
              </div>
              <div>
                <h4 className="text-base font-bold font-['Cairo',sans-serif] flex items-center gap-1.5">
                  <span>طقس {currentCity?.nameAr || 'المحمدية'}</span>
                  <span className="text-xs text-[#C5A059] font-bold">الآن</span>
                </h4>
                <p className="text-xs text-white/60">
                  {weather.conditionText} • {weather.temp} درجة مئوية
                </p>
              </div>
            </div>

            {/* Weather Metrics Grid */}
            <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-black/40 border border-white/10 mb-4 text-center">
              <div className="p-1">
                <span className="text-[10px] text-white/50 block">الحرارة</span>
                <span className="text-sm font-bold text-white font-mono">{weather.temp}°C</span>
              </div>
              <div className="p-1 border-r border-l border-white/10">
                <span className="text-[10px] text-white/50 block">الرطوبة</span>
                <span className="text-sm font-bold text-white font-mono">{weather.humidity}%</span>
              </div>
              <div className="p-1">
                <span className="text-[10px] text-white/50 block">الرياح</span>
                <span className="text-sm font-bold text-white font-mono">
                  {weather.windSpeed} <span className="text-[9px]">كم/س</span>
                </span>
              </div>
            </div>

            {/* Mosque Prayer Suitability Alert Card */}
            <div
              className={`p-3.5 rounded-2xl border mb-3.5 ${
                weather.mosqueSuitability.status === 'optimal'
                  ? 'bg-emerald-500/10 border-emerald-500/30'
                  : weather.mosqueSuitability.status === 'difficult'
                  ? 'bg-rose-500/10 border-rose-500/30'
                  : 'bg-amber-500/10 border-amber-500/30'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-white/90">
                  مدى ملاءمة الصلاة في المسجد:
                </span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                    weather.mosqueSuitability.status === 'optimal'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : weather.mosqueSuitability.status === 'difficult'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  }`}
                >
                  {weather.mosqueSuitability.badge}
                </span>
              </div>
              <p className="text-xs text-white/80 leading-relaxed mb-2">
                {weather.mosqueSuitability.advice}
              </p>
              {weather.mosqueSuitability.hadithQuote && (
                <div className="text-[11px] text-[#C5A059] bg-[#C5A059]/10 p-2.5 rounded-xl border border-[#C5A059]/20 font-serif leading-relaxed">
                  {weather.mosqueSuitability.hadithQuote}
                </div>
              )}
            </div>

            {/* Dismiss Button */}
            <button
              type="button"
              onClick={() => setShowWeatherDetails(false)}
              className="w-full py-2.5 rounded-2xl bg-[#C5A059] text-black font-bold text-sm hover:bg-[#d6b063] transition-all cursor-pointer shadow-lg active:scale-98"
            >
              حسناً، بارك الله فيك
            </button>
          </div>
        </div>
      )}

      {/* 1. Modal: Manual Prayer Selector & Order Calibration */}
      {showPrayerSelector && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md"
          onClick={() => setShowPrayerSelector(false)}
        >
          <div
            className="w-full max-w-sm rounded-3xl p-5 border border-[#C5A059]/40 shadow-2xl bg-gradient-to-b from-[#1C1A27] via-[#161420] to-[#12111A] text-white relative animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setShowPrayerSelector(false)}
              className="absolute top-4 left-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 rounded-2xl bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30">
                <SlidersHorizontal className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold font-['Cairo',sans-serif]">
                  تدقيق واختيار الصلاة القادمة
                </h4>
                <p className="text-xs text-white/60">
                  حدد الصلاة القادمة لتصحيح الترتيب فوراً
                </p>
              </div>
            </div>

            <p className="text-xs text-white/70 mb-3 leading-relaxed">
              اختر الصلاة التي ترغب في توجيه العداد إليها، وسيكمل التطبيق بعدها العد والانتقال للصلوات التالية تلقائياً:
            </p>

            {/* Prayers List */}
            <div className="space-y-2 mb-3">
              {['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].map((pId) => {
                const prayerItem = prayers?.find((p) => p.id === pId) || (nextPrayer?.id === pId ? nextPrayer : null);
                const prayerNameAr =
                  pId === 'fajr' ? 'الفجر' :
                  pId === 'dhuhr' ? 'الظهر' :
                  pId === 'asr' ? 'العصر' :
                  pId === 'maghrib' ? 'المغرب' : 'العشاء';
                const isSelected = manualNextPrayerId ? manualNextPrayerId === pId : nextPrayer?.id === pId;

                return (
                  <button
                    key={pId}
                    type="button"
                    onClick={() => {
                      audioAdhanService.playClickSound();
                      onSelectManualNextPrayer?.(pId);
                      setShowPrayerSelector(false);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer text-sm font-semibold active:scale-98 ${
                      isSelected
                        ? 'bg-[#C5A059]/20 border-[#C5A059] text-white shadow-md'
                        : 'bg-black/40 border-white/10 text-white/80 hover:bg-white/5 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{prayerNameAr}</span>
                      {isSelected && (
                        <span className="text-[10px] bg-[#C5A059] text-black px-1.5 py-0.5 rounded font-extrabold">
                          مختارة
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {prayerItem && (
                        <span className="text-xs text-[#C5A059] font-mono font-bold dir-ltr">
                          {prayerItem.time}
                        </span>
                      )}
                      {isSelected && <Check className="w-4 h-4 text-[#C5A059]" />}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Automatic Reset Option */}
            <button
              type="button"
              onClick={() => {
                audioAdhanService.playClickSound();
                onSelectManualNextPrayer?.(null);
                setShowPrayerSelector(false);
              }}
              className="w-full py-2.5 rounded-xl border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-white/90 font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>العودة للترتيب التلقائي الذكي (الافتراضي)</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. Modal: Manual Remaining Time Calibration */}
      {showTimeAdjust && nextPrayer && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md"
          onClick={() => setShowTimeAdjust(false)}
        >
          <div
            className="w-full max-w-sm rounded-3xl p-5 border border-[#C5A059]/40 shadow-2xl bg-gradient-to-b from-[#1C1A27] via-[#161420] to-[#12111A] text-white relative animate-in fade-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              type="button"
              onClick={() => setShowTimeAdjust(false)}
              className="absolute top-4 left-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 rounded-2xl bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold font-['Cairo',sans-serif]">
                  ضبط وتصحيح الوقت المتبقي
                </h4>
                <p className="text-xs text-white/60">
                  لصلاة {nextPrayer.nameAr} • الموعد: {nextPrayer.time}
                </p>
              </div>
            </div>

            {/* Live Countdown Display Card */}
            <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 mb-4 text-center">
              <span className="text-[11px] text-white/50 block mb-1">الوقت المتبقي الحالي المباشر:</span>
              <div className="text-2xl font-mono font-bold text-[#C5A059] tracking-widest dir-ltr">
                {countdownStr}
              </div>
              <div className="text-[11px] text-white/70 mt-1.5 flex items-center justify-center gap-1.5">
                <span>التصحيح المطبق:</span>
                <span className={`font-bold font-mono px-2 py-0.5 rounded ${
                  (currentPrayerOffset ?? 0) !== 0
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-white/10 text-white/70'
                }`}>
                  {(currentPrayerOffset ?? 0) > 0 ? `+${currentPrayerOffset}` : (currentPrayerOffset ?? 0)} دقيقة
                </span>
              </div>
            </div>

            {/* Quick +/- Buttons */}
            <div className="mb-4">
              <span className="text-xs font-semibold text-white/80 block mb-2 text-center">
                إضافة أو إنقاص دقائق من الوقت المتبقي:
              </span>
              <div className="grid grid-cols-3 gap-2 mb-2">
                <button
                  type="button"
                  onClick={() => {
                    audioAdhanService.playClickSound();
                    onAdjustRemainingOffset?.(-5);
                  }}
                  className="py-2 px-1 rounded-xl bg-black/40 hover:bg-rose-500/20 border border-white/10 hover:border-rose-400 text-rose-300 font-bold text-xs transition-all cursor-pointer active:scale-95"
                >
                  - 5 دقائق
                </button>
                <button
                  type="button"
                  onClick={() => {
                    audioAdhanService.playClickSound();
                    onAdjustRemainingOffset?.(-1);
                  }}
                  className="py-2 px-1 rounded-xl bg-black/40 hover:bg-rose-500/20 border border-white/10 hover:border-rose-400 text-rose-300 font-bold text-xs transition-all cursor-pointer active:scale-95"
                >
                  - 1 دقيقة
                </button>
                <button
                  type="button"
                  onClick={() => {
                    audioAdhanService.playClickSound();
                    onAdjustRemainingOffset?.(1);
                  }}
                  className="py-2 px-1 rounded-xl bg-black/40 hover:bg-emerald-500/20 border border-white/10 hover:border-emerald-400 text-emerald-300 font-bold text-xs transition-all cursor-pointer active:scale-95"
                >
                  + 1 دقيقة
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    audioAdhanService.playClickSound();
                    onAdjustRemainingOffset?.(-10);
                  }}
                  className="py-2 px-1 rounded-xl bg-black/40 hover:bg-rose-500/20 border border-white/10 hover:border-rose-400 text-rose-300 font-bold text-xs transition-all cursor-pointer active:scale-95"
                >
                  - 10 دقائق
                </button>
                <button
                  type="button"
                  onClick={() => {
                    audioAdhanService.playClickSound();
                    onAdjustRemainingOffset?.(10);
                  }}
                  className="py-2 px-1 rounded-xl bg-black/40 hover:bg-emerald-500/20 border border-white/10 hover:border-emerald-400 text-emerald-300 font-bold text-xs transition-all cursor-pointer active:scale-95"
                >
                  + 10 دقائق
                </button>
              </div>
            </div>

            {/* Reset to 0 */}
            <button
              type="button"
              onClick={() => {
                audioAdhanService.playClickSound();
                onResetRemainingOffset?.();
              }}
              className="w-full py-2.5 rounded-xl border border-white/15 bg-white/5 hover:bg-white/10 text-xs text-white/90 font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 mb-2"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>إعادة ضبط التوقيت الطبيعي (0 دقيقة)</span>
            </button>

            {/* Dismiss Button */}
            <button
              type="button"
              onClick={() => setShowTimeAdjust(false)}
              className="w-full py-2.5 rounded-2xl bg-[#C5A059] text-black font-bold text-xs hover:bg-[#d6b063] transition-all cursor-pointer active:scale-98"
            >
              تم الضبط بنجاح ✓
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
