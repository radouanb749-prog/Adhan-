import React from 'react';
import { Sun, Moon, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { audioAdhanService } from '../services/audioAdhan';

export const ThemeToggleBtn: React.FC = () => {
  const { themeMode, isDark, toggleTheme, sunriseTime, sunsetTime } = useTheme();

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleTheme();
    audioAdhanService.playClickSound();
  };

  const getLabel = () => {
    if (themeMode === 'auto') {
      return isDark ? 'تلقائي (ليلي)' : 'تلقائي (نهاري)';
    }
    return isDark ? 'الوضع الليلي' : 'الوضع النهاري';
  };

  const getTooltip = () => {
    if (themeMode === 'auto') {
      return `مفعل تلقائياً: نهاري من الشروق (${sunriseTime || '06:20'}) إلى الغروب (${sunsetTime || '18:15'})`;
    }
    return isDark ? 'انقر للتبديل للوضع النهاري' : 'انقر للتبديل للوضع التلقائي';
  };

  return (
    <button
      onClick={handleClick}
      title={getTooltip()}
      aria-label="تبديل مظهر الوضع الليلي والنهاري"
      className={`relative flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold transition-all active:scale-95 cursor-pointer backdrop-blur-md border ${
        isDark
          ? 'bg-black/40 border-[#C5A059]/40 text-[#C5A059] hover:bg-black/60 shadow-md'
          : 'bg-white/80 border-[#C5A059]/60 text-[#8B6508] hover:bg-white shadow-sm'
      }`}
    >
      {isDark ? (
        <Moon className="w-3.5 h-3.5 fill-[#C5A059]/30 text-[#C5A059]" />
      ) : (
        <Sun className="w-3.5 h-3.5 text-amber-500 fill-amber-400 animate-spin-slow" />
      )}

      <span>{getLabel()}</span>

      {themeMode === 'auto' && (
        <span
          className={`text-[9px] px-1 py-0.2 rounded-full font-extrabold ${
            isDark
              ? 'bg-[#C5A059]/20 text-[#C5A059]'
              : 'bg-amber-100 text-amber-800'
          }`}
        >
          شروق/غروب
        </span>
      )}
    </button>
  );
};
