import React, { useState, useEffect, useRef } from 'react';
import {
  Compass,
  ShieldCheck,
  MapPin,
  Volume2,
  VolumeX,
  Smartphone,
  Mic,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  X,
  RotateCw,
  RefreshCw,
} from 'lucide-react';
import { CityData } from '../types/prayer';
import { KaabaIcon } from './BottomNav';
import { audioAdhanService } from '../services/audioAdhan';

interface QiblaCompassViewProps {
  currentCity: CityData;
  onBack: () => void;
}

export const QiblaCompassView: React.FC<QiblaCompassViewProps> = ({
  currentCity,
  onBack,
}) => {
  // Mecca Coordinates
  const MECCA_LAT = 21.422487;
  const MECCA_LNG = 39.826206;

  // Calculate Qibla bearing from current coordinates
  const calculateQiblaAngle = (lat: number, lng: number): number => {
    const phiK = (MECCA_LAT * Math.PI) / 180.0;
    const lambdaK = (MECCA_LNG * Math.PI) / 180.0;
    const phi = (lat * Math.PI) / 180.0;
    const lambda = (lng * Math.PI) / 180.0;

    const y = Math.sin(lambdaK - lambda);
    const x =
      Math.cos(phi) * Math.tan(phiK) -
      Math.sin(phi) * Math.cos(lambdaK - lambda);

    let qibla = (Math.atan2(y, x) * 180.0) / Math.PI;
    return (qibla + 360) % 360;
  };

  const qiblaAngle = Math.round(calculateQiblaAngle(currentCity.lat, currentCity.lng));
  const [deviceHeading, setDeviceHeading] = useState<number>(0);
  const [hasCompassSupport, setHasCompassSupport] = useState<boolean>(false);

  // Compass Calibration Accuracy State: 'accurate' (green) or 'uncalibrated' (red)
  const [calibrationStatus, setCalibrationStatus] = useState<'accurate' | 'uncalibrated'>('accurate');
  const [accuracyDegrees, setAccuracyDegrees] = useState<number | null>(null);
  const [showCalibrationHelp, setShowCalibrationHelp] = useState<boolean>(false);

  // Audio & Haptic vibration toggles
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(true);
  const [voiceEnabled, setVoiceEnabled] = useState<boolean>(false);
  const [showSimulator, setShowSimulator] = useState<boolean>(false);

  // Track previous alignment to trigger sound/vibration only upon entering alignment
  const wasAlignedRef = useRef<boolean>(false);
  const lastFeedbackTimeRef = useRef<number>(0);

  // Approximate distance to Mecca
  const calculateDistanceKm = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  };

  const distanceKm = calculateDistanceKm(currentCity.lat, currentCity.lng, MECCA_LAT, MECCA_LNG);

  // Device orientation sensor listener with calibration accuracy detection
  useEffect(() => {
    const handleOrientation = (e: DeviceOrientationEvent) => {
      const heading =
        (e as unknown as { webkitCompassHeading?: number }).webkitCompassHeading ??
        (e.alpha ? 360 - e.alpha : null);
      if (heading !== null) {
        setHasCompassSupport(true);
        setDeviceHeading(Math.round(heading));
      }

      // Check compass calibration accuracy (iOS webkitCompassAccuracy or Android orientation)
      const accuracy = (e as unknown as { webkitCompassAccuracy?: number }).webkitCompassAccuracy;
      if (typeof accuracy === 'number' && accuracy >= 0) {
        setAccuracyDegrees(Math.round(accuracy));
        // Accuracy <= 25 degrees means calibrated & good
        if (accuracy <= 25) {
          setCalibrationStatus('accurate');
        } else {
          setCalibrationStatus('uncalibrated');
        }
      }
    };

    // Standard Android event when magnetometer requires figure-8 calibration
    const handleNeedsCalibration = (e: Event) => {
      e.preventDefault();
      setCalibrationStatus('uncalibrated');
    };

    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', handleOrientation, true);
    }
    window.addEventListener('compassneedscalibration', handleNeedsCalibration, true);

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation);
      window.removeEventListener('compassneedscalibration', handleNeedsCalibration);
    };
  }, []);

  const relativeQibla = (qiblaAngle - deviceHeading + 360) % 360;
  // Aligned when difference from target is within +/- 3 degrees
  const isAligned = Math.abs(relativeQibla) <= 3 || Math.abs(relativeQibla - 360) <= 3;

  // Trigger Audio and Haptic feedback on precision alignment
  useEffect(() => {
    const now = Date.now();
    if (isAligned && !wasAlignedRef.current) {
      // Debounce: minimum 1.5 seconds between triggers
      if (now - lastFeedbackTimeRef.current > 1500) {
        lastFeedbackTimeRef.current = now;

        // 1. Haptic vibration
        if (vibrationEnabled && navigator.vibrate) {
          // Double buzz celebration pulse
          navigator.vibrate([150, 100, 200, 100, 250]);
        }

        // 2. Audio chime
        if (soundEnabled) {
          audioAdhanService.playQiblaAlignedTone();
        }

        // 3. Optional Voice announcement
        if (voiceEnabled) {
          audioAdhanService.speakQiblaGuidance();
        }
      }
    }
    wasAlignedRef.current = isAligned;
  }, [isAligned, vibrationEnabled, soundEnabled, voiceEnabled]);

  // Quick manual alignment test for user testing
  const handleTestAlign = () => {
    setDeviceHeading(qiblaAngle);
  };

  return (
    <div className="flex flex-col items-center justify-between min-h-[580px] p-5 text-white select-none">
      {/* Top Header */}
      <div className="w-full flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white font-['Cairo',sans-serif]">
            اتجاه القبلة الشريفة
          </h2>
          <div className="flex items-center gap-1.5 text-xs sm:text-sm text-[#C5A059] mt-0.5">
            <MapPin className="w-3.5 h-3.5" />
            <span>{currentCity.nameAr}</span>
            <span className="text-white/40">•</span>
            <span>{qiblaAngle}° من الشمال</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Visual Compass Calibration Indicator (Green / Red) */}
          <button
            type="button"
            onClick={() => setShowCalibrationHelp(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer border ${
              calibrationStatus === 'accurate'
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/25'
                : 'bg-rose-500/15 border-rose-500/40 text-rose-400 hover:bg-rose-500/25 animate-pulse'
            }`}
            title="انقر لعرض تفاصيل وإرشادات معايرة بوصلة الهاتف"
          >
            {calibrationStatus === 'accurate' ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>معايرة دقيقة</span>
              </>
            ) : (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                </span>
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                <span>معايرة ضعيفة</span>
              </>
            )}
          </button>

          <button
            onClick={onBack}
            className="px-3.5 py-1.5 rounded-full bg-white/10 hover:bg-white/15 text-xs text-white/90 font-medium transition-all active:scale-95 cursor-pointer"
          >
            العودة
          </button>
        </div>
      </div>

      {/* Warning banner when compass is uncalibrated / low accuracy */}
      {calibrationStatus === 'uncalibrated' && (
        <div className="w-full max-w-sm my-2 p-2.5 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-xs flex items-center justify-between gap-2 shadow-lg animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 animate-bounce" />
            <span>حساس البوصلة غير معاير؛ حرّك الهاتف في الهواء على شكل 8 (∞)</span>
          </div>
          <button
            onClick={() => setShowCalibrationHelp(true)}
            className="text-[11px] font-bold text-rose-300 hover:text-white underline shrink-0 cursor-pointer"
          >
            الشرح
          </button>
        </div>
      )}

      {/* Audio & Haptic Feedback Controls Row */}
      <div className="w-full max-w-sm flex items-center justify-between my-2 p-2 rounded-xl bg-[#1A1A1A] border border-white/5 text-xs">
        <span className="text-white/60 font-semibold px-1">التوجيه:</span>
        <div className="flex items-center gap-1.5">
          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled((prev) => !prev)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all ${
              soundEnabled
                ? 'bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/40'
                : 'bg-white/5 text-white/40 hover:text-white'
            }`}
            title={soundEnabled ? 'صوت التوجيه مفعّل' : 'صوت التوجيه معطّل'}
          >
            {soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-[#C5A059]" />
            ) : (
              <VolumeX className="w-3.5 h-3.5" />
            )}
            <span className="font-bold">رنين</span>
          </button>

          {/* Vibration Toggle */}
          <button
            onClick={() => setVibrationEnabled((prev) => !prev)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all ${
              vibrationEnabled
                ? 'bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/40'
                : 'bg-white/5 text-white/40 hover:text-white'
            }`}
            title={vibrationEnabled ? 'الاهتزاز مفعّل' : 'الاهتزاز معطّل'}
          >
            <Smartphone className="w-3.5 h-3.5 text-[#C5A059]" />
            <span className="font-bold">اهتزاز</span>
          </button>

          {/* Voice Guidance Toggle */}
          <button
            onClick={() => setVoiceEnabled((prev) => !prev)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all ${
              voiceEnabled
                ? 'bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/40'
                : 'bg-white/5 text-white/40 hover:text-white'
            }`}
            title={voiceEnabled ? 'التوجيه الصوتي المنطوق مفعّل' : 'التوجيه الصوتي المنطوق معطّل'}
          >
            <Mic className="w-3.5 h-3.5 text-[#C5A059]" />
            <span className="font-bold">نطق</span>
          </button>
        </div>
      </div>

      {/* Compass Dial */}
      <div className="relative my-4 flex items-center justify-center">
        {/* Outer Glow Ring with alignment pulse */}
        <div
          className={`w-72 h-72 sm:w-80 sm:h-80 rounded-full border-2 transition-all duration-300 flex items-center justify-center ${
            isAligned
              ? 'border-emerald-400 shadow-[0_0_45px_rgba(16,185,129,0.45)] ring-4 ring-emerald-500/20'
              : 'border-[#C5A059]/40 shadow-[0_0_25px_rgba(197,160,89,0.15)]'
          } bg-radial from-[#1E1E1E] to-[#121212]`}
        >
          {/* Degree Ticks */}
          <div className="absolute inset-2 rounded-full border border-white/10" />

          {/* Cardinal Directions */}
          <span className="absolute top-3 text-xs font-bold text-[#C5A059]">شمال (N)</span>
          <span className="absolute bottom-3 text-xs font-bold text-white/40">جنوب (S)</span>
          <span className="absolute right-3 text-xs font-bold text-white/40">شرق (E)</span>
          <span className="absolute left-3 text-xs font-bold text-white/40">غرب (W)</span>

          {/* Compass Rose Needle pointing to Qibla */}
          <div
            className="w-full h-full absolute inset-0 flex items-center justify-center transition-transform duration-300"
            style={{ transform: `rotate(${relativeQibla}deg)` }}
          >
            {/* Kaaba Target Icon at the top of needle */}
            <div className="absolute top-6 sm:top-8 flex flex-col items-center">
              <div
                className={`p-2 rounded-full border shadow-lg transition-transform ${
                  isAligned
                    ? 'bg-emerald-600/60 border-emerald-400 scale-125 animate-pulse'
                    : 'bg-black/60 border-[#C5A059]'
                }`}
              >
                <KaabaIcon className="w-6 h-6 text-white" active />
              </div>
              <span
                className={`text-[10px] font-bold mt-1 ${
                  isAligned ? 'text-emerald-400 font-extrabold' : 'text-[#C5A059]'
                }`}
              >
                الكعبة
              </span>
            </div>

            {/* Needle Line */}
            <div
              className={`w-1 h-36 rounded-full transition-colors ${
                isAligned
                  ? 'bg-gradient-to-t from-transparent via-emerald-400 to-emerald-400'
                  : 'bg-gradient-to-t from-transparent via-[#C5A059] to-[#C5A059]'
              }`}
            />
          </div>

          {/* Center Hub */}
          <div
            className={`relative z-10 w-16 h-16 rounded-full border-2 flex flex-col items-center justify-center shadow-lg transition-colors ${
              isAligned
                ? 'bg-emerald-950 border-emerald-400 text-emerald-300'
                : 'bg-[#181818] border-[#C5A059] text-white'
            }`}
          >
            <span className="text-xs font-black font-mono">{qiblaAngle}°</span>
          </div>
        </div>
      </div>

      {/* Alignment Status Banner */}
      <div className="w-full max-w-sm space-y-2">
        {isAligned ? (
          <div className="flex items-center justify-center gap-2.5 py-3 px-4 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 text-sm font-bold shadow-lg animate-pulse">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>أنت الآن موجه نحو القبلة الشريفة تماماً!</span>
          </div>
        ) : (
          <div className="flex items-center justify-between py-3 px-4 rounded-xl bg-[#1E1E1E] border border-white/5 text-xs text-white/75">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#C5A059] shrink-0" />
              <span>
                {hasCompassSupport
                  ? 'أدر الهاتف حتى تتطابق إبرة الكعبة مع الأعلى'
                  : `وجّه الهاتف ${qiblaAngle}° نحو الشرق والشمال`}
              </span>
            </div>
            <span className="font-mono text-white/50">{distanceKm.toLocaleString()} كم</span>
          </div>
        )}

        {/* Simulator / Manual test toggle */}
        <div className="flex items-center justify-between px-2 pt-1 text-[11px] text-white/40">
          <button
            onClick={() => setShowSimulator((prev) => !prev)}
            className="flex items-center gap-1 hover:text-[#C5A059] transition-colors cursor-pointer"
          >
            <Sliders className="w-3 h-3 text-[#C5A059]" />
            <span>{showSimulator ? 'إخفاء محاكي التوجيه' : 'تجربة التوجيه اليدوي (محاكي)'}</span>
          </button>

          <button
            onClick={handleTestAlign}
            className="text-[#C5A059] hover:underline font-semibold cursor-pointer"
          >
            تجربة المحاذاة الآن
          </button>
        </div>

        {/* Manual Test Heading Slider & Calibration Simulator */}
        {showSimulator && (
          <div className="p-3 rounded-xl bg-[#1A1A1A] border border-white/10 space-y-2.5 animate-in fade-in">
            <div className="flex items-center justify-between text-xs text-white/70">
              <span>اتجاه الهاتف اليدوي:</span>
              <span className="font-mono text-[#C5A059] font-bold">{deviceHeading}°</span>
            </div>
            <input
              type="range"
              min="0"
              max="359"
              value={deviceHeading}
              onChange={(e) => setDeviceHeading(Number(e.target.value))}
              className="w-full accent-[#C5A059] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-white/40">
              <span>0° (شمال)</span>
              <span>{qiblaAngle}° (القبلة)</span>
              <span>360°</span>
            </div>

            {/* Test calibration indicator button */}
            <div className="pt-2 border-t border-white/10 flex items-center justify-between">
              <span className="text-[11px] text-white/60">اختبار مؤشر المعايرة:</span>
              <button
                type="button"
                onClick={() =>
                  setCalibrationStatus((prev) => (prev === 'accurate' ? 'uncalibrated' : 'accurate'))
                }
                className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
                  calibrationStatus === 'accurate'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                }`}
              >
                {calibrationStatus === 'accurate' ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>حالة المعايرة: خضراء (دقيقة)</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    <span>حالة المعايرة: حمراء (ضعيفة)</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Compass Calibration Guide Modal */}
      {showCalibrationHelp && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setShowCalibrationHelp(false)}
        >
          <div
            className="w-full max-w-sm rounded-3xl p-5 border border-[#C5A059]/40 bg-gradient-to-b from-[#1C1A27] via-[#161420] to-[#12111A] text-white shadow-2xl relative animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              onClick={() => setShowCalibrationHelp(false)}
              className="absolute top-4 left-4 p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30">
                <Compass className="w-6 h-6 animate-spin-slow" />
              </div>
              <div>
                <h4 className="text-base font-bold font-['Cairo',sans-serif]">
                  معايرة بوصلة الهاتف 🧭
                </h4>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-xs text-white/60">الحالة الراهنة:</span>
                  {calibrationStatus === 'accurate' ? (
                    <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      معايرة دقيقة وممتازة 🟢
                    </span>
                  ) : (
                    <span className="text-[11px] font-bold text-rose-400 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      تحتاج إلى معايرة 🔴
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Visual Figure-8 (∞) Demonstration */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 mb-4 text-center">
              <div className="w-16 h-10 mx-auto border-2 border-dashed border-[#C5A059] rounded-full flex items-center justify-center text-xl font-bold text-[#C5A059] mb-2 shadow-inner">
                ∞
              </div>
              <p className="text-xs font-bold text-white mb-1">
                حرّك الهاتف في الهواء على شكل رقم 8
              </p>
              <p className="text-[11px] text-white/60 leading-relaxed">
                ارسم بهاتفك في الهواء حركة علامة ما لا نهاية (∞) مرتين إلى ثلاث مرات لتحرير الحساس المغناطيسي الداخلي.
              </p>
            </div>

            {/* Golden Tips */}
            <div className="space-y-2 mb-4 text-xs text-white/80">
              <div className="flex items-start gap-2 p-2 rounded-xl bg-white/5">
                <span className="text-[#C5A059] font-bold">•</span>
                <span><strong>الابتعاد عن المعادن:</strong> تأكد من عدم وجود أجهزة كمبيوتر أو مغناطيس أو أغطية هواتف تحتوي على معادن قرب الهاتف.</span>
              </div>
              <div className="flex items-start gap-2 p-2 rounded-xl bg-white/5">
                <span className="text-[#C5A059] font-bold">•</span>
                <span><strong>استواء الهاتف:</strong> ضع الهاتف أفقياً على راحة يدك مثل صحن مستوٍ للحصول على أعلى دقة.</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  setCalibrationStatus('accurate');
                  setShowCalibrationHelp(false);
                }}
                className="w-full py-2.5 rounded-2xl bg-[#C5A059] hover:bg-[#d6b063] text-black font-bold text-sm transition-all shadow-lg active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>إعادة ضبط المعايرة للوضع الدقيق (🟢)</span>
              </button>
              <button
                type="button"
                onClick={() => setShowCalibrationHelp(false)}
                className="w-full py-2 rounded-2xl bg-white/5 hover:bg-white/10 text-white/70 hover:text-white text-xs transition-colors cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
