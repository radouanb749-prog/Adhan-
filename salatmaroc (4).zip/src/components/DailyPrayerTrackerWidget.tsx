import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { CheckCircle2, Users, Clock, AlertCircle, Sparkles, ChevronDown, Check, RotateCcw } from 'lucide-react';
import { PrayerTimeItem, PrayerRecordStatus, DailyPrayerRecord } from '../types/prayer';
import { useTheme } from '../context/ThemeContext';
import { getSecondsForTimezone } from '../services/prayerCalculation';

interface DailyPrayerTrackerWidgetProps {
  targetDate: Date;
  prayers: PrayerTimeItem[];
  currentTimeMs: number;
  timezoneMode?: 'gmt' | 'gmt+1';
}

const STORAGE_PREFIX = 'salaat_prayer_tracker_';

const PRAYER_IDS: Array<'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'> = [
  'fajr',
  'dhuhr',
  'asr',
  'maghrib',
  'isha',
];

const PRAYER_NAMES_AR: Record<'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha', string> = {
  fajr: 'الفجر',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',
};

const STATUS_CONFIG: Record<
  PrayerRecordStatus,
  { label: string; shortLabel: string; bg: string; text: string; border: string; icon: React.ReactNode }
> = {
  on_time: {
    label: 'أُديت في وقتها',
    shortLabel: 'في وقتها',
    bg: 'bg-emerald-500/15',
    text: 'text-emerald-400',
    border: 'border-emerald-500/40',
    icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />,
  },
  jamaah: {
    label: 'صُلّيت جماعة بالمسجد',
    shortLabel: 'جماعة',
    bg: 'bg-[#C5A059]/20',
    text: 'text-[#C5A059]',
    border: 'border-[#C5A059]/50',
    icon: <Users className="w-3.5 h-3.5 text-[#C5A059]" />,
  },
  qadaa: {
    label: 'صُلّيت قضاءً',
    shortLabel: 'قضاءً',
    bg: 'bg-amber-500/15',
    text: 'text-amber-300',
    border: 'border-amber-500/40',
    icon: <Clock className="w-3.5 h-3.5 text-amber-300" />,
  },
  missed: {
    label: 'صلاة فائتة',
    shortLabel: 'فائتة',
    bg: 'bg-rose-500/15',
    text: 'text-rose-400',
    border: 'border-rose-500/40',
    icon: <AlertCircle className="w-3.5 h-3.5 text-rose-400" />,
  },
  none: {
    label: 'لم تسجل بعد',
    shortLabel: 'اضغط للتسجيل',
    bg: 'bg-white/5',
    text: 'text-white/40',
    border: 'border-white/10',
    icon: null,
  },
};

export const DailyPrayerTrackerWidget: React.FC<DailyPrayerTrackerWidgetProps> = ({
  targetDate,
  prayers,
  currentTimeMs,
  timezoneMode = 'gmt',
}) => {
  const { isDark } = useTheme();

  // Storage key by date YYYY-MM-DD
  const dateKey = useMemo(() => {
    const y = targetDate.getFullYear();
    const m = String(targetDate.getMonth() + 1).padStart(2, '0');
    const d = String(targetDate.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }, [targetDate]);

  const [record, setRecord] = useState<DailyPrayerRecord>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_PREFIX}${dateKey}`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      dateKey,
      fajr: 'none',
      dhuhr: 'none',
      asr: 'none',
      maghrib: 'none',
      isha: 'none',
    };
  });

  // Reload when dateKey changes
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_PREFIX}${dateKey}`);
      if (saved) {
        setRecord(JSON.parse(saved));
        return;
      }
    } catch {}
    setRecord({
      dateKey,
      fajr: 'none',
      dhuhr: 'none',
      asr: 'none',
      maghrib: 'none',
      isha: 'none',
    });
  }, [dateKey]);

  // Persist record
  const updatePrayerStatus = useCallback(
    (prayerId: 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha', status: PrayerRecordStatus) => {
      setRecord((prev) => {
        const next = { ...prev, [prayerId]: status };
        try {
          localStorage.setItem(`${STORAGE_PREFIX}${dateKey}`, JSON.stringify(next));
        } catch {}
        return next;
      });
    },
    [dateKey]
  );

  // Cycle status on tap: none -> on_time -> jamaah -> qadaa -> missed -> none
  const handleCycleStatus = useCallback(
    (prayerId: 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha') => {
      const current = record[prayerId];
      let nextStatus: PrayerRecordStatus;
      switch (current) {
        case 'none':
          nextStatus = 'on_time';
          break;
        case 'on_time':
          nextStatus = 'jamaah';
          break;
        case 'jamaah':
          nextStatus = 'qadaa';
          break;
        case 'qadaa':
          nextStatus = 'missed';
          break;
        case 'missed':
        default:
          nextStatus = 'none';
          break;
      }
      updatePrayerStatus(prayerId, nextStatus);
    },
    [record, updatePrayerStatus]
  );

  // Calculate statistics
  const stats = useMemo(() => {
    let completed = 0;
    let onTime = 0;
    let jamaah = 0;
    let qadaa = 0;
    let missed = 0;

    PRAYER_IDS.forEach((id) => {
      const st = record[id];
      if (st === 'on_time' || st === 'jamaah') completed++;
      if (st === 'on_time') onTime++;
      if (st === 'jamaah') jamaah++;
      if (st === 'qadaa') qadaa++;
      if (st === 'missed') missed++;
    });

    const percent = Math.round((completed / 5) * 100);

    return { completed, onTime, jamaah, qadaa, missed, percent };
  }, [record]);

  // Check if each prayer has arrived or passed
  const isPassedMap = useMemo(() => {
    const nowSecToday = getSecondsForTimezone(currentTimeMs, timezoneMode);

    const map: Record<string, boolean> = {};
    prayers.forEach((p) => {
      const [h, m] = p.time.split(':').map(Number);
      const pSec = h * 3600 + m * 60;
      map[p.id] = nowSecToday >= pSec;
    });
    return map;
  }, [prayers, currentTimeMs, timezoneMode]);

  return (
    <div className="w-full px-4 py-2 select-none">
      <div
        className={`rounded-3xl border p-4 sm:p-5 transition-all shadow-xl backdrop-blur-md relative overflow-hidden ${
          isDark
            ? 'bg-gradient-to-b from-[#1C1A27]/95 via-[#161420]/95 to-[#12111A]/95 border-emerald-500/20'
            : 'bg-gradient-to-b from-white/95 via-[#FAF8F5]/95 to-white/95 border-emerald-600/25 shadow-emerald-900/5'
        }`}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-2xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white font-['Cairo',sans-serif] flex items-center gap-2">
                <span>سجل الصلوات اليومية</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                  {stats.completed} / 5 مؤداة ({stats.percent}%)
                </span>
              </h3>
              <p className={`text-[11px] ${isDark ? 'text-white/50' : 'text-gray-500'}`}>
                انقر على اسم الصلاة لتدوين أدائها (في وقتها، جماعة، أو فائتة)
              </p>
            </div>
          </div>

          {/* Quick reset button */}
          <button
            onClick={() => {
              const empty: DailyPrayerRecord = {
                dateKey,
                fajr: 'none',
                dhuhr: 'none',
                asr: 'none',
                maghrib: 'none',
                isha: 'none',
              };
              setRecord(empty);
              try {
                localStorage.setItem(`${STORAGE_PREFIX}${dateKey}`, JSON.stringify(empty));
              } catch {}
            }}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/50 hover:text-white transition-all cursor-pointer"
            title="إعادة تعيين سجل اليوم"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 rounded-full bg-black/40 overflow-hidden mb-3.5 p-0.5 border border-white/10">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 transition-all duration-500 shadow-sm"
            style={{ width: `${stats.percent}%` }}
          />
        </div>

        {/* 5 Prayers Grid */}
        <div className="grid grid-cols-5 gap-1.5 sm:gap-2 mb-3">
          {PRAYER_IDS.map((id) => {
            const prayer = prayers.find((p) => p.id === id);
            const status = record[id];
            const cfg = STATUS_CONFIG[status];
            const isPassed = isPassedMap[id] ?? false;

            return (
              <button
                key={id}
                onClick={() => handleCycleStatus(id)}
                className={`flex flex-col items-center justify-between p-2 sm:p-2.5 rounded-2xl border transition-all cursor-pointer relative overflow-hidden active:scale-95 ${
                  cfg.bg
                } ${cfg.border} ${
                  status !== 'none'
                    ? 'ring-1 ring-emerald-500/40 shadow-sm'
                    : isDark
                    ? 'bg-[#181622] hover:bg-white/5'
                    : 'bg-white hover:bg-gray-50'
                }`}
                title={`انقر لتغيير حالة صلاة ${PRAYER_NAMES_AR[id]}`}
              >
                {/* Prayer Name & Time */}
                <div className="text-center w-full">
                  <span className="text-xs sm:text-sm font-bold block text-white/90">
                    {PRAYER_NAMES_AR[id]}
                  </span>
                  <span className="text-[10px] sm:text-[11px] font-mono text-white/50 block">
                    {prayer?.time || '--:--'}
                  </span>
                </div>

                {/* Status Indicator Badge */}
                <div className="mt-1.5 flex items-center justify-center">
                  {cfg.icon ? (
                    cfg.icon
                  ) : (
                    <span
                      className={`w-3.5 h-3.5 rounded-full border border-dashed flex items-center justify-center text-[9px] ${
                        isPassed ? 'border-amber-400/50 text-amber-300' : 'border-white/20 text-white/20'
                      }`}
                    >
                      {isPassed ? '•' : ''}
                    </span>
                  )}
                </div>

                {/* Short Label */}
                <span className={`text-[9px] font-bold mt-1 text-center truncate max-w-full ${cfg.text}`}>
                  {cfg.shortLabel}
                </span>
              </button>
            );
          })}
        </div>

        {/* Legend / Stats Summary */}
        <div className="flex items-center justify-between text-[11px] text-white/60 pt-2 border-t border-white/5 flex-wrap gap-2">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" />
              <span>في وقتها: <strong>{stats.onTime}</strong></span>
            </span>
            <span className="flex items-center gap-1 text-[#C5A059]">
              <Users className="w-3 h-3" />
              <span>جماعة: <strong>{stats.jamaah}</strong></span>
            </span>
            {stats.qadaa > 0 && (
              <span className="flex items-center gap-1 text-amber-300">
                <Clock className="w-3 h-3" />
                <span>قضاءً: <strong>{stats.qadaa}</strong></span>
              </span>
            )}
            {stats.missed > 0 && (
              <span className="flex items-center gap-1 text-rose-400">
                <AlertCircle className="w-3 h-3" />
                <span>فائتة: <strong>{stats.missed}</strong></span>
              </span>
            )}
          </div>

          <span className="text-[10px] text-white/40">
            {stats.completed === 5 ? '✨ هنيئاً لك إتمام صلوات اليوم كلها!' : 'حافظ على صلواتك في وقتها'}
          </span>
        </div>
      </div>
    </div>
  );
};
