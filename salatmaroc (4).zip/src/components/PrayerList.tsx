import React, { useState, useEffect } from 'react';
import { Bell, BellOff, Volume2, Square, SlidersHorizontal, UserCheck, Clock, Share2 } from 'lucide-react';
import { PrayerTimeItem } from '../types/prayer';
import { audioAdhanService, AdhanPlaybackState } from '../services/audioAdhan';
import { MUEZZINS_LIST, MuezzinItem } from '../data/muezzinsData';
import { useTheme } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';

interface PrayerListProps {
  prayers: PrayerTimeItem[];
  nextPrayerId?: string;
  countdownStr?: string;
  onOpenPrayerAdjust?: () => void;
  onOpenMuezzinSelector?: (prayerId: string, prayerNameAr: string) => void;
  onOpenShare?: () => void;
  assignedMuezzins?: Record<string, string>; // prayerId -> muezzinId
}

export const PrayerList: React.FC<PrayerListProps> = ({
  prayers,
  nextPrayerId,
  countdownStr,
  onOpenPrayerAdjust,
  onOpenMuezzinSelector,
  onOpenShare,
  assignedMuezzins = {},
}) => {
  const { isDark } = useTheme();
  const { language, t } = useLanguage();

  // Store alarm toggles per prayer
  const [activeAlarms, setActiveAlarms] = useState<Record<string, boolean>>({
    fajr: true,
    sunrise: false,
    dhuhr: true,
    asr: true,
    maghrib: true,
    isha: true,
  });

  const [playbackState, setPlaybackState] = useState<AdhanPlaybackState>(() =>
    audioAdhanService.getPlaybackState()
  );

  useEffect(() => {
    const unsubscribe = audioAdhanService.subscribe((state) => {
      setPlaybackState(state);
    });
    return unsubscribe;
  }, []);

  const toggleAlarm = (prayerId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveAlarms((prev) => ({
      ...prev,
      [prayerId]: !prev[prayerId],
    }));
    audioAdhanService.playClickSound();
  };

  // Get Muezzin for specific prayer
  const getMuezzinForPrayer = (prayerId: string): MuezzinItem => {
    const assignedId = assignedMuezzins[prayerId];
    if (assignedId) {
      const found = MUEZZINS_LIST.find((m) => m.id === assignedId);
      if (found) return found;
    }

    // Smart defaults for prayers
    if (prayerId === 'fajr') {
      return (
        MUEZZINS_LIST.find((m) => m.id === 'makkah_fajr') ||
        MUEZZINS_LIST[0]
      );
    }
    if (prayerId === 'maghrib') {
      return (
        MUEZZINS_LIST.find((m) => m.id === 'moroccan_traditional') ||
        MUEZZINS_LIST[0]
      );
    }
    if (prayerId === 'dhuhr' || prayerId === 'asr') {
      return (
        MUEZZINS_LIST.find((m) => m.id === 'makkah_mulla') ||
        MUEZZINS_LIST[0]
      );
    }
    if (prayerId === 'isha') {
      return (
        MUEZZINS_LIST.find((m) => m.id === 'madinah_bukhari') ||
        MUEZZINS_LIST[0]
      );
    }

    return MUEZZINS_LIST[0];
  };

  const handlePlayPrayerAdhan = (prayer: PrayerTimeItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const prayerAudioId = `prayer_${prayer.id}`;

    if (playbackState.isPlaying && playbackState.activeId === prayerAudioId) {
      audioAdhanService.stopRealAdhan();
    } else {
      const muezzin = getMuezzinForPrayer(prayer.id);
      audioAdhanService.playRealAdhan(
        muezzin.audioUrl,
        prayerAudioId,
        `أذان ${prayer.nameAr}`,
        muezzin.nameAr
      );
    }
  };

  return (
    <div className="w-full px-4 py-2">
      <div
        className={`rounded-2xl overflow-hidden transition-colors duration-300 ${
          isDark
            ? 'bg-[#1C1C1C] border border-white/5 shadow-lg'
            : 'bg-white border border-[#C5A059]/30 shadow-[0_4px_20px_rgba(0,0,0,0.06)]'
        }`}
      >
        {prayers.map((prayer, index) => {
          const isNext = prayer.id === nextPrayerId;
          const isLast = index === prayers.length - 1;
          const isAlarmOn = activeAlarms[prayer.id];
          const isPlayingThis =
            playbackState.isPlaying &&
            playbackState.activeId === `prayer_${prayer.id}`;
          const muezzin = getMuezzinForPrayer(prayer.id);

          return (
            <div
              key={prayer.id}
              className={`relative flex items-center justify-between py-3.5 px-4 sm:px-5 transition-all select-none ${
                isNext
                  ? isDark
                    ? 'bg-gradient-to-l from-[#C5A059]/20 via-[#C5A059]/10 to-transparent border-r-4 border-[#C5A059]'
                    : 'bg-gradient-to-l from-[#C5A059]/25 via-[#C5A059]/10 to-transparent border-r-4 border-[#C5A059]'
                  : isDark
                  ? 'hover:bg-white/[0.02]'
                  : 'hover:bg-[#F9F7F2]'
              } ${
                !isLast
                  ? isDark
                    ? 'border-b border-white/[0.06]'
                    : 'border-b border-[#C5A059]/15'
                  : ''
              }`}
            >
              {/* Right side: Prayer Name in Arabic + Muezzin badge */}
              <div className="flex items-center gap-2.5">
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-lg sm:text-xl font-bold font-['Cairo',sans-serif] ${
                        isNext
                          ? 'text-[#C5A059]'
                          : isDark
                          ? 'text-white'
                          : 'text-gray-900'
                      }`}
                    >
                      {language === 'en' ? prayer.nameEn : prayer.nameAr}
                    </span>
                    {isNext && (
                      <span className="text-[10px] font-medium bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/30 px-2 py-0.5 rounded-full font-bold">
                        {t.nextBadge}
                      </span>
                    )}
                  </div>

                  {/* Muezzin Tag / Change Button */}
                  {prayer.id !== 'sunrise' && (
                    <button
                      onClick={() =>
                        onOpenMuezzinSelector &&
                        onOpenMuezzinSelector(prayer.id, prayer.nameAr)
                      }
                      className={`text-[11px] flex items-center gap-1 text-right mt-0.5 transition-colors cursor-pointer ${
                        isDark
                          ? 'text-white/40 hover:text-[#C5A059]'
                          : 'text-gray-500 hover:text-[#8B6508]'
                      }`}
                      title={language === 'en' ? 'Change muezzin for this prayer' : 'تغيير المؤذن لهذه الصلاة'}
                    >
                      <UserCheck className="w-3 h-3 text-[#C5A059]" />
                      <span className="truncate max-w-[130px] sm:max-w-[170px]">
                        {language === 'en'
                          ? (muezzin.nameEn || muezzin.nameAr).replace('Adhan ', '').replace('أذان ', '')
                          : muezzin.nameAr.replace('أذان ', '')}
                      </span>
                    </button>
                  )}
                </div>
              </div>

              {/* Left side: Time, Real Adhan Audio Play Button, and Alarm Bell */}
              <div className="flex items-center gap-3 sm:gap-4">
                {/* Time (04:55, 06:20...) */}
                <span
                  className={`text-lg sm:text-xl font-bold font-mono tracking-wider ${
                    isNext
                      ? 'text-[#C5A059]'
                      : isDark
                      ? 'text-white/95'
                      : 'text-gray-800'
                  }`}
                >
                  {prayer.time}
                </span>

                {/* Real Adhan Audio Button */}
                {prayer.id !== 'sunrise' ? (
                  <button
                    onClick={(e) => handlePlayPrayerAdhan(prayer, e)}
                    className={`flex items-center justify-center p-2 rounded-xl transition-all active:scale-90 cursor-pointer ${
                      isPlayingThis
                        ? 'bg-[#C5A059] text-black shadow-lg animate-pulse'
                        : isDark
                        ? 'bg-white/5 hover:bg-[#C5A059]/20 text-[#C5A059]'
                        : 'bg-[#C5A059]/10 hover:bg-[#C5A059]/25 text-[#8B6508]'
                    }`}
                    title={
                      isPlayingThis
                        ? language === 'en'
                          ? 'Stop Adhan'
                          : 'إيقاف صوت الأذان'
                        : language === 'en'
                        ? `Listen to ${prayer.nameEn} Adhan`
                        : `استماع لأذان ${prayer.nameAr}`
                    }
                    aria-label={`Adhan ${prayer.nameEn}`}
                  >
                    {isPlayingThis ? (
                      <Square className="w-4 h-4 fill-black" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                  </button>
                ) : (
                  <div className="w-8" />
                )}

                {/* Golden Bell Icon for notifications */}
                <button
                  onClick={(e) => toggleAlarm(prayer.id, e)}
                  title={
                    isAlarmOn
                      ? language === 'en'
                        ? 'Adhan reminder enabled'
                        : 'تنبيه الأذان مفعل'
                      : language === 'en'
                      ? 'Adhan reminder disabled'
                      : 'تنبيه الأذان معطل'
                  }
                  className={`p-1.5 rounded-full transition-all active:scale-90 cursor-pointer ${
                    isAlarmOn
                      ? 'text-[#C5A059] hover:bg-[#C5A059]/15'
                      : isDark
                      ? 'text-white/30 hover:text-white/50 hover:bg-white/5'
                      : 'text-gray-400 hover:text-gray-600 hover:bg-gray-100'
                  }`}
                  aria-label={`Alarm ${prayer.nameEn}`}
                >
                  {isAlarmOn ? (
                    <Bell className="w-5 h-5 fill-[#C5A059] stroke-[#C5A059]" />
                  ) : (
                    <BellOff className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>
          );
        })}

        {/* Adjust button shortcut */}
        {onOpenPrayerAdjust && (
          <button
            onClick={onOpenPrayerAdjust}
            className={`w-full py-2.5 px-4 flex items-center justify-between text-xs transition-colors group cursor-pointer border-t ${
              isDark
                ? 'bg-[#141414] hover:bg-[#1a1a1a] border-white/5 text-white/60 hover:text-[#C5A059]'
                : 'bg-[#FBF9F5] hover:bg-[#F4EFE6] border-[#C5A059]/15 text-gray-600 hover:text-[#8B6508]'
            }`}
          >
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>{language === 'en' ? 'Adjust prayer times (+/- min)' : 'تعديل أوقات الصلاة (+/- دقيقة)'}</span>
            </div>
            <span className="text-[11px] text-[#C5A059] font-semibold group-hover:underline">
              {language === 'en' ? 'Adjust' : 'تعديل'}
            </span>
          </button>
        )}

        {/* Share schedule shortcut */}
        {onOpenShare && (
          <button
            onClick={onOpenShare}
            className={`w-full py-2.5 px-4 flex items-center justify-between text-xs transition-colors group cursor-pointer border-t ${
              isDark
                ? 'bg-[#141414] hover:bg-[#1a1a1a] border-white/5 text-white/60 hover:text-[#C5A059]'
                : 'bg-[#FBF9F5] hover:bg-[#F4EFE6] border-[#C5A059]/15 text-gray-600 hover:text-[#8B6508]'
            }`}
          >
            <div className="flex items-center gap-2">
              <Share2 className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>{t.shareTitle}</span>
            </div>
            <span className="text-[11px] text-[#C5A059] font-semibold group-hover:underline">
              {t.share}
            </span>
          </button>
        )}
      </div>
    </div>
  );
};
