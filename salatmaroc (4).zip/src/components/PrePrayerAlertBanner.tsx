import React, { useState, useEffect } from 'react';
import { Bell, X, Volume2, MapPin } from 'lucide-react';
import { PrePrayerAlertData, notificationService } from '../services/notificationService';
import { audioAdhanService } from '../services/audioAdhan';

export const PrePrayerAlertBanner: React.FC = () => {
  const [activeAlert, setActiveAlert] = useState<PrePrayerAlertData | null>(null);

  useEffect(() => {
    const unsubscribe = notificationService.onAlert((alert) => {
      setActiveAlert(alert);
    });
    return unsubscribe;
  }, []);

  // Auto-dismiss after 15 seconds
  useEffect(() => {
    if (!activeAlert) return;
    const timer = setTimeout(() => {
      setActiveAlert(null);
    }, 15000);
    return () => clearTimeout(timer);
  }, [activeAlert]);

  if (!activeAlert) return null;

  return (
    <div className="fixed top-4 left-4 right-4 z-50 max-w-md mx-auto animate-in slide-in-from-top duration-300 select-none">
      <div className="relative rounded-2xl bg-[#1C1C1C] border-2 border-[#C5A059] p-4 shadow-[0_10px_35px_rgba(0,0,0,0.8)] overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute -top-12 -right-12 w-28 h-28 bg-[#C5A059]/20 rounded-full blur-xl pointer-events-none" />

        <div className="flex items-start justify-between gap-3">
          {/* Bell Icon with animated pulse */}
          <div className="p-2.5 rounded-xl bg-[#C5A059]/20 text-[#C5A059] border border-[#C5A059]/40 shrink-0 animate-bounce">
            <Bell className="w-5 h-5 fill-[#C5A059]" />
          </div>

          <div className="flex-1 text-right">
            <div className="flex items-center gap-2">
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                activeAlert.minutesRemaining === 0
                  ? 'text-emerald-300 bg-emerald-500/20 border border-emerald-500/40'
                  : 'text-[#C5A059] bg-[#C5A059]/15'
              }`}>
                {activeAlert.minutesRemaining === 0 ? 'حان موعد الصلاة الآن 🕌' : `تنبيه مسبق (${activeAlert.minutesRemaining} دقائق)`}
              </span>
              <div className="flex items-center gap-1 text-[11px] text-white/50">
                <MapPin className="w-3 h-3 text-[#C5A059]" />
                <span>{activeAlert.cityNameAr}</span>
              </div>
            </div>

            <h4 className="text-base font-bold text-white mt-1 font-['Cairo',sans-serif]">
              {activeAlert.minutesRemaining === 0
                ? `حان الآن موعد أذان ${activeAlert.prayerNameAr} (${activeAlert.prayerTime})`
                : `اقتراب موعد أذان ${activeAlert.prayerNameAr} (${activeAlert.prayerTime})`}
            </h4>

            <p className="text-xs text-white/70 mt-0.5">
              {activeAlert.minutesRemaining === 0
                ? `الله أكبر الله أكبر. حان الآن وقت صلاة ${activeAlert.prayerNameAr} في مدينة ${activeAlert.cityNameAr}. تقبل الله منا ومنكم.`
                : `بقي ${activeAlert.minutesRemaining} دقائق على دخول الوقت في ${activeAlert.cityNameAr}. استعد للوضوء والصلاة.`}
            </p>

            <div className="mt-2.5 flex items-center gap-2">
              <button
                onClick={() => {
                  if (activeAlert.adhanUrl) {
                    audioAdhanService.playRealAdhan(
                      activeAlert.adhanUrl,
                      'alert_' + activeAlert.id,
                      `أذان ${activeAlert.prayerNameAr}`,
                      activeAlert.cityNameAr
                    );
                  } else {
                    audioAdhanService.playAdhanChime();
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#C5A059] text-black font-bold text-xs hover:bg-[#d8b56f] transition-all active:scale-95"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>استماع للأذان</span>
              </button>

              <button
                onClick={() => setActiveAlert(null)}
                className="px-3 py-1 rounded-lg bg-white/5 text-white/70 hover:text-white font-medium text-xs hover:bg-white/10 transition-all"
              >
                حسناً، فهمت
              </button>
            </div>
          </div>

          <button
            onClick={() => setActiveAlert(null)}
            className="p-1 rounded-full text-white/40 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
