import React from 'react';
import {
  BookOpen,
  CalendarDays,
  MapPin,
  Settings,
  X,
  ChevronLeft,
  Volume2,
  Sparkles,
  Download,
  Heart,
  Moon,
  Lock,
  Share2,
  Car,
} from 'lucide-react';

import { useLanguage } from '../context/LanguageContext';

export type SubMenuOption =
  | 'tasbeeh'
  | 'hadiths'
  | 'adhkar'
  | 'hisn'
  | 'virtues'
  | 'monthly'
  | 'cities'
  | 'share'
  | 'settings'
  | 'adhan_settings'
  | 'android_auto'
  | 'download_zip';

interface SideMenuBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectOption: (option: SubMenuOption) => void;
}

// Custom Tasbih Icon (Islamic prayer beads)
const TasbihIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    {/* String loop */}
    <circle cx="12" cy="11" r="7" strokeDasharray="3 3" />
    {/* Beads */}
    <circle cx="12" cy="4" r="1.5" fill="currentColor" />
    <circle cx="17" cy="6" r="1.5" fill="currentColor" />
    <circle cx="19" cy="11" r="1.5" fill="currentColor" />
    <circle cx="17" cy="16" r="1.5" fill="currentColor" />
    <circle cx="12" cy="18" r="1.5" fill="currentColor" />
    <circle cx="7" cy="16" r="1.5" fill="currentColor" />
    <circle cx="5" cy="11" r="1.5" fill="currentColor" />
    <circle cx="7" cy="6" r="1.5" fill="currentColor" />
    {/* Tassel (Sharraba) */}
    <path d="M12 18v4" />
    <path d="M10 22h4" />
  </svg>
);

export const SideMenuBottomSheet: React.FC<SideMenuBottomSheetProps> = ({
  isOpen,
  onClose,
  onSelectOption,
}) => {
  const { language, t } = useLanguage();

  if (!isOpen) return null;

  const menuItems: {
    id: SubMenuOption;
    title: string;
    description: string;
    icon: React.ReactNode;
    highlight?: boolean;
    badgeText?: string;
  }[] = [
    {
      id: 'tasbeeh',
      title: t.tasbeeh,
      description: t.tasbeehDesc,
      icon: <TasbihIcon className="w-5 h-5 text-[#C5A059]" />,
      highlight: true,
      badgeText: t.tasbeehBadge,
    },
    {
      id: 'virtues',
      title: t.virtuesTitle,
      description: t.virtuesDesc,
      icon: <Sparkles className="w-5 h-5 text-[#C5A059]" />,
    },
    {
      id: 'adhan_settings',
      title: t.adhanSettings,
      description: t.adhanSettingsDesc,
      icon: <Volume2 className="w-5 h-5 text-[#C5A059]" />,
    },
    {
      id: 'adhkar',
      title: t.adhkarMenuTitle,
      description: t.adhkarMenuDesc,
      icon: <TasbihIcon className="w-5 h-5 text-white" />,
    },
    {
      id: 'hadiths',
      title: t.hadithsMenuTitle,
      description: t.hadithsMenuDesc,
      icon: <Heart className="w-5 h-5 text-white" />,
    },
    {
      id: 'monthly',
      title: t.monthlyMenuTitle,
      description: t.monthlyMenuDesc,
      icon: <CalendarDays className="w-5 h-5 text-white" />,
    },
    {
      id: 'share',
      title: t.shareTitle,
      description: t.shareDesc,
      icon: <Share2 className="w-5 h-5 text-[#C5A059]" />,
      highlight: true,
      badgeText: language === 'en' ? 'Share' : 'مشاركة',
    },
    {
      id: 'settings',
      title: t.settingsMenuTitle,
      description: t.settingsMenuDesc,
      icon: <Settings className="w-5 h-5 text-white" />,
    },
    {
      id: 'android_auto',
      title: language === 'en' ? 'Android Auto (Car Screen)' : 'شاشة السيارة (Android Auto)',
      description: language === 'en' ? 'Prayer times and Qibla on car dashboard' : 'عرض المواقيت والقبلة على شاشة لوحة قيادة سيارتك',
      icon: <Car className="w-5 h-5 text-emerald-400" />,
      highlight: true,
      badgeText: language === 'en' ? 'Car Screen' : 'جديد 🚗',
    },
    {
      id: 'download_zip',
      title: t.downloadZipTitle,
      description: t.downloadZipDesc,
      icon: <Download className="w-5 h-5 text-emerald-400" />,
      highlight: true,
      badgeText: t.supervisorBadge,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end select-none animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/75 backdrop-blur-sm transition-opacity cursor-pointer"
      />

      {/* Bottom Sheet Drawer */}
      <div className="relative z-10 w-full max-w-xl mx-auto bg-[#181720] border-t border-white/10 rounded-t-3xl p-5 shadow-2xl pb-8 animate-in slide-in-from-bottom duration-300 max-h-[85vh] flex flex-col overflow-hidden">
        {/* Drag handle */}
        <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mb-4 shrink-0" />

        {/* Title bar */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <img
              src="/pwa-192x192.png"
              alt="شعار مواقيت الصلاة"
              className="w-8 h-8 rounded-xl object-cover shadow border border-[#C5A059]/40"
            />
            <h3 className="text-lg font-bold text-white font-['Cairo',sans-serif]">
              {t.moreOptions}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/80 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of sub-options */}
        <div className="overflow-y-auto space-y-2 pr-1 flex-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onSelectOption(item.id);
                onClose();
              }}
              className={`w-full flex items-center justify-between p-3.5 rounded-2xl border transition-all text-right group active:scale-[0.99] cursor-pointer ${
                item.highlight
                  ? 'bg-gradient-to-l from-[#C5A059]/20 to-[#1F1E2A] border-[#C5A059]/40 hover:border-[#C5A059]'
                  : 'bg-[#201F2B] border-white/5 hover:border-white/20 hover:bg-[#282736]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`p-2.5 rounded-xl ${
                    item.highlight ? 'bg-[#C5A059]/20' : 'bg-white/5'
                  }`}
                >
                  {item.icon}
                </div>
                <div>
                  <h4 className="text-sm sm:text-base font-bold text-white group-hover:text-[#C5A059] transition-colors font-['Cairo',sans-serif] flex items-center gap-2">
                    <span>{item.title}</span>
                    {item.badgeText ? (
                      <span className="text-[10px] bg-[#C5A059] text-black font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                        <Lock className="w-2.5 h-2.5" />
                        <span>{item.badgeText}</span>
                      </span>
                    ) : item.highlight ? (
                      <span className="text-[10px] bg-[#C5A059] text-black font-extrabold px-1.5 py-0.2 rounded">
                        مميز
                      </span>
                    ) : null}
                  </h4>
                  <p className="text-xs text-white/50 mt-0.5">
                    {item.description}
                  </p>
                </div>
              </div>
              <ChevronLeft className="w-5 h-5 text-white/40 group-hover:text-[#C5A059] group-hover:-translate-x-1 transition-all" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
