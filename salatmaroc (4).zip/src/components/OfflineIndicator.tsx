import React from 'react';
import { WifiOff, CheckCircle2 } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-4 z-50 max-w-sm mx-auto animate-in fade-in slide-in-from-bottom duration-300 select-none">
      <div className="flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-[#1C1A27]/95 border border-[#C5A059]/40 text-white shadow-[0_8px_30px_rgba(0,0,0,0.8)] backdrop-blur-md">
        <div className="p-1.5 rounded-xl bg-[#C5A059]/20 text-[#C5A059] shrink-0">
          <WifiOff className="w-4 h-4" />
        </div>
        <div className="flex-1 text-right text-xs">
          <div className="font-bold text-[#C5A059] flex items-center gap-1">
            <span>يعمل بدون إنترنت (أوفلاين)</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />
          </div>
          <p className="text-[11px] text-white/70 mt-0.5">
            جميع مواقيت الصلاة والأذان والقبلة محفوظة بالكامل على جهازك.
          </p>
        </div>
      </div>
    </div>
  );
};
