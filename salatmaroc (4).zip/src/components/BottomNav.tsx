import React from 'react';
import { Calendar, Menu, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useLanguage } from '../context/LanguageContext';

export type MainTabType = 'today' | 'virtues' | 'qibla' | 'mosques';

interface BottomNavProps {
  activeTab: MainTabType;
  onTabChange: (tab: MainTabType) => void;
  onOpenMoreMenu: () => void;
  isMoreMenuOpen: boolean;
}

// Custom Kaaba Icon
export const KaabaIcon: React.FC<{ className?: string; active?: boolean }> = ({
  className = 'w-6 h-6',
  active = false,
}) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    className={className}
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {/* Kaaba Cube */}
    <rect
      x="4"
      y="5"
      width="16"
      height="15"
      rx="2"
      fill={active ? 'currentColor' : '#1E1E1E'}
      stroke="currentColor"
    />
    {/* Golden Band (Hizam) */}
    <line
      x1="4"
      y1="9"
      x2="20"
      y2="9"
      stroke={active ? '#1E1E1E' : '#C5A059'}
      strokeWidth="2.2"
    />
    {/* Door of the Kaaba */}
    <rect
      x="13"
      y="12"
      width="4"
      height="8"
      rx="1"
      stroke={active ? '#1E1E1E' : '#C5A059'}
      strokeWidth="1.5"
      fill={active ? 'transparent' : '#C5A059'}
    />
  </svg>
);

// Custom Mosque Icon
export const MosqueIcon: React.FC<{ className?: string }> = ({
  className = 'w-6 h-6',
}) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    className={className}
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {/* Central Dome */}
    <path d="M7 12c0-3.5 2.5-6 5-6s5 2.5 5 6" />
    <path d="M12 6V3.5" />
    <path d="M12 3.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" />
    {/* Minaret Left */}
    <path d="M4 21V9l1.5-2 1.5 2v12" />
    {/* Minaret Right */}
    <path d="M17 21V9l1.5-2 1.5 2v12" />
    {/* Door */}
    <path d="M10 21v-4a2 2 0 0 1 4 0v4" />
    {/* Base line */}
    <path d="M2 21h20" />
  </svg>
);

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  onOpenMoreMenu,
  isMoreMenuOpen,
}) => {
  const { isDark } = useTheme();
  const { language, t } = useLanguage();

  return (
    <nav
      className={`fixed bottom-0 left-0 right-0 z-40 backdrop-blur-lg select-none max-w-xl mx-auto transition-colors duration-300 ${
        isDark
          ? 'bg-[#161616]/95 border-t border-white/10 shadow-[0_-8px_25px_rgba(0,0,0,0.7)] text-white'
          : 'bg-white/95 border-t border-[#C5A059]/25 shadow-[0_-8px_25px_rgba(0,0,0,0.08)] text-gray-800'
      }`}
    >
      <div className="flex items-center justify-around h-16 px-1.5">
        {/* اليوم */}
        <button
          onClick={() => onTabChange('today')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
            activeTab === 'today' && !isMoreMenuOpen
              ? 'text-[#C5A059]'
              : isDark
              ? 'text-white/60 hover:text-white'
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          <Calendar className="w-5 h-5 mb-1" />
          <span className="text-[11px] sm:text-xs font-semibold font-['Cairo',sans-serif]">{t.today}</span>
          {activeTab === 'today' && !isMoreMenuOpen && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] mt-0.5" />
          )}
        </button>

        {/* فضل الصلاة */}
        <button
          onClick={() => onTabChange('virtues')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
            activeTab === 'virtues' && !isMoreMenuOpen
              ? 'text-[#C5A059]'
              : isDark
              ? 'text-white/60 hover:text-white'
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          <Sparkles className="w-5 h-5 mb-1" />
          <span className="text-[11px] sm:text-xs font-semibold font-['Cairo',sans-serif]">{t.virtues}</span>
          {activeTab === 'virtues' && !isMoreMenuOpen && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] mt-0.5" />
          )}
        </button>

        {/* القبلة */}
        <button
          onClick={() => onTabChange('qibla')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
            activeTab === 'qibla' && !isMoreMenuOpen
              ? 'text-[#C5A059]'
              : isDark
              ? 'text-white/60 hover:text-white'
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          <KaabaIcon
            className="w-5 h-5 mb-1"
            active={activeTab === 'qibla' && !isMoreMenuOpen}
          />
          <span className="text-[11px] sm:text-xs font-semibold font-['Cairo',sans-serif]">{t.qibla}</span>
          {activeTab === 'qibla' && !isMoreMenuOpen && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] mt-0.5" />
          )}
        </button>

        {/* مساجد */}
        <button
          onClick={() => onTabChange('mosques')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
            activeTab === 'mosques' && !isMoreMenuOpen
              ? 'text-[#C5A059]'
              : isDark
              ? 'text-white/60 hover:text-white'
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          <MosqueIcon className="w-5 h-5 mb-1" />
          <span className="text-[11px] sm:text-xs font-semibold font-['Cairo',sans-serif]">{language === 'en' ? 'Mosques' : 'مساجد'}</span>
          {activeTab === 'mosques' && !isMoreMenuOpen && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] mt-0.5" />
          )}
        </button>

        {/* المزيد */}
        <button
          onClick={onOpenMoreMenu}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all cursor-pointer ${
            isMoreMenuOpen
              ? 'text-[#C5A059]'
              : isDark
              ? 'text-white/60 hover:text-white'
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          <Menu className="w-5 h-5 mb-1" />
          <span className="text-[11px] sm:text-xs font-semibold font-['Cairo',sans-serif]">{t.more}</span>
          {isMoreMenuOpen && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059] mt-0.5" />
          )}
        </button>
      </div>
    </nav>
  );
};
