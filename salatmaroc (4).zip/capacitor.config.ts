import type { CapacitorConfig } from '@capacitor/cli';

export interface MouadhinCapacitorConfig extends CapacitorConfig {
  allowInSilentMode?: boolean;
}

const config: MouadhinCapacitorConfig = {
  appId: 'com.mouadhin.app',
  appName: 'المؤذن',
  webDir: 'dist',
  allowInSilentMode: true,
  android: {
    allowMixedContent: true,
    captureInput: true,
  },
  server: {
    androidScheme: 'https',
  },
  plugins: {
    LocalNotifications: {
      smallIcon: 'ic_launcher',
      iconColor: '#C5A059',
      sound: 'azan.mp3',
    },
  },
};

export default config;
