package com.mouadhin.app;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PowerManager;

/**
 * AdhanAlarmReceiver (BroadcastReceiver)
 * Receives AlarmManager exact hardware alarm and starts AdhanForegroundService.
 */
public class AdhanAlarmReceiver extends BroadcastReceiver {
    private static PowerManager.WakeLock receiverWakeLock;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null) return;

        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                if (receiverWakeLock == null) {
                    receiverWakeLock = pm.newWakeLock(
                            PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                            "AlMouadhin:AdhanAlarmReceiverWakeLock"
                    );
                    receiverWakeLock.setReferenceCounted(false);
                }
                receiverWakeLock.acquire(45000L);
            }
        } catch (Exception ignored) {}

        String prayerId = intent != null ? intent.getStringExtra("prayerId") : "prayer";
        String prayerName = intent != null ? intent.getStringExtra("prayerName") : "الصلاة";
        boolean isFajr = intent != null && intent.getBooleanExtra("isFajr", false);
        long triggerAtMillis = intent != null ? intent.getLongExtra("triggerAtMillis", System.currentTimeMillis()) : System.currentTimeMillis();

        SharedPreferences prefs = context.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
        boolean isAppMuted = prefs.getBoolean("is_silent_mode_enabled", false);

        if (!isAppMuted) {
            // 1. Start foreground service to play Adhan and display USE_FULL_SCREEN_INTENT notification
            Intent serviceIntent = new Intent(context, AdhanForegroundService.class);
            serviceIntent.putExtra("prayerId", prayerId);
            serviceIntent.putExtra("prayerName", prayerName);
            serviceIntent.putExtra("isFajr", isFajr);

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 2. On Android 9 and below (pre-Q), directly launch AdhanLockScreenActivity as fallback.
            // On Android 10+ (Q+), AdhanForegroundService triggers AdhanLockScreenActivity via official USE_FULL_SCREEN_INTENT
            // to wake the screen and show immediately over the lock screen without BAL restriction conflicts.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                try {
                    String alertMode = prefs.getString("adhan_alert_method", "lock_window_unlocked_notification");

                    KeyguardManager km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
                    PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                    boolean isInteractive = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH
                            ? (pm != null && pm.isInteractive())
                            : (pm != null && pm.isScreenOn());
                    boolean isLocked = km != null && km.isKeyguardLocked();

                    boolean shouldShowWindow = "window".equals(alertMode)
                            || (!"notification".equals(alertMode) && (!isInteractive || isLocked));
                    if (shouldShowWindow) {
                        Intent lockIntent = new Intent(context, AdhanLockScreenActivity.class);
                        lockIntent.addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_NO_USER_ACTION |
                                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                                Intent.FLAG_ACTIVITY_SINGLE_TOP
                        );
                        lockIntent.putExtra("prayerId", prayerId);
                        lockIntent.putExtra("prayerName", prayerName);
                        lockIntent.putExtra("isFajr", isFajr);
                        context.startActivity(lockIntent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        // 3. Chain-reschedule for tomorrow if not test alarm
        if (!"test_adhan_idle".equals(prayerId)) {
            long nextOccurrence = triggerAtMillis + (24 * 3600 * 1000L);
            AdhanScheduler.schedulePrayer(context, prayerId, prayerName, nextOccurrence, isFajr);
            AdhanScheduler.scheduleDailyPrayersNatively(context);
        }
    }
}
