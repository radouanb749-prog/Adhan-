package com.mouadhin.app;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Turn on screen and show over keyguard/lock screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        );

        // Configure Capacitor WebView settings and register AdhanNativeBridge
        if (this.bridge != null && this.bridge.getWebView() != null) {
            WebSettings settings = this.bridge.getWebView().getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setMediaPlaybackRequiresUserGesture(false);
            settings.setAllowFileAccess(true);

            this.bridge.getWebView().addJavascriptInterface(new AdhanNativeBridge(this), "AndroidAdhan");
        }

        // Ensure default allowInSilentMode is true on first launch
        SharedPreferences prefs = getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
        if (!prefs.contains("allow_in_silent_mode")) {
            prefs.edit().putBoolean("allow_in_silent_mode", true).apply();
        }

        // Initialize native Moroccan prayer alarms immediately on app startup
        AdhanScheduler.rescheduleSavedPrayers(this);

        // Start continuous foreground service for reliable background Adhan execution
        try {
            Intent persistentService = new Intent(this, PrayerForegroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(persistentService);
            } else {
                startService(persistentService);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Request runtime POST_NOTIFICATIONS cleanly on Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    public static class AdhanNativeBridge {
        private final MainActivity activity;

        public AdhanNativeBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public boolean isAndroid12OrHigher() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S;
        }

        @JavascriptInterface
        public void schedulePrayerAlarm(String prayerId, String prayerName, long triggerAtMillis, boolean isFajr) {
            AdhanScheduler.schedulePrayer(activity, prayerId, prayerName, triggerAtMillis, isFajr);
        }

        @JavascriptInterface
        public void scheduleTestAlarm(long delayMillis) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AlarmManager am = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
                if (am != null && !am.canScheduleExactAlarms()) {
                    requestExactAlarmPermission();
                }
            }
            AdhanScheduler.scheduleTestAlarm(activity, delayMillis);
        }

        @JavascriptInterface
        public void cancelPrayerAlarm(String prayerId) {
            AdhanScheduler.cancelPrayer(activity, prayerId);
        }

        @JavascriptInterface
        public void updateLocation(String cityName, double lat, double lng, String timezoneMode) {
            AdhanScheduler.saveCityLocation(activity, cityName, lat, lng, timezoneMode);
            AdhanScheduler.scheduleDailyPrayersNatively(activity);
        }

        @JavascriptInterface
        public void setAllowInSilentMode(boolean enabled) {
            SharedPreferences prefs = activity.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            prefs.edit().putBoolean("allow_in_silent_mode", enabled).apply();
        }

        @JavascriptInterface
        public boolean isAllowInSilentMode() {
            SharedPreferences prefs = activity.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            return prefs.getBoolean("allow_in_silent_mode", true);
        }

        @JavascriptInterface
        public void setSilentModeEnabled(boolean isEnabled) {
            SharedPreferences prefs = activity.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            prefs.edit().putBoolean("is_silent_mode_enabled", isEnabled).apply();
        }

        @JavascriptInterface
        public boolean isSilentModeEnabled() {
            SharedPreferences prefs = activity.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            return prefs.getBoolean("is_silent_mode_enabled", false);
        }

        @JavascriptInterface
        public void setAdhanAlertMethod(String method) {
            SharedPreferences prefs = activity.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            prefs.edit().putString("adhan_alert_method", method).apply();
        }

        @JavascriptInterface
        public String getAdhanAlertMethod() {
            SharedPreferences prefs = activity.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            return prefs.getString("adhan_alert_method", "lock_window_unlocked_notification");
        }

        @JavascriptInterface
        public void stopAdhan() {
            activity.runOnUiThread(() -> {
                try {
                    Intent stopIntent = new Intent(activity, AdhanForegroundService.class);
                    stopIntent.setAction(AdhanForegroundService.ACTION_STOP);
                    activity.startService(stopIntent);
                } catch (Exception ignored) {}
                try {
                    activity.sendBroadcast(new Intent(AdhanLockScreenActivity.ACTION_CLOSE));
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public boolean isAdhanPlaying() {
            return AdhanForegroundService.isPlaying;
        }

        @JavascriptInterface
        public void setShakeToStopConfig(boolean enabled, float sensitivity) {
            SharedPreferences prefs = activity.getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            prefs.edit()
                    .putBoolean("shake_to_stop_enabled", enabled)
                    .putFloat("shake_sensitivity", sensitivity)
                    .apply();
        }

        private int savedInterruptionFilter = -1;

        @JavascriptInterface
        public boolean isDndAccessGranted() {
            NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm != null) {
                return nm.isNotificationPolicyAccessGranted();
            }
            return true;
        }

        @JavascriptInterface
        public int getCurrentInterruptionFilter() {
            NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm != null) {
                return nm.getCurrentInterruptionFilter();
            }
            return NotificationManager.INTERRUPTION_FILTER_ALL;
        }

        @JavascriptInterface
        public boolean setInterruptionFilter(int filter) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.isNotificationPolicyAccessGranted()) {
                    try {
                        nm.setInterruptionFilter(filter);
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                }
            }
            return false;
        }

        @JavascriptInterface
        public int beginTemporaryDndBypass() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.isNotificationPolicyAccessGranted()) {
                    try {
                        int current = nm.getCurrentInterruptionFilter();
                        if (savedInterruptionFilter == -1) {
                            savedInterruptionFilter = current;
                        }
                        if (current != NotificationManager.INTERRUPTION_FILTER_ALL) {
                            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                        }
                        return savedInterruptionFilter;
                    } catch (Exception e) {
                        return -1;
                    }
                }
            }
            return -1;
        }

        @JavascriptInterface
        public boolean restoreDndFilter() {
            if (savedInterruptionFilter != -1 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.isNotificationPolicyAccessGranted()) {
                    try {
                        nm.setInterruptionFilter(savedInterruptionFilter);
                        savedInterruptionFilter = -1;
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                }
            }
            savedInterruptionFilter = -1;
            return false;
        }

        @JavascriptInterface
        public boolean isIgnoringBatteryOptimizations() {
            PowerManager pm = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && pm != null) {
                return pm.isIgnoringBatteryOptimizations(activity.getPackageName());
            }
            return true;
        }

        @JavascriptInterface
        public boolean canScheduleExactAlarms() {
            AlarmManager am = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am != null) {
                return am.canScheduleExactAlarms();
            }
            return true;
        }

        @JavascriptInterface
        public boolean canUseFullScreenIntent() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                NotificationManager nm = (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    return nm.canUseFullScreenIntent();
                }
            }
            return true;
        }

        @JavascriptInterface
        public void requestDndAccess() {
            activity.runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        activity.startActivity(intent);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void requestBatteryExemption() {
            activity.runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                            intent.setData(Uri.parse("package:" + activity.getPackageName()));
                            activity.startActivity(intent);
                        } catch (Exception e) {
                            Intent fallback = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            activity.startActivity(fallback);
                        }
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void requestExactAlarmPermission() {
            activity.runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        try {
                            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                            intent.setData(Uri.parse("package:" + activity.getPackageName()));
                            activity.startActivity(intent);
                        } catch (Exception e) {
                            try {
                                Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                fallback.setData(Uri.parse("package:" + activity.getPackageName()));
                                activity.startActivity(fallback);
                            } catch (Exception ignored) {}
                        }
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void requestFullScreenIntentPermission() {
            activity.runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                        try {
                            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
                            intent.setData(Uri.parse("package:" + activity.getPackageName()));
                            activity.startActivity(intent);
                        } catch (Exception e) {
                            try {
                                Intent fallback = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                                fallback.putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
                                activity.startActivity(fallback);
                            } catch (Exception ignored) {}
                        }
                    }
                } catch (Exception ignored) {}
            });
        }
    }
}
