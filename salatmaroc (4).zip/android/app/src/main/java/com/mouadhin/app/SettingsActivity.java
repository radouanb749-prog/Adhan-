package com.mouadhin.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private Switch switchSilentMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        switchSilentMode = findViewById(R.id.switch_silent_mode);
        if (switchSilentMode != null) {
            switchSilentMode.setSaveEnabled(true);

            SharedPreferences prefs = getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            boolean allowInSilent = prefs.getBoolean("allow_in_silent_mode", true);
            switchSilentMode.setChecked(allowInSilent);

            switchSilentMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
                prefs.edit().putBoolean("allow_in_silent_mode", isChecked).apply();
            });
        }
    }
}
