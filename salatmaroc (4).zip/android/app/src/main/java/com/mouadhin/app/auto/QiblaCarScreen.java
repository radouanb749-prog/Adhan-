package com.mouadhin.app.auto;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.ListTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;

public class QiblaCarScreen extends Screen {

    public QiblaCarScreen(@NonNull CarContext carContext) {
        super(carContext);
    }

    @NonNull
    @Override
    public Template onGetTemplate() {
        CarContext context = getCarContext();

        SharedPreferences cityPrefs = context.getSharedPreferences("salat_location_prefs", Context.MODE_PRIVATE);
        String cityName = cityPrefs.getString("city_name", "المغرب");
        double lat = Double.longBitsToDouble(cityPrefs.getLong("city_lat", Double.doubleToLongBits(33.6835)));
        double lng = Double.longBitsToDouble(cityPrefs.getLong("city_lng", Double.doubleToLongBits(-7.3849)));

        double lat1 = Math.toRadians(lat);
        double lat2 = Math.toRadians(21.4225);
        double dLng = Math.toRadians(39.8262 - lng);

        double y = Math.sin(dLng) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
        double bearing = (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
        int bearingInt = (int) Math.round(bearing);

        double dLat = lat2 - lat1;
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1) * Math.cos(lat2) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distanceKm = 6371.0 * c;
        int distanceKmInt = (int) Math.round(distanceKm);

        String compassDirection;
        if (bearing >= 337.5 || bearing < 22.5) compassDirection = "شمال (N)";
        else if (bearing < 67.5) compassDirection = "شمال شرق (NE)";
        else if (bearing < 112.5) compassDirection = "شرق (E)";
        else if (bearing < 157.5) compassDirection = "جنوب شرق (SE)";
        else if (bearing < 202.5) compassDirection = "جنوب (S)";
        else if (bearing < 247.5) compassDirection = "جنوب غرب (SW)";
        else if (bearing < 292.5) compassDirection = "غرب (W)";
        else compassDirection = "شمال غرب (NW)";

        ItemList.Builder listBuilder = new ItemList.Builder();

        listBuilder.addItem(
                new Row.Builder()
                        .setTitle("🧭 زاوية اتجاه القبلة: " + bearingInt + "° " + compassDirection)
                        .addText("محسوبة بدقة من موقعك في " + cityName)
                        .build()
        );

        listBuilder.addItem(
                new Row.Builder()
                        .setTitle("🕋 المسافة إلى الكعبة المشرفة بمكة المكرمة")
                        .addText(String.format("%,d كم خط مستقيم", distanceKmInt))
                        .build()
        );

        listBuilder.addItem(
                new Row.Builder()
                        .setTitle("🚗 إرشاد السائق وموقف السيارة")
                        .addText("أثناء الوقوف أو الاستراحة، اجعل وجهتك نحو زاوية " + bearingInt + "° شرقاً لأداء الصلاة.")
                        .build()
        );

        ActionStrip actionStrip = new ActionStrip.Builder()
                .addAction(
                        new Action.Builder()
                                .setTitle("مواقيت الصلاة 🕌")
                                .setOnClickListener(() -> getScreenManager().pop())
                                .build()
                )
                .build();

        return new ListTemplate.Builder()
                .setTitle("اتجاه القبلة للسيارة • " + cityName)
                .setHeaderAction(Action.BACK)
                .setActionStrip(actionStrip)
                .setSingleList(listBuilder.build())
                .build();
    }
}
