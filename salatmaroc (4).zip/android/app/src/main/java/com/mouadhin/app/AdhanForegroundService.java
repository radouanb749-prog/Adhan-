package com.mouadhin.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/**
 * AdhanForegroundService
 * - NotificationChannel with IMPORTANCE_HIGH, setBypassDnd(true), VISIBILITY_PUBLIC, and silent channel sound
 *   so MediaPlayer's USAGE_ALARM audio plays clearly without overlapping system notification beeps.
 * - Attaches USE_FULL_SCREEN_INTENT PendingIntent targeting AdhanLockScreenActivity to wake screen
 *   and show Adhan UI immediately over the lock screen.
 * - AudioAttributes strictly with USAGE_ALARM and CONTENT_TYPE_SONIFICATION on STREAM_ALARM.
 * - Saves STREAM_ALARM volume, temporarily raises it during Adhan, then restores it on stop/completion.
 */
public class AdhanForegroundService extends Service {
    public static final String CHANNEL_ID = "adhan_prayer_channel_alarm_v2";
    public static final String ACTION_STOP = "com.mouadhin.app.ACTION_STOP_ADHAN";
    public static final int NOTIFICATION_ID = 1001;

    public static volatile boolean isPlaying = false;

    private MediaPlayer mediaPlayer;
    private PowerManager.WakeLock wakeLock;
    private PowerManager.WakeLock screenWakeLock;
    private WifiManager.WifiLock wifiLock;
    private AudioFocusRequest audioFocusRequest;
    private int originalAlarmVolume = -1;
    private int originalInterruptionFilter = -1;

    // Native hardware shake sensor
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SensorEventListener shakeListener;
    private long lastShakeTime = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopAdhan();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        String prayerId = intent != null && intent.hasExtra("prayerId")
                ? intent.getStringExtra("prayerId")
                : "prayer";
        String prayerName = intent != null && intent.hasExtra("prayerName")
                ? intent.getStringExtra("prayerName")
                : "الصلاة";
        boolean isFajr = intent != null && intent.getBooleanExtra("isFajr", false);

        // 1. Check silent/mute preferences before raising full-screen notification & audio
        SharedPreferences prefs = getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
        boolean isAppMuted = prefs.getBoolean("is_silent_mode_enabled", false);
        if (isAppMuted) {
            stopSelf();
            return START_NOT_STICKY;
        }

        // 2. Acquire WakeLock, Screen WakeLock, and WifiLock
        acquireLocks();

        // 3. Ensure channel exists & build notification with USE_FULL_SCREEN_INTENT
        createNotificationChannel();
        Notification notification = buildFullScreenNotification(prayerId, prayerName, isFajr);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                );
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
        } catch (Exception e) {
            try {
                startForeground(NOTIFICATION_ID, notification);
            } catch (Exception ignored) {}
        }

        // Also post notification via NotificationManager to ensure fullScreenIntent triggers heads-up / lock screen immediately
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.notify(NOTIFICATION_ID, notification);
            }
        } catch (Exception ignored) {}

        // 4. Play full Adhan clearly with USAGE_ALARM + CONTENT_TYPE_SONIFICATION & volume save/restore
        playAdhan(isFajr);

        return START_NOT_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;

            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "أذان الصلاة (شاشة القفل والمنبه)",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("يعرض واجهة الأذان فوراً فوق شاشة القفل ويرفع الصوت بوضوح حتى في الوضع الصامت");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.setBypassDnd(true);
            // Disable channel's default ding so MediaPlayer's USAGE_ALARM Adhan plays cleanly without overlap
            channel.setSound(null, null);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 600, 250, 600, 250, 1000, 300, 1200});
            manager.createNotificationChannel(channel);
        }
    }

    private Notification buildFullScreenNotification(String prayerId, String prayerName, boolean isFajr) {
        Intent fullScreenIntent = new Intent(this, AdhanLockScreenActivity.class);
        fullScreenIntent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_NO_USER_ACTION |
                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_SINGLE_TOP
        );
        fullScreenIntent.putExtra("from_adhan_alert", true);
        fullScreenIntent.putExtra("prayerId", prayerId);
        fullScreenIntent.putExtra("prayerName", prayerName);
        fullScreenIntent.putExtra("isFajr", isFajr);

        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
                this,
                2001,
                fullScreenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        Intent stopIntent = new Intent(this, AdhanForegroundService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
                this,
                2002,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
            builder.setPriority(Notification.PRIORITY_MAX);
        }

        builder
                .setContentTitle("حان الآن موعد أذان " + prayerName)
                .setContentText("حي على الصلاة، حي على الفلاح - اضغط لإيقاف الأذان")
                .setSmallIcon(R.drawable.ic_notification_bell)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(fullScreenPendingIntent)
                .addAction(android.R.drawable.ic_media_pause, "إيقاف الأذان", stopPendingIntent)
                .setAutoCancel(false)
                .setOngoing(true);

        SharedPreferences prefs = getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
        String alertMode = prefs.getString("adhan_alert_method", "lock_window_unlocked_notification");
        if (!"notification".equals(alertMode)) {
            builder.setFullScreenIntent(fullScreenPendingIntent, true);
        }

        return builder.build();
    }

    private void playAdhan(boolean isFajr) {
        stopMediaPlayer();
        try {
            SharedPreferences prefs = getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            boolean allowInSilentMode = prefs.getBoolean("allow_in_silent_mode", true);

            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            boolean isPhoneSilentOrVibrate = am != null && am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL;
            boolean isPhoneDndActive = false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm != null) {
                int filter = nm.getCurrentInterruptionFilter();
                isPhoneDndActive = filter != NotificationManager.INTERRUPTION_FILTER_ALL
                        && filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
            }

            if ((isPhoneSilentOrVibrate || isPhoneDndActive) && !allowInSilentMode) {
                stopForeground(false);
                stopSelf();
                return;
            }

            int soundResId = isFajr ? R.raw.adhan_fajr : R.raw.adhan_morocco;

            // AudioAttributes strictly with USAGE_ALARM and CONTENT_TYPE_SONIFICATION
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setLegacyStreamType(AudioManager.STREAM_ALARM)
                    .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                    .build();

            // Temporarily set NotificationManager Interruption Filter to ALL to bypass DND at Adhan moment,
            // then save original filter to restore after audio finishes
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm != null && allowInSilentMode && nm.isNotificationPolicyAccessGranted()) {
                try {
                    int currentFilter = nm.getCurrentInterruptionFilter();
                    if (originalInterruptionFilter == -1) {
                        originalInterruptionFilter = currentFilter;
                    }
                    if (currentFilter != NotificationManager.INTERRUPTION_FILTER_ALL) {
                        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                    }
                } catch (Exception e) {
                    android.util.Log.w("AdhanForegroundService", "Could not temporarily bypass DND filter: " + e.getMessage());
                }
            }

            // Save original alarm volume, temporarily raise STREAM_ALARM volume, then restore on stop/completion
            if (am != null) {
                try {
                    if (originalAlarmVolume == -1) {
                        originalAlarmVolume = am.getStreamVolume(AudioManager.STREAM_ALARM);
                    }
                    int maxStreamVolume = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                    am.setStreamVolume(AudioManager.STREAM_ALARM, maxStreamVolume, 0);
                } catch (Exception e) {
                    android.util.Log.w("AdhanForegroundService", "Could not raise alarm volume: " + e.getMessage());
                }

                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                                .setAudioAttributes(audioAttributes)
                                .setAcceptsDelayedFocusGain(true)
                                .setOnAudioFocusChangeListener(focusChange -> {
                                    // Keep Adhan playing smoothly
                                })
                                .build();
                        am.requestAudioFocus(audioFocusRequest);
                    } else {
                        am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
                    }
                } catch (Exception ignored) {}
            }

            // Prepare MediaPlayer cleanly with AudioAttributes BEFORE prepare/start
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(audioAttributes);
            mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);

            boolean prepared = false;
            try {
                android.content.res.AssetFileDescriptor afd = getResources().openRawResourceFd(soundResId);
                if (afd != null) {
                    mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    afd.close();
                    mediaPlayer.prepare();
                    prepared = true;
                }
            } catch (Exception ignored) {}

            if (!prepared) {
                try {
                    mediaPlayer.reset();
                    mediaPlayer.setAudioAttributes(audioAttributes);
                    android.content.res.AssetFileDescriptor afdFallback = getResources().openRawResourceFd(R.raw.azan);
                    if (afdFallback != null) {
                        mediaPlayer.setDataSource(afdFallback.getFileDescriptor(), afdFallback.getStartOffset(), afdFallback.getLength());
                        afdFallback.close();
                        mediaPlayer.prepare();
                        prepared = true;
                    }
                } catch (Exception ignored) {}
            }

            if (prepared) {
                mediaPlayer.setVolume(1.0f, 1.0f);

                try {
                    Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibrator != null && vibrator.hasVibrator()) {
                        long[] pattern = new long[]{0, 800, 300, 800, 300, 1200, 400, 1500};
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
                        } else {
                            vibrator.vibrate(pattern, -1);
                        }
                    }
                } catch (Exception ignored) {}

                mediaPlayer.setOnCompletionListener(mp -> {
                    stopAdhan();
                    stopForeground(true);
                    stopSelf();
                });

                mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                    stopAdhan();
                    stopForeground(true);
                    stopSelf();
                    return true;
                });

                isPlaying = true;
                setupNativeShakeDetector();
                mediaPlayer.start();
            } else {
                restoreInterruptionFilter();
                restoreAlarmVolume();
                stopForeground(true);
                stopSelf();
            }
        } catch (Exception e) {
            e.printStackTrace();
            restoreInterruptionFilter();
            restoreAlarmVolume();
            stopForeground(true);
            stopSelf();
        }
    }

    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && wakeLock == null) {
                wakeLock = pm.newWakeLock(
                        PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                        "AlMouadhin:AdhanForegroundWakeLock"
                );
                wakeLock.acquire(6 * 60 * 1000L);
            }
        } catch (Exception ignored) {}

        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null && wifiLock == null) {
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "AlMouadhin:AdhanWifiLock");
                wifiLock.acquire();
            }
        } catch (Exception ignored) {}

        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                screenWakeLock = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE,
                        "AlMouadhin:AdhanScreenWakeLock"
                );
                screenWakeLock.acquire(25000L);
            }
        } catch (Exception ignored) {}
    }

    private void restoreInterruptionFilter() {
        if (originalInterruptionFilter != -1) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null && nm.isNotificationPolicyAccessGranted()) {
                        nm.setInterruptionFilter(originalInterruptionFilter);
                    }
                }
            } catch (Exception e) {
                android.util.Log.w("AdhanForegroundService", "Could not restore DND filter: " + e.getMessage());
            }
            originalInterruptionFilter = -1;
        }
    }

    private void restoreAlarmVolume() {
        if (originalAlarmVolume != -1) {
            try {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    am.setStreamVolume(AudioManager.STREAM_ALARM, originalAlarmVolume, 0);
                }
            } catch (Exception ignored) {}
            originalAlarmVolume = -1;
        }
    }

    private void abandonAudioFocus() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
                    am.abandonAudioFocusRequest(audioFocusRequest);
                    audioFocusRequest = null;
                } else {
                    am.abandonAudioFocus(null);
                }
            }
        } catch (Exception ignored) {}
    }

    private void stopMediaPlayer() {
        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
                mediaPlayer.release();
            } catch (Exception ignored) {}
            mediaPlayer = null;
        }
    }

    private void stopAdhan() {
        isPlaying = false;
        unregisterShakeDetector();
        stopMediaPlayer();
        restoreAlarmVolume();
        restoreInterruptionFilter();
        abandonAudioFocus();

        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {}
            wakeLock = null;
        }
        if (screenWakeLock != null && screenWakeLock.isHeld()) {
            try {
                screenWakeLock.release();
            } catch (Exception ignored) {}
            screenWakeLock = null;
        }
        if (wifiLock != null && wifiLock.isHeld()) {
            try {
                wifiLock.release();
            } catch (Exception ignored) {}
            wifiLock = null;
        }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(NOTIFICATION_ID);
            }
        } catch (Exception ignored) {}
        try {
            sendBroadcast(new Intent(AdhanLockScreenActivity.ACTION_CLOSE));
        } catch (Exception ignored) {}
    }

    private void setupNativeShakeDetector() {
        try {
            SharedPreferences prefs = getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            boolean shakeEnabled = prefs.getBoolean("shake_to_stop_enabled", true);
            if (!shakeEnabled) return;

            float sensitivity = prefs.getFloat("shake_sensitivity", 5.5f);
            final float shakeThreshold = sensitivity > 0 ? sensitivity * 2.2f : 12.0f;

            sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            if (sensorManager != null) {
                accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                if (accelerometer != null) {
                    shakeListener = new SensorEventListener() {
                        private float lastAccel = SensorManager.GRAVITY_EARTH;
                        private float currentAccel = SensorManager.GRAVITY_EARTH;
                        private float accel = 0.00f;

                        @Override
                        public void onSensorChanged(SensorEvent event) {
                            float x = event.values[0];
                            float y = event.values[1];
                            float z = event.values[2];
                            lastAccel = currentAccel;
                            currentAccel = (float) Math.sqrt((double) (x * x + y * y + z * z));
                            float delta = currentAccel - lastAccel;
                            accel = accel * 0.9f + delta;

                            long now = System.currentTimeMillis();
                            if (Math.abs(accel) > (shakeThreshold * 0.5f) && (now - lastShakeTime > 1000)) {
                                lastShakeTime = now;
                                try {
                                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                                    if (v != null) {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            v.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
                                        } else {
                                            v.vibrate(200);
                                        }
                                    }
                                } catch (Exception ignored) {}

                                stopAdhan();
                                stopForeground(true);
                                stopSelf();
                            }
                        }

                        @Override
                        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
                    };
                    sensorManager.registerListener(shakeListener, accelerometer, SensorManager.SENSOR_DELAY_UI);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void unregisterShakeDetector() {
        if (sensorManager != null && shakeListener != null) {
            try {
                sensorManager.unregisterListener(shakeListener);
            } catch (Exception ignored) {}
            shakeListener = null;
        }
    }

    @Override
    public void onDestroy() {
        stopAdhan();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
