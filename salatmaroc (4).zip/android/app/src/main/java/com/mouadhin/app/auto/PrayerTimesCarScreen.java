package com.mouadhin.app.auto;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.ListTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;
import com.mouadhin.app.NativePrayerCalculator;
import java.util.Calendar;
import java.util.List;

public class PrayerTimesCarScreen extends Screen {

    public PrayerTimesCarScreen(@NonNull CarContext carContext) {
        super(carContext);
    }

    @NonNull
    @Override
    public Template onGetTemplate() {
        CarContext context = getCarContext();

        SharedPreferences cityPrefs = context.getSharedPreferences("salat_location_prefs", Context.MODE_PRIVATE);
        String cityName = cityPrefs.getString("city_name", "المحمدية / الدار البيضاء");
        double lat = Double.longBitsToDouble(cityPrefs.getLong("city_lat", Double.doubleToLongBits(33.6835)));
        double lng = Double.longBitsToDouble(cityPrefs.getLong("city_lng", Double.doubleToLongBits(-7.3849)));
        String tzMode = cityPrefs.getString("timezone_mode", "gmt");
        int tzOffset = "gmt+1".equals(tzMode) ? 1 : 0;

        Calendar todayCal = Calendar.getInstance();
        List<NativePrayerCalculator.PrayerTime> prayers =
                NativePrayerCalculator.calculatePrayers(todayCal, lat, lng, tzOffset);

        long now = System.currentTimeMillis();
        NativePrayerCalculator.PrayerTime nextPrayer = null;
        long minDiff = Long.MAX_VALUE;

        for (NativePrayerCalculator.PrayerTime p : prayers) {
            long diff = p.triggerAtMillis - now;
            if (diff > 0 && diff < minDiff) {
                minDiff = diff;
                nextPrayer = p;
            }
        }

        if (nextPrayer == null) {
            Calendar tomCal = Calendar.getInstance();
            tomCal.add(Calendar.DAY_OF_YEAR, 1);
            List<NativePrayerCalculator.PrayerTime> tomPrayers =
                    NativePrayerCalculator.calculatePrayers(tomCal, lat, lng, tzOffset);
            if (!tomPrayers.isEmpty()) {
                nextPrayer = tomPrayers.get(0);
                minDiff = nextPrayer.triggerAtMillis - now;
            }
        }

        String countdownText = "";
        if (nextPrayer != null && minDiff > 0) {
            long totalMinutes = minDiff / (60 * 1000);
            long hours = totalMinutes / 60;
            long mins = totalMinutes % 60;
            countdownText = String.format("متبقي %02d:%02d", hours, mins);
        }

        ItemList.Builder listBuilder = new ItemList.Builder();

        if (nextPrayer != null) {
            listBuilder.addItem(
                    new Row.Builder()
                            .setTitle("★ الصلاة القادمة: " + nextPrayer.nameAr + " (" + nextPrayer.getFormattedTime() + ")")
                            .addText("الوقت المتبقي: " + countdownText + " • " + cityName)
                            .build()
            );
        }

        for (NativePrayerCalculator.PrayerTime p : prayers) {
            boolean isNext = (nextPrayer != null && p.id.equals(nextPrayer.id));
            String title = (isNext ? "▶ " : "• ") + p.nameAr;
            String text = "الوقت: " + p.getFormattedTime() + (isNext ? " (الصلاة القادمة)" : "");

            listBuilder.addItem(
                    new Row.Builder()
                            .setTitle(title)
                            .addText(text)
                            .build()
            );
        }

        ActionStrip actionStrip = new ActionStrip.Builder()
                .addAction(
                        new Action.Builder()
                                .setTitle("اتجاه القبلة 🧭")
                                .setOnClickListener(() -> getScreenManager().push(new QiblaCarScreen(context)))
                                .build()
                )
                .addAction(
                        new Action.Builder()
                                .setTitle("تحديث 🔄")
                                .setOnClickListener(this::invalidate)
                                .build()
                )
                .build();

        return new ListTemplate.Builder()
                .setTitle("مواقيت الصلاة • " + cityName)
                .setHeaderAction(Action.APP_ICON)
                .setActionStrip(actionStrip)
                .setSingleList(listBuilder.build())
                .build();
    }
}
