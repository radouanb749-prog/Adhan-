package com.mouadhin.app.auto;

import android.content.pm.ApplicationInfo;
import androidx.annotation.NonNull;
import androidx.car.app.CarAppService;
import androidx.car.app.Session;
import androidx.car.app.validation.HostValidator;

public class SalatCarAppService extends CarAppService {

    @NonNull
    @Override
    public HostValidator createHostValidator() {
        return (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0
                ? HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
                : new HostValidator.Builder(getApplicationContext())
                        .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
                        .build();
    }

    @NonNull
    @Override
    public Session onCreateSession() {
        return new SalatCarSession();
    }
}
