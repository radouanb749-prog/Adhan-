package com.mouadhin.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * AdhanScheduler
 * Uses AlarmManager.setAlarmClock() with SCHEDULE_EXACT_ALARM
 * to accurately trigger Adhans even when phone is locked in Doze mode.
 */
public class AdhanScheduler {
    private static final String PREF_NAME = "salat_adhan_scheduled_prayers";
    public static final String ACTION_PRAYER_ALARM = "com.mouadhin.app.ACTION_PRAYER_ALARM";

    public static void schedulePrayer(Context context, String prayerId, String prayerName, long triggerAtMillis, boolean isFajr) {
        if (context == null || triggerAtMillis <= System.currentTimeMillis()) {
            return;
        }

        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) return;

            Intent intent = new Intent(context, AdhanAlarmReceiver.class);
            intent.setAction(ACTION_PRAYER_ALARM);
            intent.putExtra("prayerId", prayerId);
            intent.putExtra("prayerName", prayerName);
            intent.putExtra("isFajr", isFajr);
            intent.putExtra("triggerAtMillis", triggerAtMillis);

            int requestCode = prayerId.hashCode();
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            boolean hasExactPermission = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                hasExactPermission = alarmManager.canScheduleExactAlarms();
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && hasExactPermission) {
                    Intent showIntent = new Intent(context, MainActivity.class);
                    showIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    PendingIntent showPendingIntent = PendingIntent.getActivity(
                            context,
                            requestCode + 1000,
                            showIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
                    );
                    AlarmManager.AlarmClockInfo clockInfo = new AlarmManager.AlarmClockInfo(triggerAtMillis, showPendingIntent);
                    alarmManager.setAlarmClock(clockInfo, pendingIntent);
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
                } else {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
                }
            } catch (SecurityException se) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    try {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
                    } catch (Exception ex) {
                        alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
                    }
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
                }
            }

            savePrayerToPrefs(context, prayerId, prayerName, triggerAtMillis, isFajr);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void scheduleTestAlarm(Context context, long delayMillis) {
        if (context == null) return;
        long triggerAt = System.currentTimeMillis() + (delayMillis > 0 ? delayMillis : 15000L);
        schedulePrayer(context, "test_adhan_idle", "اختبار الأذان في الخلفية", triggerAt, false);
    }

    public static void cancelPrayer(Context context, String prayerId) {
        if (context == null || prayerId == null) return;
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) return;

            Intent intent = new Intent(context, AdhanAlarmReceiver.class);
            intent.setAction(ACTION_PRAYER_ALARM);
            int requestCode = prayerId.hashCode();

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            alarmManager.cancel(pendingIntent);
            removePrayerFromPrefs(context, prayerId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void rescheduleSavedPrayers(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Map<String, ?> all = prefs.getAll();
        long now = System.currentTimeMillis();
        boolean scheduledAny = false;

        for (String key : all.keySet()) {
            if (key.endsWith("_time")) {
                String prayerId = key.substring(0, key.length() - 5);
                if ("test_adhan_idle".equals(prayerId)) continue;

                long triggerAtMillis = prefs.getLong(key, 0);
                String prayerName = prefs.getString(prayerId + "_name", "الصلاة");
                boolean isFajr = prefs.getBoolean(prayerId + "_isfajr", false);

                while (triggerAtMillis <= now && triggerAtMillis > 0) {
                    triggerAtMillis += 24 * 3600 * 1000L;
                }

                if (triggerAtMillis > now) {
                    schedulePrayer(context, prayerId, prayerName, triggerAtMillis, isFajr);
                    scheduledAny = true;
                }
            }
        }

        if (!scheduledAny) {
            scheduleDailyPrayersNatively(context);
        }
    }

    public static void scheduleDailyPrayersNatively(Context context) {
        if (context == null) return;
        try {
            SharedPreferences cityPrefs = context.getSharedPreferences("salat_location_prefs", Context.MODE_PRIVATE);
            double lat = Double.longBitsToDouble(cityPrefs.getLong("city_lat", Double.doubleToLongBits(33.6835)));
            double lng = Double.longBitsToDouble(cityPrefs.getLong("city_lng", Double.doubleToLongBits(-7.3849)));
            String tzMode = cityPrefs.getString("timezone_mode", "gmt");
            int tzOffset = "gmt+1".equals(tzMode) ? 1 : 0;

            long now = System.currentTimeMillis();

            Calendar todayCal = Calendar.getInstance();
            List<NativePrayerCalculator.PrayerTime> todayPrayers =
                    NativePrayerCalculator.calculatePrayers(todayCal, lat, lng, tzOffset);

            Calendar tomorrowCal = Calendar.getInstance();
            tomorrowCal.add(Calendar.DAY_OF_YEAR, 1);
            List<NativePrayerCalculator.PrayerTime> tomorrowPrayers =
                    NativePrayerCalculator.calculatePrayers(tomorrowCal, lat, lng, tzOffset);

            for (int i = 0; i < todayPrayers.size(); i++) {
                NativePrayerCalculator.PrayerTime pToday = todayPrayers.get(i);
                if (pToday.triggerAtMillis > now) {
                    schedulePrayer(context, pToday.id, pToday.nameAr, pToday.triggerAtMillis, pToday.isFajr);
                } else {
                    NativePrayerCalculator.PrayerTime pTomorrow = tomorrowPrayers.get(i);
                    schedulePrayer(context, pTomorrow.id, pTomorrow.nameAr, pTomorrow.triggerAtMillis, pTomorrow.isFajr);
                }
            }
        } catch (Exception e) {
            android.util.Log.e("AdhanScheduler", "scheduleDailyPrayersNatively error: " + e.getMessage());
        }
    }

    public static void saveCityLocation(Context context, String cityName, double lat, double lng, String timezoneMode) {
        if (context == null) return;
        SharedPreferences cityPrefs = context.getSharedPreferences("salat_location_prefs", Context.MODE_PRIVATE);
        cityPrefs.edit()
                .putString("city_name", cityName)
                .putLong("city_lat", Double.doubleToLongBits(lat))
                .putLong("city_lng", Double.doubleToLongBits(lng))
                .putString("timezone_mode", timezoneMode)
                .apply();
    }

    private static void savePrayerToPrefs(Context context, String prayerId, String prayerName, long triggerAtMillis, boolean isFajr) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .putLong(prayerId + "_time", triggerAtMillis)
                .putString(prayerId + "_name", prayerName)
                .putBoolean(prayerId + "_isfajr", isFajr)
                .apply();
    }

    private static void removePrayerFromPrefs(Context context, String prayerId) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .remove(prayerId + "_time")
                .remove(prayerId + "_name")
                .remove(prayerId + "_isfajr")
                .apply();
    }
}
