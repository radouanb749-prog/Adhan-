package com.mouadhin.app;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * AdhanLockScreenActivity
 * Displays immediately over the lock screen via USE_FULL_SCREEN_INTENT
 * without triggering PIN/pattern prompt over the Adhan controls.
 */
public class AdhanLockScreenActivity extends AppCompatActivity {
    public static final String ACTION_CLOSE = "com.mouadhin.app.ACTION_CLOSE_LOCK_ACTIVITY";
    private BroadcastReceiver closeReceiver;
    private TextView prayerTitleView;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SensorEventListener shakeListener;
    private long lastShakeTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Enable display over lock screen & wake screen immediately without forcing keyguard PIN prompt
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        );

        String prayerName = getPrayerNameFromIntent(getIntent());

        View rootView = createLockScreenView(prayerName);
        setContentView(rootView);

        closeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                finish();
            }
        };
        IntentFilter filter = new IntentFilter(ACTION_CLOSE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(closeReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(closeReceiver, filter);
        }

        // Auto-dismiss after 5 minutes if untouched
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!isFinishing()) {
                finish();
            }
        }, 5 * 60 * 1000L);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (prayerTitleView != null) {
            prayerTitleView.setText("صلاة " + getPrayerNameFromIntent(intent));
        }
    }

    private String getPrayerNameFromIntent(Intent intent) {
        return (intent != null && intent.hasExtra("prayerName") && intent.getStringExtra("prayerName") != null)
                ? intent.getStringExtra("prayerName")
                : "الصلاة";
    }

    private View createLockScreenView(String prayerName) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.parseColor("#121118"));
        root.setPadding(48, 64, 48, 64);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#1C1A24"));
        cardBg.setCornerRadius(40f);
        cardBg.setStroke(3, Color.parseColor("#C5A059"));
        card.setBackground(cardBg);
        card.setPadding(40, 48, 40, 48);

        ImageView iconView = new ImageView(this);
        iconView.setImageResource(R.mipmap.ic_launcher_round);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(160, 160);
        iconParams.setMargins(0, 0, 0, 32);
        iconView.setLayoutParams(iconParams);
        card.addView(iconView);

        TextView timeView = new TextView(this);
        String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        timeView.setText(currentTime);
        timeView.setTextColor(Color.parseColor("#C5A059"));
        timeView.setTextSize(38);
        timeView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        timeView.setGravity(Gravity.CENTER);
        card.addView(timeView);

        TextView subTitle = new TextView(this);
        subTitle.setText("حان الآن موعد أذان");
        subTitle.setTextColor(Color.parseColor("#B0AFC0"));
        subTitle.setTextSize(17);
        subTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        subParams.setMargins(0, 16, 0, 8);
        subTitle.setLayoutParams(subParams);
        card.addView(subTitle);

        prayerTitleView = new TextView(this);
        prayerTitleView.setText("صلاة " + prayerName);
        prayerTitleView.setTextColor(Color.WHITE);
        prayerTitleView.setTextSize(28);
        prayerTitleView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        prayerTitleView.setGravity(Gravity.CENTER);
        card.addView(prayerTitleView);

        Button stopBtn = new Button(this);
        stopBtn.setText("إيقاف الأذان");
        stopBtn.setTextColor(Color.BLACK);
        stopBtn.setTextSize(16);
        stopBtn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#C5A059"));
        btnBg.setCornerRadius(24f);
        stopBtn.setBackground(btnBg);

        LinearLayout.LayoutParams stopParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                130
        );
        stopParams.setMargins(0, 48, 0, 20);
        stopBtn.setLayoutParams(stopParams);

        stopBtn.setOnClickListener(v -> stopAdhanAndFinish());
        card.addView(stopBtn);

        Button openAppBtn = new Button(this);
        openAppBtn.setText("فتح التطبيق");
        openAppBtn.setTextColor(Color.WHITE);
        openAppBtn.setTextSize(14);

        GradientDrawable openBg = new GradientDrawable();
        openBg.setColor(Color.parseColor("#252330"));
        openBg.setCornerRadius(20f);
        openAppBtn.setBackground(openBg);

        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                105
        );
        openAppBtn.setLayoutParams(openParams);

        openAppBtn.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (km != null && km.isKeyguardLocked()) {
                    km.requestDismissKeyguard(this, null);
                }
            }
            Intent mainIntent = new Intent(this, MainActivity.class);
            mainIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(mainIntent);
            finish();
        });
        card.addView(openAppBtn);

        root.addView(card);
        return root;
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupShakeDetector();
    }

    @Override
    protected void onPause() {
        unregisterShakeDetector();
        super.onPause();
    }

    private void stopAdhanAndFinish() {
        try {
            Intent stopIntent = new Intent(this, AdhanForegroundService.class);
            stopIntent.setAction(AdhanForegroundService.ACTION_STOP);
            startService(stopIntent);
        } catch (Exception ignored) {}
        finish();
    }

    private void setupShakeDetector() {
        try {
            SharedPreferences prefs = getSharedPreferences("prayer_settings", Context.MODE_PRIVATE);
            boolean shakeEnabled = prefs.getBoolean("shake_to_stop_enabled", true);
            if (!shakeEnabled) return;

            float sensitivity = prefs.getFloat("shake_sensitivity", 5.5f);
            final float shakeThreshold = sensitivity > 0 ? sensitivity * 2.2f : 12.0f;

            sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            if (sensorManager != null) {
                accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                if (accelerometer != null) {
                    shakeListener = new SensorEventListener() {
                        private float lastAccel = SensorManager.GRAVITY_EARTH;
                        private float currentAccel = SensorManager.GRAVITY_EARTH;
                        private float accel = 0.00f;

                        @Override
                        public void onSensorChanged(SensorEvent event) {
                            float x = event.values[0];
                            float y = event.values[1];
                            float z = event.values[2];
                            lastAccel = currentAccel;
                            currentAccel = (float) Math.sqrt((double) (x * x + y * y + z * z));
                            float delta = currentAccel - lastAccel;
                            accel = accel * 0.9f + delta;

                            long now = System.currentTimeMillis();
                            if (Math.abs(accel) > (shakeThreshold * 0.5f) && (now - lastShakeTime > 1000)) {
                                lastShakeTime = now;
                                try {
                                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                                    if (v != null) {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                            v.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
                                        } else {
                                            v.vibrate(200);
                                        }
                                    }
                                } catch (Exception ignored) {}

                                stopAdhanAndFinish();
                            }
                        }

                        @Override
                        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
                    };
                    sensorManager.registerListener(shakeListener, accelerometer, SensorManager.SENSOR_DELAY_UI);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void unregisterShakeDetector() {
        if (sensorManager != null && shakeListener != null) {
            try {
                sensorManager.unregisterListener(shakeListener);
            } catch (Exception ignored) {}
            shakeListener = null;
        }
    }

    @Override
    protected void onDestroy() {
        unregisterShakeDetector();
        if (closeReceiver != null) {
            try {
                unregisterReceiver(closeReceiver);
            } catch (Exception ignored) {}
            closeReceiver = null;
        }
        super.onDestroy();
    }
}
