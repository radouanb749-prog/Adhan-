package com.mouadhin.app;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Native Moroccan Prayer Calculator (وزارة الأوقاف والشؤون الإسلامية بالمغرب)
 */
public class NativePrayerCalculator {

    public static class PrayerTime {
        public String id;
        public String nameAr;
        public int hour;
        public int minute;
        public long triggerAtMillis;
        public boolean isFajr;

        public PrayerTime(String id, String nameAr, int hour, int minute, long triggerAtMillis, boolean isFajr) {
            this.id = id;
            this.nameAr = nameAr;
            this.hour = hour;
            this.minute = minute;
            this.triggerAtMillis = triggerAtMillis;
            this.isFajr = isFajr;
        }

        public String getFormattedTime() {
            return String.format("%02d:%02d", hour, minute);
        }
    }

    private static double degToRad(double deg) {
        return (deg * Math.PI) / 180.0;
    }

    private static double radToDeg(double rad) {
        return (rad * 180.0) / Math.PI;
    }

    private static double normalize(double value, double max) {
        double val = value - max * Math.floor(value / max);
        return val < 0 ? val + max : val;
    }

    public static List<PrayerTime> calculatePrayers(Calendar cal, double lat, double lng, int tzOffsetHours) {
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int a = (14 - month) / 12;
        int y = year + 4800 - a;
        int m = month + 12 * a - 3;
        double jd = day + Math.floor((153.0 * m + 2) / 5) + 365.0 * y + Math.floor(y / 4.0)
                - Math.floor(y / 100.0) + Math.floor(y / 400.0) - 32045.0;

        double d = jd - 2451545.0;

        double g = normalize(357.529 + 0.98560028 * d, 360.0);
        double q = normalize(280.459 + 0.98564736 * d, 360.0);
        double L = normalize(q + 1.915 * Math.sin(degToRad(g)) + 0.02 * Math.sin(degToRad(2.0 * g)), 360.0);

        double e = 23.439 - 0.00000036 * d;
        double sinDecl = Math.sin(degToRad(e)) * Math.sin(degToRad(L));
        double decl = radToDeg(Math.asin(sinDecl));

        double ra = radToDeg(Math.atan2(Math.cos(degToRad(e)) * Math.sin(degToRad(L)), Math.cos(degToRad(L)))) / 15.0;
        double raNormalized = normalize(ra, 24.0);
        double eqTime = (q / 15.0 - raNormalized) * 60.0;

        double solarNoon = 12.0 + tzOffsetHours - lng / 15.0 - eqTime / 60.0;

        double latRad = degToRad(lat);
        double declRad = degToRad(decl);

        AutoHourAngle hourAngleFn = altitude -> {
            double cosH = (Math.sin(degToRad(altitude)) - Math.sin(latRad) * Math.sin(declRad))
                    / (Math.cos(latRad) * Math.cos(declRad));
            if (cosH > 1.0 || cosH < -1.0) return 0.0;
            return radToDeg(Math.acos(cosH)) / 15.0;
        };

        double fajrAngle = hourAngleFn.calc(-19.0);
        double fajrHours = solarNoon - fajrAngle;

        double sunAngle = hourAngleFn.calc(-0.8333);
        double sunsetHours = solarNoon + sunAngle;

        double dhuhrHours = solarNoon + (5.0 / 60.0);

        double asrAltitude = radToDeg(Math.atan(1.0 / (1.0 + Math.tan(degToRad(Math.abs(lat - decl))))));
        double asrAngle = hourAngleFn.calc(asrAltitude);
        double asrHours = solarNoon + asrAngle;

        double maghribHours = sunsetHours + (2.0 / 60.0);

        double ishaAngle = hourAngleFn.calc(-17.0);
        double ishaHours = solarNoon + ishaAngle;

        List<PrayerTime> prayers = new ArrayList<>();
        prayers.add(createPrayer("fajr", "الفجر", fajrHours, cal, true));
        prayers.add(createPrayer("dhuhr", "الظهر", dhuhrHours, cal, false));
        prayers.add(createPrayer("asr", "العصر", asrHours, cal, false));
        prayers.add(createPrayer("maghrib", "المغرب", maghribHours, cal, false));
        prayers.add(createPrayer("isha", "العشاء", ishaHours, cal, false));

        return prayers;
    }

    private interface AutoHourAngle {
        double calc(double altitude);
    }

    private static PrayerTime createPrayer(String id, String nameAr, double hours, Calendar cal, boolean isFajr) {
        hours = normalize(hours, 24.0);
        int totalMinutes = (int) Math.round(hours * 60.0);
        int h = totalMinutes / 60;
        int m = totalMinutes % 60;

        Calendar triggerCal = Calendar.getInstance();
        triggerCal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), h, m, 0);
        triggerCal.set(Calendar.MILLISECOND, 0);

        return new PrayerTime(id, nameAr, h, m, triggerCal.getTimeInMillis(), isFajr);
    }
}
