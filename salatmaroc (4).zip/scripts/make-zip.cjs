const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

try {
  if (!fs.existsSync('public')) {
    fs.mkdirSync('public', { recursive: true });
  }

  // Use zip if available, or archiver/tar
  console.log('Creating zip...');
  try {
    execSync('zip -r public/salaat-morocco-app.zip . -x "node_modules/*" ".git/*" "dist/*" "public/salaat-morocco-app.zip"', { stdio: 'inherit' });
    console.log('Zip created via zip command!');
  } catch (err) {
    console.log('zip command not found or failed, using node js script');
  }
} catch (e) {
  console.error('Error:', e);
}
