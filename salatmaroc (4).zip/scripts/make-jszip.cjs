const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');

async function createZip() {
  const zip = new JSZip();

  function addDir(dirPath, zipFolder) {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      if (
        entry.name.endsWith('.zip') ||
        entry.name === 'node_modules' ||
        entry.name === '.git' ||
        entry.name === 'dist' ||
        entry.name === 'dev-dist' ||
        entry.name === '.aistudio' ||
        entry.name === 'aistudio' ||
        entry.name === 'bun.lock'
      ) {
        continue;
      }
      if (entry.isDirectory()) {
        const subFolder = zipFolder.folder(entry.name);
        addDir(fullPath, subFolder);
      } else {
        const content = fs.readFileSync(fullPath);
        zipFolder.file(entry.name, content);
      }
    }
  }

  if (!fs.existsSync('public')) {
    fs.mkdirSync('public', { recursive: true });
  }

  console.log('Adding files to zip...');
  addDir('.', zip);

  function copyRecursive(src, dest) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    const entries = fs.readdirSync(src, { withFileTypes: true });
    for (const entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);
      if (entry.isDirectory()) {
        copyRecursive(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    }
  }

  // Ensure assets exist in both public and dist under android assets
  if (fs.existsSync('dist')) {
    copyRecursive('dist', 'android/app/src/main/assets/public');
    copyRecursive('dist', 'android/app/src/main/assets/dist');
    console.log('Synced dist to android/app/src/main/assets/public and dist');
  }

  console.log('Generating zip buffer...');
  const buffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  fs.writeFileSync('public/salatmaroc.zip', buffer);
  fs.writeFileSync('public/salaat-morocco-app.zip', buffer);
  if (fs.existsSync('dist')) {
    fs.writeFileSync('dist/salatmaroc.zip', buffer);
    fs.writeFileSync('dist/salaat-morocco-app.zip', buffer);
  }
  console.log('Successfully written public/salatmaroc.zip! Size:', buffer.length, 'bytes');
}

createZip().catch(console.error);
